import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { academicDB } from './server/db.js';
import { askAcademicAssistant, generatePersonalizedStudyPlan } from './server/gemini.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(express.json());

  // --- API Routes ---

  // Auth / Login
  app.post('/api/auth/login', (req, res) => {
    const { role, id } = req.body;
    if (role === 'faculty') {
      const fac = academicDB.getFacultyById(id || 'FAC001');
      if (fac) {
        return res.json({ success: true, role: 'faculty', user: fac });
      }
      // default to first faculty
      const first = academicDB.getFaculty()[0];
      return res.json({ success: true, role: 'faculty', user: first });
    } else {
      const stu = academicDB.getStudentById(id || 'STU101');
      if (stu) {
        return res.json({ success: true, role: 'student', user: stu });
      }
      const firstStu = academicDB.getStudents()[0];
      return res.json({ success: true, role: 'student', user: firstStu });
    }
  });

  // Get all students
  app.get('/api/students', (_req, res) => {
    res.json(academicDB.getStudents());
  });

  // Get full student data (all metrics, attendance, assignments, exams, reminders)
  app.get('/api/students/:id', (req, res) => {
    const data = academicDB.getStudentFullData(req.params.id);
    if (!data) {
      return res.status(404).json({ error: 'Student not found' });
    }
    res.json(data);
  });

  // Faculty: Add student
  app.post('/api/students', (req, res) => {
    try {
      const created = academicDB.addStudent(req.body);
      res.status(201).json(created);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to add student' });
    }
  });

  // Faculty: Update student
  app.put('/api/students/:id', (req, res) => {
    const updated = academicDB.updateStudent(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'Student not found' });
    }
    res.json(updated);
  });

  // Faculty: Delete student
  app.delete('/api/students/:id', (req, res) => {
    const ok = academicDB.deleteStudent(req.params.id);
    res.json({ success: ok });
  });

  // Get faculty list
  app.get('/api/faculty', (_req, res) => {
    res.json(academicDB.getFaculty());
  });

  // Get subjects catalog
  app.get('/api/subjects', (_req, res) => {
    res.json(academicDB.getSubjects());
  });

  // Faculty: Record attendance
  app.post('/api/attendance', (req, res) => {
    const { studentId, subjectCode, status, date, topicTaught } = req.body;
    if (!studentId || !subjectCode || !status) {
      return res.status(400).json({ error: 'Missing required attendance fields' });
    }
    const result = academicDB.recordAttendance({
      studentId,
      subjectCode,
      status,
      date: date || '2026-09-27',
      topicTaught,
    });
    res.json(result);
  });

  // Faculty: Add assignment
  app.post('/api/assignments', (req, res) => {
    const { subjectCode, subjectName, facultyName, title, description, deadline } = req.body;
    if (!title || !subjectCode || !deadline) {
      return res.status(400).json({ error: 'Title, subject, and deadline are required' });
    }
    const created = academicDB.addAssignment({
      subjectCode,
      subjectName: subjectName || subjectCode,
      facultyName: facultyName || 'Faculty',
      title,
      description: description || '',
      deadline,
    });
    res.status(201).json(created);
  });

  // Student/Faculty: Update assignment status
  app.patch('/api/assignments/:id/status', (req, res) => {
    const { status, completionPercentage } = req.body;
    const updated = academicDB.updateAssignmentStatus(req.params.id, status, completionPercentage);
    if (!updated) {
      return res.status(404).json({ error: 'Assignment not found' });
    }
    res.json(updated);
  });

  // Faculty: Add exam
  app.post('/api/exams', (req, res) => {
    const { subjectCode, subjectName, examDate, room, syllabusTopics, notes } = req.body;
    if (!subjectCode || !examDate) {
      return res.status(400).json({ error: 'Subject code and exam date are required' });
    }
    const created = academicDB.addExam({
      subjectCode,
      subjectName: subjectName || subjectCode,
      examDate,
      room: room || 'Main Exam Hall',
      syllabusTopics: syllabusTopics || ['Core Module 1', 'Core Module 2'],
      notes,
    });
    res.status(201).json(created);
  });

  // Update exam
  app.patch('/api/exams/:id', (req, res) => {
    const updated = academicDB.updateExam(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'Exam not found' });
    }
    res.json(updated);
  });

  // Faculty: Add lecture & notes
  app.post('/api/lectures', (req, res) => {
    const { date, subjectCode, subjectName, facultyName, topic, notesContent, attendanceMap } = req.body;
    if (!date || !subjectCode || !topic) {
      return res.status(400).json({ error: 'Date, subject, and topic are required' });
    }
    const created = academicDB.addLecture({
      date,
      subjectCode,
      subjectName: subjectName || subjectCode,
      facultyName: facultyName || 'Faculty',
      topic,
      notesAvailable: Boolean(notesContent && notesContent.trim().length > 0),
      notesContent: notesContent || '',
      attendanceMap,
    });
    res.status(201).json(created);
  });

  // Student: Toggle progress topic
  app.patch('/api/progress/topic', (req, res) => {
    const { studentId, subjectCode, topic, completed } = req.body;
    const success = academicDB.updateProgressTopic(studentId, subjectCode, topic, completed);
    res.json({ success });
  });

  // AI Agent Chat (ONLY on Home Page)
  app.post('/api/chat', async (req, res) => {
    const { query, studentId, history } = req.body;
    if (!query || !studentId) {
      return res.status(400).json({ error: 'query and studentId are required' });
    }

    const studentData = academicDB.getStudentFullData(studentId);
    if (!studentData) {
      return res.status(404).json({ error: 'Student data not found' });
    }

    try {
      const answer = await askAcademicAssistant(query, studentData, history || []);
      res.json({ answer });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error processing AI question' });
    }
  });

  // Study Planner generator
  app.post('/api/study-planner/generate', async (req, res) => {
    const { studentId, dailyHours, planType, weakSubjects, focusSubjects } = req.body;
    const studentData = academicDB.getStudentFullData(studentId || 'STU101');
    if (!studentData) {
      return res.status(404).json({ error: 'Student data not found' });
    }

    try {
      const plan = await generatePersonalizedStudyPlan(studentData, {
        dailyHours: Number(dailyHours) || 3,
        planType: planType || '1-day',
        weakSubjects: weakSubjects || [],
        focusSubjects: focusSubjects || [],
      });
      res.json(plan);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to generate study plan' });
    }
  });

  // Reset database to initial seed
  app.post('/api/reset-db', (_req, res) => {
    academicDB.resetDatabase();
    res.json({ success: true, message: 'Database reset to 10 sample students' });
  });

  // Vite middleware in dev or static files in production
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`[AcademiaAI] Server running on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server boot error:', err);
});
