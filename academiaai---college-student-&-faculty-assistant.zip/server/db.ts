import fs from 'fs';
import path from 'path';
import {
  Student,
  Faculty,
  Subject,
  AttendanceEntry,
  Assignment,
  Exam,
  Lecture,
  SubjectProgress,
  Reminder,
  StudentFullData,
  AttendanceStatus,
  AssignmentStatus,
} from '../src/types/academic.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'academic_db.json');

export interface AcademicDatabase {
  students: Student[];
  faculty: Faculty[];
  subjects: Subject[];
  attendanceEntries: AttendanceEntry[];
  assignments: Assignment[];
  exams: Exam[];
  lectures: Lecture[];
  progress: Record<string, SubjectProgress[]>; // studentId -> progress
}

// 10 realistic Indian college students
const INITIAL_STUDENTS: Student[] = [
  {
    id: 'STU101',
    name: 'Aarav Sharma',
    rollNo: '21CS101',
    email: 'aarav.sharma@college.edu.in',
    phone: '+91 98201 44521',
    course: 'B.Tech Computer Science & Engineering',
    semester: 6,
    division: 'A',
    cgpa: 8.65,
    mentor: 'Prof. Rajesh Mehta',
    enrolledSubjects: ['CS601', 'CS602', 'CS603', 'CS604', 'CS605'],
    weakSubjects: ['CS602'], // DBMS
  },
  {
    id: 'STU102',
    name: 'Priya Patel',
    rollNo: '21CS102',
    email: 'priya.patel@college.edu.in',
    phone: '+91 98450 12890',
    course: 'B.Tech Computer Science & Engineering',
    semester: 6,
    division: 'A',
    cgpa: 8.2,
    mentor: 'Dr. Sunita Rao',
    enrolledSubjects: ['CS601', 'CS602', 'CS603', 'CS604', 'CS605'],
    weakSubjects: ['CS603'], // Computer Networks
  },
  {
    id: 'STU103',
    name: 'Rohan Verma',
    rollNo: '21CS103',
    email: 'rohan.verma@college.edu.in',
    phone: '+91 97112 88419',
    course: 'B.Tech Computer Science & Engineering',
    semester: 6,
    division: 'B',
    cgpa: 6.95,
    mentor: 'Prof. Rajesh Mehta',
    enrolledSubjects: ['CS601', 'CS602', 'CS603', 'CS604', 'CS605'],
    weakSubjects: ['CS601', 'CS602'], // OS & DBMS (Low Attendance Alert)
  },
  {
    id: 'STU104',
    name: 'Ananya Iyer',
    rollNo: '21CS104',
    email: 'ananya.iyer@college.edu.in',
    phone: '+91 99304 55120',
    course: 'B.Tech Computer Science & Engineering',
    semester: 6,
    division: 'A',
    cgpa: 9.45,
    mentor: 'Dr. Sunita Rao',
    enrolledSubjects: ['CS601', 'CS602', 'CS603', 'CS604', 'CS605'],
    weakSubjects: [],
  },
  {
    id: 'STU105',
    name: 'Karthik Nair',
    rollNo: '21CS105',
    email: 'karthik.nair@college.edu.in',
    phone: '+91 98111 67234',
    course: 'B.Tech Computer Science & Engineering',
    semester: 6,
    division: 'B',
    cgpa: 7.75,
    mentor: 'Prof. Rajesh Mehta',
    enrolledSubjects: ['CS601', 'CS602', 'CS603', 'CS604', 'CS605'],
    weakSubjects: ['CS601'], // Operating Systems
  },
  {
    id: 'STU106',
    name: 'Sneha Kulkarni',
    rollNo: '21CS106',
    email: 'sneha.kulkarni@college.edu.in',
    phone: '+91 98670 91823',
    course: 'B.Tech Computer Science & Engineering',
    semester: 6,
    division: 'A',
    cgpa: 8.1,
    mentor: 'Dr. Sunita Rao',
    enrolledSubjects: ['CS601', 'CS602', 'CS603', 'CS604', 'CS605'],
    weakSubjects: ['CS604'], // Theory of Computation
  },
  {
    id: 'STU107',
    name: 'Vikram Singh',
    rollNo: '21CS107',
    email: 'vikram.singh@college.edu.in',
    phone: '+91 98220 33419',
    course: 'B.Tech Computer Science & Engineering',
    semester: 6,
    division: 'B',
    cgpa: 7.3,
    mentor: 'Prof. Rajesh Mehta',
    enrolledSubjects: ['CS601', 'CS602', 'CS603', 'CS604', 'CS605'],
    weakSubjects: ['CS603', 'CS605'],
  },
  {
    id: 'STU108',
    name: 'Divya Sundaram',
    rollNo: '21CS108',
    email: 'divya.sundaram@college.edu.in',
    phone: '+91 99401 77312',
    course: 'B.Tech Computer Science & Engineering',
    semester: 6,
    division: 'A',
    cgpa: 8.8,
    mentor: 'Dr. Sunita Rao',
    enrolledSubjects: ['CS601', 'CS602', 'CS603', 'CS604', 'CS605'],
    weakSubjects: ['CS602'],
  },
  {
    id: 'STU109',
    name: 'Mohammad Farhan',
    rollNo: '21CS109',
    email: 'm.farhan@college.edu.in',
    phone: '+91 98920 66541',
    course: 'B.Tech Computer Science & Engineering',
    semester: 6,
    division: 'B',
    cgpa: 7.15,
    mentor: 'Prof. Rajesh Mehta',
    enrolledSubjects: ['CS601', 'CS602', 'CS603', 'CS604', 'CS605'],
    weakSubjects: ['CS603'], // CN low attendance
  },
  {
    id: 'STU110',
    name: 'Ishita Sen',
    rollNo: '21CS110',
    email: 'ishita.sen@college.edu.in',
    phone: '+91 98300 22918',
    course: 'B.Tech Computer Science & Engineering',
    semester: 6,
    division: 'A',
    cgpa: 9.1,
    mentor: 'Dr. Sunita Rao',
    enrolledSubjects: ['CS601', 'CS602', 'CS603', 'CS604', 'CS605'],
    weakSubjects: ['CS604'],
  },
];

const INITIAL_FACULTY: Faculty[] = [
  {
    id: 'FAC001',
    name: 'Prof. Rajesh Mehta',
    email: 'rajesh.mehta@college.edu.in',
    department: 'Computer Science & Engineering',
    designation: 'Associate Professor & HOD Academics',
    subjects: ['CS601', 'CS602'],
  },
  {
    id: 'FAC002',
    name: 'Dr. Sunita Rao',
    email: 'sunita.rao@college.edu.in',
    department: 'Computer Science & Engineering',
    designation: 'Professor & Senior Research Lead',
    subjects: ['CS603', 'CS604', 'CS605'],
  },
];

const INITIAL_SUBJECTS: Subject[] = [
  {
    code: 'CS601',
    name: 'Operating Systems',
    shortName: 'OS',
    facultyId: 'FAC001',
    facultyName: 'Prof. Rajesh Mehta',
    credits: 4,
    syllabusTopics: [
      'Process Management & Threads',
      'CPU Scheduling Algorithms',
      'Process Synchronization & Deadlocks',
      'Memory Management & Paging',
      'Virtual Memory & Page Replacement',
      'File System Implementation',
      'Disk Scheduling & I/O Systems',
    ],
  },
  {
    code: 'CS602',
    name: 'Database Management Systems',
    shortName: 'DBMS',
    facultyId: 'FAC001',
    facultyName: 'Prof. Rajesh Mehta',
    credits: 4,
    syllabusTopics: [
      'Relational Data Model & ER Diagrams',
      'Relational Algebra & Advanced SQL',
      'Database Normalization (1NF to BCNF)',
      'Transaction Processing & ACID Properties',
      'Concurrency Control & Locking Protocols',
      'Crash Recovery & Logging',
      'Indexing & B+ Trees',
    ],
  },
  {
    code: 'CS603',
    name: 'Computer Networks',
    shortName: 'CN',
    facultyId: 'FAC002',
    facultyName: 'Dr. Sunita Rao',
    credits: 4,
    syllabusTopics: [
      'OSI & TCP/IP Reference Architectures',
      'Data Link Layer & Error Control',
      'Medium Access Control (CSMA/CD)',
      'Network Layer Routing (Distance Vector & Link State)',
      'IP Addressing, CIDR & Subnetting',
      'Transport Layer (TCP, UDP, Flow & Congestion Control)',
      'Application Layer (DNS, HTTP, SMTP)',
    ],
  },
  {
    code: 'CS604',
    name: 'Theory of Computation',
    shortName: 'TOC',
    facultyId: 'FAC002',
    facultyName: 'Dr. Sunita Rao',
    credits: 3,
    syllabusTopics: [
      'Deterministic & Non-deterministic Finite Automata',
      'Regular Expressions & Pumping Lemma for Regular Languages',
      'Context-Free Grammars & Pushdown Automata',
      'Pumping Lemma for CFLs & Normal Forms',
      'Turing Machines & Variants',
      'Decidability & Halting Problem',
    ],
  },
  {
    code: 'CS605',
    name: 'Web Technologies & Cloud Applications',
    shortName: 'WTCA',
    facultyId: 'FAC002',
    facultyName: 'Dr. Sunita Rao',
    credits: 3,
    syllabusTopics: [
      'Modern Web Architectures & REST APIs',
      'React & State Management',
      'Node.js & Express Backend Services',
      'Database Integration & Authentication',
      'Cloud Deployment & Docker Basics',
      'Microservices & Serverless',
    ],
  },
];

// Seed lectures with dates, notes, and attendance maps
const INITIAL_LECTURES: Lecture[] = [
  {
    id: 'LEC001',
    date: '2026-09-24',
    subjectCode: 'CS601',
    subjectName: 'Operating Systems',
    facultyName: 'Prof. Rajesh Mehta',
    topic: 'CPU Scheduling Algorithms (FCFS, SJF, Round Robin & Multi-level)',
    notesAvailable: true,
    notesContent: `### Operating Systems — CPU Scheduling Algorithms\n\n**Key Concepts Taught:**\n- **FCFS (First-Come, First-Served):** Non-preemptive, suffers from Convoy Effect.\n- **SJF (Shortest Job First):** Optimal average turnaround and waiting time. Preemptive variant is SRTF (Shortest Remaining Time First).\n- **Round Robin (RR):** Preemptive, time quantum 'q' critical. If q too large -> FCFS; if q too small -> high context switch overhead.\n- **Priority Scheduling:** Suffers from Starvation; solution is Aging (gradually increase priority of waiting processes).\n- **Formula:** Turnaround Time = Completion Time - Arrival Time. Waiting Time = Turnaround Time - Burst Time.\n\n*Review Questions:*\n1. Calculate average waiting time for 4 processes with given burst times under RR (q=2).\n2. Explain how aging resolves starvation in Priority Scheduling.`,
    attendanceMap: {
      STU101: 'Present',
      STU102: 'Present',
      STU103: 'Absent', // Rohan absent
      STU104: 'Present',
      STU105: 'Absent', // Karthik absent
      STU106: 'Present',
      STU107: 'Absent', // Vikram absent
      STU108: 'Present',
      STU109: 'Present',
      STU110: 'Present',
    },
  },
  {
    id: 'LEC002',
    date: '2026-09-25',
    subjectCode: 'CS602',
    subjectName: 'Database Management Systems',
    facultyName: 'Prof. Rajesh Mehta',
    topic: 'Database Normalization (BCNF vs 3NF & Dependency Preservation)',
    notesAvailable: true,
    notesContent: `### DBMS — Normalization: 3NF & BCNF\n\n**Key Takeaways:**\n- **Functional Dependency (FD):** X -> Y means X uniquely determines Y.\n- **Third Normal Form (3NF):** For every FD X -> Y, either X is a superkey OR Y is a prime attribute.\n- **Boyce-Codd Normal Form (BCNF):** For every FD X -> Y, X must strictly be a superkey. No exceptions.\n- **Trade-off:** BCNF guarantees zero redundancy from functional dependencies, but may NOT preserve all functional dependencies. 3NF always allows dependency preservation and lossless join.\n\n*Important Problem:* Decomposition of R(A,B,C,D) with F={AB->C, C->D, D->A}. Determine highest normal form.`,
    attendanceMap: {
      STU101: 'Present',
      STU102: 'Present',
      STU103: 'Absent', // Rohan absent again in DBMS!
      STU104: 'Present',
      STU105: 'Present',
      STU106: 'Present',
      STU107: 'Present',
      STU108: 'Present',
      STU109: 'Absent', // Farhan absent
      STU110: 'Present',
    },
  },
  {
    id: 'LEC003',
    date: '2026-09-26',
    subjectCode: 'CS603',
    subjectName: 'Computer Networks',
    facultyName: 'Dr. Sunita Rao',
    topic: 'Subnetting, CIDR & Variable Length Subnet Masking (VLSM)',
    notesAvailable: true,
    notesContent: `### Computer Networks — CIDR & Subnetting\n\n**Class Summary:**\n- **Classless Inter-Domain Routing (CIDR):** Representation using prefix notation (e.g., 192.168.10.0/26).\n- Subnet Mask for /26: 255.255.255.192. Total host addresses = 2^(32-26) = 64 (Usable: 62).\n- Network Address: Bitwise AND of IP and subnet mask.\n- Broadcast Address: Set all host bits to 1.\n- **Routing table lookup:** Longest prefix match algorithm used by routers.\n\n*Lab Task:* Divide 172.16.0.0/24 into 4 subnets for CSE department labs.`,
    attendanceMap: {
      STU101: 'Present',
      STU102: 'Absent', // Priya missed CN!
      STU103: 'Present',
      STU104: 'Present',
      STU105: 'Present',
      STU106: 'Present',
      STU107: 'Absent',
      STU108: 'Present',
      STU109: 'Absent', // Farhan missed CN (dangerously low!)
      STU110: 'Present',
    },
  },
  {
    id: 'LEC004',
    date: '2026-09-22',
    subjectCode: 'CS604',
    subjectName: 'Theory of Computation',
    facultyName: 'Dr. Sunita Rao',
    topic: 'Pumping Lemma for Regular Languages & Non-regular Proofs',
    notesAvailable: true,
    notesContent: `### TOC — Pumping Lemma for Regular Languages\n\n**Statement:**\nIf L is regular, there exists an integer p >= 1 (pumping length) such that any string w in L with |w| >= p can be split as w = xyz satisfying:\n1. |y| > 0\n2. |xy| <= p\n3. For all i >= 0, xy^i z is in L.\n\n**Application:** Used exclusively to prove that a given language is NOT regular via contradiction (e.g., L = {a^n b^n | n >= 0}).`,
    attendanceMap: {
      STU101: 'Present',
      STU102: 'Present',
      STU103: 'Absent',
      STU104: 'Present',
      STU105: 'Present',
      STU106: 'Absent', // Sneha missed TOC!
      STU107: 'Present',
      STU108: 'Present',
      STU109: 'Present',
      STU110: 'Present',
    },
  },
  {
    id: 'LEC005',
    date: '2026-09-20',
    subjectCode: 'CS605',
    subjectName: 'Web Technologies & Cloud Applications',
    facultyName: 'Dr. Sunita Rao',
    topic: 'Building RESTful APIs with Node.js & Express Middleware',
    notesAvailable: true,
    notesContent: `### WTCA — REST APIs & Express Architecture\n\n**Core Topics:**\n- Stateless HTTP methods: GET, POST, PUT, PATCH, DELETE.\n- Status codes: 200 OK, 201 Created, 400 Bad Request, 401 Unauthorized, 403 Forbidden, 404 Not Found, 500 Internal Error.\n- Express Middleware stack: Application-level, router-level, error-handling middleware (takes 4 parameters: err, req, res, next).\n- JWT token authentication and Bearer header parsing.`,
    attendanceMap: {
      STU101: 'Present',
      STU102: 'Present',
      STU103: 'Present',
      STU104: 'Present',
      STU105: 'Present',
      STU106: 'Present',
      STU107: 'Absent',
      STU108: 'Present',
      STU109: 'Present',
      STU110: 'Present',
    },
  },
];

// Helper to generate realistic historical attendance numbers per student & subject
const SUBJECT_TOTAL_CLASSES: Record<string, number> = {
  CS601: 25,
  CS602: 25,
  CS603: 24,
  CS604: 20,
  CS605: 20,
};

// Seed student-specific class attendance stats
const STUDENT_ATTENDANCE_PRESETS: Record<string, Record<string, { attended: number; missed: number }>> = {
  STU101: { // Aarav Sharma (88% overall)
    CS601: { attended: 22, missed: 3 },
    CS602: { attended: 21, missed: 4 },
    CS603: { attended: 22, missed: 2 },
    CS604: { attended: 18, missed: 2 },
    CS605: { attended: 18, missed: 2 },
  },
  STU102: { // Priya Patel (74.5% overall, borderline)
    CS601: { attended: 19, missed: 6 },
    CS602: { attended: 19, missed: 6 },
    CS603: { attended: 17, missed: 7 }, // CN warning!
    CS604: { attended: 15, missed: 5 },
    CS605: { attended: 15, missed: 5 },
  },
  STU103: { // Rohan Verma (68% overall, critical low attendance in DBMS & OS)
    CS601: { attended: 17, missed: 8 }, // 68%
    CS602: { attended: 16, missed: 9 }, // 64% - LOW!
    CS603: { attended: 17, missed: 7 },
    CS604: { attended: 14, missed: 6 }, // 70%
    CS605: { attended: 14, missed: 6 },
  },
  STU104: { // Ananya Iyer (94% overall, high achiever)
    CS601: { attended: 24, missed: 1 },
    CS602: { attended: 24, missed: 1 },
    CS603: { attended: 23, missed: 1 },
    CS604: { attended: 19, missed: 1 },
    CS605: { attended: 19, missed: 1 },
  },
  STU105: { // Karthik Nair (79% overall)
    CS601: { attended: 19, missed: 6 }, // 76%
    CS602: { attended: 20, missed: 5 },
    CS603: { attended: 19, missed: 5 },
    CS604: { attended: 16, missed: 4 },
    CS605: { attended: 16, missed: 4 },
  },
  STU106: { // Sneha Kulkarni (81% overall)
    CS601: { attended: 21, missed: 4 },
    CS602: { attended: 21, missed: 4 },
    CS603: { attended: 20, missed: 4 },
    CS604: { attended: 15, missed: 5 }, // 75%
    CS605: { attended: 17, missed: 3 },
  },
  STU107: { // Vikram Singh (72% overall, warning)
    CS601: { attended: 18, missed: 7 }, // 72%
    CS602: { attended: 18, missed: 7 }, // 72%
    CS603: { attended: 17, missed: 7 }, // 70.8%
    CS604: { attended: 14, missed: 6 }, // 70%
    CS605: { attended: 15, missed: 5 }, // 75%
  },
  STU108: { // Divya Sundaram (86% overall)
    CS601: { attended: 22, missed: 3 },
    CS602: { attended: 21, missed: 4 },
    CS603: { attended: 21, missed: 3 },
    CS604: { attended: 17, missed: 3 },
    CS605: { attended: 18, missed: 2 },
  },
  STU109: { // Mohammad Farhan (71% overall, critical CN attendance)
    CS601: { attended: 18, missed: 7 },
    CS602: { attended: 18, missed: 7 },
    CS603: { attended: 16, missed: 8 }, // 66.6% - WARNING!
    CS604: { attended: 15, missed: 5 },
    CS605: { attended: 15, missed: 5 },
  },
  STU110: { // Ishita Sen (91% overall)
    CS601: { attended: 23, missed: 2 },
    CS602: { attended: 23, missed: 2 },
    CS603: { attended: 22, missed: 2 },
    CS604: { attended: 18, missed: 2 },
    CS605: { attended: 19, missed: 1 },
  },
};

// Seed Assignments with deadlines relative to current time (Sept 2026)
const INITIAL_ASSIGNMENTS: Assignment[] = [
  {
    id: 'ASN001',
    subjectCode: 'CS602',
    subjectName: 'Database Management Systems',
    facultyName: 'Prof. Rajesh Mehta',
    title: 'DBMS Assignment 3: Relational Algebra & Query Optimization',
    description: 'Implement complex queries, relational algebra expressions, and query tree transformations with execution plans.',
    deadline: '2026-09-29', // Due in 2 days!
    status: 'Pending',
    completionPercentage: 35,
  },
  {
    id: 'ASN002',
    subjectCode: 'CS603',
    subjectName: 'Computer Networks',
    facultyName: 'Dr. Sunita Rao',
    title: 'Socket Programming & Packet Analysis in Wireshark',
    description: 'Build a multi-client TCP echo server in C/Python and trace TCP three-way handshake and FIN packets.',
    deadline: '2026-09-28', // Due in 1 day! Urgent!
    status: 'In Progress',
    completionPercentage: 70,
  },
  {
    id: 'ASN003',
    subjectCode: 'CS601',
    subjectName: 'Operating Systems',
    facultyName: 'Prof. Rajesh Mehta',
    title: 'Process Synchronization using Semaphores & Mutex',
    description: 'Simulate the classic Dining Philosophers and Producer-Consumer synchronization problems with deadlock avoidance.',
    deadline: '2026-10-04', // Due in 7 days
    status: 'Pending',
    completionPercentage: 10,
  },
  {
    id: 'ASN004',
    subjectCode: 'CS604',
    subjectName: 'Theory of Computation',
    facultyName: 'Dr. Sunita Rao',
    title: 'PDA Design and Context-Free Grammar Simplification',
    description: 'Construct deterministic pushdown automata for palindromes and convert grammars to Chomsky Normal Form (CNF).',
    deadline: '2026-10-08',
    status: 'Pending',
    completionPercentage: 0,
  },
  {
    id: 'ASN005',
    subjectCode: 'CS605',
    subjectName: 'Web Technologies & Cloud Applications',
    facultyName: 'Dr. Sunita Rao',
    title: 'Full Stack REST API with Authentication & Dockerization',
    description: 'Create a secured Express API with JWT auth, PostgreSQL/SQLite connection, and Dockerfile containerization.',
    deadline: '2026-09-20', // Past deadline - completed
    status: 'Completed',
    completionPercentage: 100,
  },
];

// Seed Exams
const INITIAL_EXAMS: Exam[] = [
  {
    id: 'EXAM001',
    subjectCode: 'CS601',
    subjectName: 'Operating Systems',
    examDate: '2026-10-09', // in 12 days
    room: 'Hall 302, Academic Block A',
    syllabusTopics: [
      'Processes & Threads',
      'CPU Scheduling Algorithms',
      'Synchronization & Deadlocks',
      'Paging & Virtual Memory',
    ],
    syllabusProgress: 65,
    prepProgress: 60,
    notes: 'Focus on Banker Algorithm and Page Replacement (FIFO, LRU, Optimal).',
  },
  {
    id: 'EXAM002',
    subjectCode: 'CS604',
    subjectName: 'Theory of Computation',
    examDate: '2026-10-03', // in 6 days
    room: 'Auditorium 1, Main Campus',
    syllabusTopics: [
      'DFA, NFA & Equivalence',
      'Regular Expressions & Pumping Lemma',
      'Context-Free Grammars',
      'Pushdown Automata',
    ],
    syllabusProgress: 55,
    prepProgress: 45,
    notes: 'High weightage on Pumping Lemma proofs and PDA state transition diagrams.',
  },
  {
    id: 'EXAM003',
    subjectCode: 'CS602',
    subjectName: 'Database Management Systems',
    examDate: '2026-10-15', // in 18 days
    room: 'Lab 4, Computing Center',
    syllabusTopics: [
      'Relational Algebra & SQL',
      'Normalization (3NF, BCNF)',
      'Transactions & Concurrency',
      'Indexing & B+ Trees',
    ],
    syllabusProgress: 75,
    prepProgress: 65,
    notes: 'Practical SQL and Normalization decomposition problems will carry 40 marks.',
  },
  {
    id: 'EXAM004',
    subjectCode: 'CS603',
    subjectName: 'Computer Networks',
    examDate: '2026-10-22', // in 25 days
    room: 'Hall 105, Academic Block B',
    syllabusTopics: [
      'OSI / TCP-IP Models',
      'Subnetting & Routing Algorithms',
      'TCP Congestion Control',
      'Application Layer Protocols',
    ],
    syllabusProgress: 80,
    prepProgress: 70,
    notes: 'Numerical problems on Subnetting (CIDR/VLSM) and Dijkstra/Distance Vector routing.',
  },
];

class AcademicDB {
  private data: AcademicDatabase;

  constructor() {
    this.data = this.loadOrInit();
  }

  private loadOrInit(): AcademicDatabase {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw) as AcademicDatabase;
        if (parsed.students && parsed.students.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Error loading DB file, will reseed:', e);
    }

    const seeded = this.seedDatabase();
    this.save(seeded);
    return seeded;
  }

  private seedDatabase(): AcademicDatabase {
    // Generate initial progress per student
    const progressMap: Record<string, SubjectProgress[]> = {};
    for (const student of INITIAL_STUDENTS) {
      progressMap[student.id] = INITIAL_SUBJECTS.map((sub) => {
        const isHigh = ['STU104', 'STU110'].includes(student.id);
        const isLow = ['STU103', 'STU107'].includes(student.id);
        const completedCount = isHigh ? 5 : isLow ? 2 : 3;
        const completed = sub.syllabusTopics.slice(0, completedCount);
        const remaining = sub.syllabusTopics.slice(completedCount);
        return {
          subjectCode: sub.code,
          subjectName: sub.name,
          completedTopics: completed,
          remainingTopics: remaining,
          totalTopicsCount: sub.syllabusTopics.length,
          studyHoursLogged: isHigh ? 42 : isLow ? 18 : 28,
        };
      });
    }

    return {
      students: INITIAL_STUDENTS,
      faculty: INITIAL_FACULTY,
      subjects: INITIAL_SUBJECTS,
      attendanceEntries: [],
      assignments: INITIAL_ASSIGNMENTS,
      exams: INITIAL_EXAMS,
      lectures: INITIAL_LECTURES,
      progress: progressMap,
    };
  }

  private save(data?: AcademicDatabase) {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(data || this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to save academic DB:', err);
    }
  }

  // --- Read Operations ---
  public getStudents(): Student[] {
    return this.data.students;
  }

  public getStudentById(id: string): Student | undefined {
    return this.data.students.find((s) => s.id === id);
  }

  public getFaculty(): Faculty[] {
    return this.data.faculty;
  }

  public getFacultyById(id: string): Faculty | undefined {
    return this.data.faculty.find((f) => f.id === id);
  }

  public getSubjects(): Subject[] {
    return this.data.subjects;
  }

  public getLectures(): Lecture[] {
    return this.data.lectures;
  }

  public getAssignments(): Assignment[] {
    return this.data.assignments;
  }

  public getExams(): Exam[] {
    return this.data.exams;
  }

  // Calculate dynamic days remaining from current date (2026-09-27)
  private getDaysRemaining(targetDateStr: string): number {
    const today = new Date('2026-09-27T00:00:00');
    const target = new Date(targetDateStr + 'T00:00:00');
    const diffTime = target.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  // Get aggregated student full data
  public getStudentFullData(studentId: string): StudentFullData | null {
    const student = this.getStudentById(studentId);
    if (!student) return null;

    // Subjects
    const enrolledSubs = this.data.subjects.filter((sub) =>
      student.enrolledSubjects.includes(sub.code)
    );

    // Attendance calculation
    const preset = STUDENT_ATTENDANCE_PRESETS[student.id] || {};
    let totalAttended = 0;
    let totalMissed = 0;

    const subjectStats = enrolledSubs.map((sub) => {
      let attended = preset[sub.code]?.attended ?? 20;
      let missed = preset[sub.code]?.missed ?? 5;

      // Adjust for recorded lectures
      for (const lec of this.data.lectures) {
        if (lec.subjectCode === sub.code && lec.attendanceMap[student.id]) {
          // If already in preset we keep as base, but we can verify status
        }
      }

      const total = attended + missed;
      const pct = total > 0 ? Math.round((attended / total) * 100) : 0;
      const isLow = pct < 75;

      totalAttended += attended;
      totalMissed += missed;

      // Needed for 75%: (attended + x) / (total + x) >= 0.75 => x >= (3*total - 4*attended)
      const neededFor75 = isLow ? Math.max(0, Math.ceil(3 * total - 4 * attended)) : 0;

      return {
        subjectCode: sub.code,
        subjectName: sub.name,
        facultyName: sub.facultyName,
        attended,
        missed,
        total,
        percentage: pct,
        isLow,
        neededFor75,
      };
    });

    const totalClasses = totalAttended + totalMissed;
    const overallPercentage = totalClasses > 0 ? Math.round((totalAttended / totalClasses) * 100) : 0;

    // Assignments
    const assignmentsWithMeta = this.data.assignments.map((asn) => {
      const days = this.getDaysRemaining(asn.deadline);
      const isUrgent = days >= 0 && days <= 2 && asn.status !== 'Completed';
      return {
        ...asn,
        daysRemaining: days,
        isUrgent,
      };
    });

    // Exams
    const examsWithMeta = this.data.exams.map((exam) => {
      const days = this.getDaysRemaining(exam.examDate);
      return {
        ...exam,
        daysRemaining: days,
      };
    }).sort((a, b) => a.daysRemaining - b.daysRemaining);

    // Lectures with student's specific attendance
    const studentLectures = this.data.lectures.map((lec) => ({
      id: lec.id,
      date: lec.date,
      subjectCode: lec.subjectCode,
      subjectName: lec.subjectName,
      topic: lec.topic,
      status: (lec.attendanceMap[student.id] || 'Present') as AttendanceStatus,
      notesAvailable: lec.notesAvailable,
      notesContent: lec.notesContent,
      facultyName: lec.facultyName,
    }));

    // Progress
    const studentProgressList = this.data.progress[student.id] || [];
    let totalCompletedTopics = 0;
    let totalTopicsAll = 0;
    let totalStudyHours = 0;

    for (const prog of studentProgressList) {
      totalCompletedTopics += prog.completedTopics.length;
      totalTopicsAll += prog.totalTopicsCount;
      totalStudyHours += prog.studyHoursLogged;
    }

    const overallProgressPercentage =
      totalTopicsAll > 0 ? Math.round((totalCompletedTopics / totalTopicsAll) * 100) : 50;

    const completedAssignments = assignmentsWithMeta.filter((a) => a.status === 'Completed').length;
    const assignmentsCompletionPercentage =
      assignmentsWithMeta.length > 0
        ? Math.round((completedAssignments / assignmentsWithMeta.length) * 100)
        : 0;

    // Automated Reminders
    const reminders: Reminder[] = [];

    // 1. Assignment deadlines (2 days or 1 day)
    for (const asn of assignmentsWithMeta) {
      if (asn.status !== 'Completed') {
        if (asn.daysRemaining === 1) {
          reminders.push({
            id: `rem-asn-${asn.id}`,
            type: 'assignment_due',
            title: `Assignment Due Tomorrow`,
            message: `Reminder: Your ${asn.subjectName} assignment "${asn.title}" is due tomorrow!`,
            urgency: 'critical',
            date: asn.deadline,
            relatedSubject: asn.subjectName,
            actionPage: 'assignments',
          });
        } else if (asn.daysRemaining === 2) {
          reminders.push({
            id: `rem-asn-${asn.id}`,
            type: 'assignment_due',
            title: `Assignment Due in 2 Days`,
            message: `Your ${asn.subjectName} assignment "${asn.title}" is due in 2 days.`,
            urgency: 'warning',
            date: asn.deadline,
            relatedSubject: asn.subjectName,
            actionPage: 'assignments',
          });
        } else if (asn.daysRemaining < 0) {
          reminders.push({
            id: `rem-asn-overdue-${asn.id}`,
            type: 'assignment_due',
            title: `Overdue Assignment`,
            message: `Your ${asn.subjectName} assignment is overdue by ${Math.abs(asn.daysRemaining)} day(s).`,
            urgency: 'critical',
            date: asn.deadline,
            relatedSubject: asn.subjectName,
            actionPage: 'assignments',
          });
        }
      }
    }

    // 2. Low attendance warnings (< 75%)
    for (const sStat of subjectStats) {
      if (sStat.isLow) {
        reminders.push({
          id: `rem-att-${sStat.subjectCode}`,
          type: 'low_attendance',
          title: `Low Attendance Alert: ${sStat.subjectName}`,
          message: `Your attendance in ${sStat.subjectName} is ${sStat.percentage}%. You have missed ${sStat.missed} classes. You need to attend at least ${sStat.neededFor75} consecutive classes to cross 75%.`,
          urgency: 'critical',
          date: '2026-09-27',
          relatedSubject: sStat.subjectName,
          actionPage: 'attendance',
        });
      }
    }

    // 3. Upcoming exams (within 14 days)
    for (const exam of examsWithMeta) {
      if (exam.daysRemaining > 0 && exam.daysRemaining <= 14) {
        reminders.push({
          id: `rem-exam-${exam.id}`,
          type: 'exam_soon',
          title: `Upcoming Exam: ${exam.subjectName}`,
          message: `Your ${exam.subjectName} exam is in ${exam.daysRemaining} days (${exam.examDate}). Preparation is at ${exam.prepProgress}%.`,
          urgency: exam.daysRemaining <= 7 ? 'critical' : 'warning',
          date: exam.examDate,
          relatedSubject: exam.subjectName,
          actionPage: 'exams',
        });
      }
    }

    // 4. Missed lectures with notes available
    for (const lec of studentLectures) {
      if (lec.status === 'Absent' && lec.notesAvailable) {
        reminders.push({
          id: `rem-lec-${lec.id}`,
          type: 'missed_lecture',
          title: `Missed Lecture Notes Available`,
          message: `You were absent for ${lec.date} ${lec.subjectName} lecture on "${lec.topic}". Faculty lecture notes are available for download.`,
          urgency: 'info',
          date: lec.date,
          relatedSubject: lec.subjectName,
          actionPage: 'lectures_notes',
        });
      }
    }

    return {
      student,
      subjects: enrolledSubs,
      attendanceSummary: {
        overallPercentage,
        totalClasses,
        totalAttended,
        totalMissed,
        subjectStats,
      },
      assignments: assignmentsWithMeta,
      exams: examsWithMeta,
      lectures: studentLectures,
      progress: {
        overallProgressPercentage,
        subjects: studentProgressList,
        totalStudyHours,
        assignmentsCompletedCount: completedAssignments,
        assignmentsTotalCount: assignmentsWithMeta.length,
        assignmentsCompletionPercentage,
      },
      reminders,
    };
  }

  // --- Faculty Operations ---
  public addStudent(newStudent: Omit<Student, 'id'> & { id?: string }): Student {
    const nextIdNum = this.data.students.length + 101;
    const id = newStudent.id || `STU${nextIdNum}`;
    const student: Student = {
      ...newStudent,
      id,
      enrolledSubjects: newStudent.enrolledSubjects?.length
        ? newStudent.enrolledSubjects
        : ['CS601', 'CS602', 'CS603', 'CS604', 'CS605'],
    };

    this.data.students.push(student);

    // Initialize progress
    this.data.progress[id] = this.data.subjects.map((sub) => ({
      subjectCode: sub.code,
      subjectName: sub.name,
      completedTopics: sub.syllabusTopics.slice(0, 2),
      remainingTopics: sub.syllabusTopics.slice(2),
      totalTopicsCount: sub.syllabusTopics.length,
      studyHoursLogged: 10,
    }));

    // Initialize default attendance preset
    STUDENT_ATTENDANCE_PRESETS[id] = {
      CS601: { attended: 18, missed: 4 },
      CS602: { attended: 18, missed: 4 },
      CS603: { attended: 17, missed: 5 },
      CS604: { attended: 15, missed: 4 },
      CS605: { attended: 15, missed: 4 },
    };

    this.save();
    return student;
  }

  public updateStudent(id: string, updates: Partial<Student>): Student | null {
    const idx = this.data.students.findIndex((s) => s.id === id);
    if (idx === -1) return null;
    this.data.students[idx] = { ...this.data.students[idx], ...updates };
    this.save();
    return this.data.students[idx];
  }

  public deleteStudent(id: string): boolean {
    const initialLen = this.data.students.length;
    this.data.students = this.data.students.filter((s) => s.id !== id);
    delete this.data.progress[id];
    delete STUDENT_ATTENDANCE_PRESETS[id];
    this.save();
    return this.data.students.length < initialLen;
  }

  public recordAttendance(params: {
    studentId: string;
    subjectCode: string;
    status: AttendanceStatus;
    date: string;
    topicTaught?: string;
  }): { success: boolean; newPercentage: number } {
    const { studentId, subjectCode, status, date, topicTaught } = params;

    // Update preset counts
    if (!STUDENT_ATTENDANCE_PRESETS[studentId]) {
      STUDENT_ATTENDANCE_PRESETS[studentId] = {};
    }
    if (!STUDENT_ATTENDANCE_PRESETS[studentId][subjectCode]) {
      STUDENT_ATTENDANCE_PRESETS[studentId][subjectCode] = { attended: 15, missed: 5 };
    }

    if (status === 'Present') {
      STUDENT_ATTENDANCE_PRESETS[studentId][subjectCode].attended += 1;
    } else {
      STUDENT_ATTENDANCE_PRESETS[studentId][subjectCode].missed += 1;
    }

    // Record entry
    this.data.attendanceEntries.push({
      id: `ATT-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      studentId,
      subjectCode,
      date,
      status,
      topicTaught: topicTaught || 'Regular Lecture',
    });

    // Check if there is an existing lecture on this date
    const lec = this.data.lectures.find(
      (l) => l.subjectCode === subjectCode && l.date === date
    );
    if (lec) {
      lec.attendanceMap[studentId] = status;
    }

    const { attended, missed } = STUDENT_ATTENDANCE_PRESETS[studentId][subjectCode];
    const total = attended + missed;
    const newPercentage = total > 0 ? Math.round((attended / total) * 100) : 0;

    this.save();
    return { success: true, newPercentage };
  }

  public addAssignment(assignmentData: Omit<Assignment, 'id' | 'status' | 'completionPercentage'>): Assignment {
    const id = `ASN${String(this.data.assignments.length + 1).padStart(3, '0')}`;
    const newAsn: Assignment = {
      ...assignmentData,
      id,
      status: 'Pending',
      completionPercentage: 0,
    };
    this.data.assignments.unshift(newAsn);
    this.save();
    return newAsn;
  }

  public updateAssignmentStatus(
    id: string,
    status: AssignmentStatus,
    completionPercentage?: number
  ): Assignment | null {
    const asn = this.data.assignments.find((a) => a.id === id);
    if (!asn) return null;
    asn.status = status;
    if (completionPercentage !== undefined) {
      asn.completionPercentage = completionPercentage;
    } else if (status === 'Completed') {
      asn.completionPercentage = 100;
    } else if (status === 'In Progress' && asn.completionPercentage === 0) {
      asn.completionPercentage = 50;
    }
    this.save();
    return asn;
  }

  public addExam(examData: Omit<Exam, 'id' | 'syllabusProgress' | 'prepProgress'> & { syllabusProgress?: number; prepProgress?: number }): Exam {
    const id = `EXAM${String(this.data.exams.length + 1).padStart(3, '0')}`;
    const newExam: Exam = {
      id,
      syllabusProgress: examData.syllabusProgress ?? 50,
      prepProgress: examData.prepProgress ?? 40,
      ...examData,
    };
    this.data.exams.push(newExam);
    this.save();
    return newExam;
  }

  public updateExam(id: string, updates: Partial<Exam>): Exam | null {
    const exam = this.data.exams.find((e) => e.id === id);
    if (!exam) return null;
    Object.assign(exam, updates);
    this.save();
    return exam;
  }

  public addLecture(lectureData: Omit<Lecture, 'id' | 'attendanceMap'> & { attendanceMap?: Record<string, AttendanceStatus> }): Lecture {
    const id = `LEC${String(this.data.lectures.length + 1).padStart(3, '0')}`;
    const defaultAttendance: Record<string, AttendanceStatus> = {};
    for (const student of this.data.students) {
      defaultAttendance[student.id] = 'Present';
    }

    const newLecture: Lecture = {
      id,
      date: lectureData.date,
      subjectCode: lectureData.subjectCode,
      subjectName: lectureData.subjectName,
      facultyName: lectureData.facultyName,
      topic: lectureData.topic,
      notesAvailable: lectureData.notesAvailable,
      notesContent: lectureData.notesContent,
      attendanceMap: lectureData.attendanceMap || defaultAttendance,
    };

    this.data.lectures.unshift(newLecture);
    this.save();
    return newLecture;
  }

  public updateProgressTopic(
    studentId: string,
    subjectCode: string,
    topic: string,
    markCompleted: boolean
  ): boolean {
    const list = this.data.progress[studentId];
    if (!list) return false;
    const subProg = list.find((p) => p.subjectCode === subjectCode);
    if (!subProg) return false;

    if (markCompleted) {
      if (!subProg.completedTopics.includes(topic)) {
        subProg.completedTopics.push(topic);
        subProg.remainingTopics = subProg.remainingTopics.filter((t) => t !== topic);
      }
    } else {
      if (!subProg.remainingTopics.includes(topic)) {
        subProg.remainingTopics.push(topic);
        subProg.completedTopics = subProg.completedTopics.filter((t) => t !== topic);
      }
    }
    this.save();
    return true;
  }

  public resetDatabase(): void {
    const seeded = this.seedDatabase();
    this.data = seeded;
    this.save(seeded);
  }
}

export const academicDB = new AcademicDB();
