import { GoogleGenAI } from '@google/genai';
import { StudentFullData } from '../src/types/academic.js';

let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

export function buildStudentContextPrompt(data: StudentFullData): string {
  const { student, attendanceSummary, assignments, exams, lectures, progress } = data;

  const attendanceStr = attendanceSummary.subjectStats
    .map(
      (s) =>
        `- ${s.subjectName} (${s.subjectCode}): ${s.percentage}% (${s.attended} attended, ${s.missed} missed out of ${s.total})${
          s.isLow ? ` [CRITICAL WARNING: Needs ${s.neededFor75} consecutive classes for 75%]` : ''
        }`
    )
    .join('\n');

  const pendingAssignmentsStr = assignments
    .filter((a) => a.status !== 'Completed')
    .map(
      (a) =>
        `- "${a.title}" in ${a.subjectName} | Status: ${a.status} (${a.completionPercentage}% done) | Due: ${a.deadline} (${a.daysRemaining} days remaining)${
          a.isUrgent ? ' [URGENT]' : ''
        }`
    )
    .join('\n') || 'None. All assignments completed!';

  const examsStr = exams
    .map(
      (e) =>
        `- ${e.subjectName} (${e.subjectCode}): Exam on ${e.examDate} (${e.daysRemaining} days left). Prep: ${e.prepProgress}%, Syllabus Covered: ${e.syllabusProgress}%. Topics: ${e.syllabusTopics.slice(0, 3).join(', ')}...`
    )
    .join('\n');

  const missedLecturesStr = lectures
    .filter((l) => l.status === 'Absent')
    .map(
      (l) =>
        `- Date: ${l.date} | Subject: ${l.subjectName} | Topic: "${l.topic}" | Notes: ${l.notesAvailable ? 'Available' : 'None'}`
    )
    .join('\n') || 'No recent missed lectures.';

  const weakSubjectsStr = student.weakSubjects && student.weakSubjects.length > 0
    ? student.weakSubjects
        .map((code) => {
          const sub = data.subjects.find((s) => s.code === code);
          return sub ? `${sub.name} (${code})` : code;
        })
        .join(', ')
    : 'None flagged.';

  const progressStr = progress.subjects
    .map(
      (p) =>
        `- ${p.subjectName}: ${p.completedTopics.length}/${p.totalTopicsCount} topics covered. Logged study hours: ${p.studyHoursLogged}h.`
    )
    .join('\n');

  return `STUDENT ACADEMIC PROFILE (DO NOT HALLUCINATE OR DEVIATE FROM THIS DATA):
- Student Name: ${student.name}
- Student ID: ${student.id} | Roll No: ${student.rollNo}
- Course: ${student.course}, Semester: ${student.semester}, Division: ${student.division}
- CGPA: ${student.cgpa} | Faculty Mentor: ${student.mentor}
- Weak Subjects: ${weakSubjectsStr}

ATTENDANCE STATS (OVERALL: ${attendanceSummary.overallPercentage}% | Attended: ${attendanceSummary.totalAttended}/${attendanceSummary.totalClasses}):
${attendanceStr}

ASSIGNMENTS:
${pendingAssignmentsStr}

EXAM SCHEDULE:
${examsStr}

RECENT MISSED LECTURES:
${missedLecturesStr}

SYLLABUS & STUDY PROGRESS (OVERALL: ${progress.overallProgressPercentage}%):
${progressStr}
Total Study Hours Logged: ${progress.totalStudyHours}h.`;
}

export async function askAcademicAssistant(
  userQuery: string,
  studentData: StudentFullData,
  chatHistory: Array<{ role: 'user' | 'model'; text: string }> = []
): Promise<string> {
  const context = buildStudentContextPrompt(studentData);
  const systemInstruction = `You are "AcademiaAI", an intelligent, highly personalized College Academic Advisor and Study Assistant.
You have direct, real-time access to the student's actual database records.

CORE RULES:
1. Always base your advice strictly on the student's REAL stored data provided in the context below. Never invent imaginary subjects, exams, or fake attendance numbers.
2. Address the student by their first name (${studentData.student.name.split(' ')[0]}).
3. Maintain an encouraging, clear, structured, and student-friendly tone.
4. When answering questions like "What is my attendance?", "What should I study today?", "Which assignment to complete first?", or "What did I miss?", cite the exact numbers, subjects, deadlines, and missed topics from their profile.
5. If the student has low attendance (< 75%) or an urgent deadline (due in 1 or 2 days), highlight it prominently with proactive advice.
6. Format your answer with clean Markdown (bold headings, bullet points, clean spacing). Do not use excessive emoji.

${context}`;

  const ai = getAiClient();
  if (ai) {
    try {
      // Build conversation contents
      const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];

      for (const msg of chatHistory.slice(-6)) {
        contents.push({
          role: msg.role === 'model' ? 'model' : 'user',
          parts: [{ text: msg.text }],
        });
      }

      contents.push({
        role: 'user',
        parts: [{ text: userQuery }],
      });

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: contents,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      const text = response.text;
      if (text && text.trim().length > 0) {
        return text;
      }
    } catch (err) {
      console.error('Error in Gemini API call, using intelligent academic fallback:', err);
    }
  }

  // High-accuracy fallback grounded in student data if Gemini API key is missing or errored
  return generateIntelligentFallbackResponse(userQuery, studentData);
}

function generateIntelligentFallbackResponse(query: string, data: StudentFullData): string {
  const q = query.toLowerCase();
  const firstName = data.student.name.split(' ')[0];
  const { attendanceSummary, assignments, exams, lectures, progress } = data;

  const lowAttSubjects = attendanceSummary.subjectStats.filter((s) => s.isLow);
  const pendingAsns = assignments.filter((a) => a.status !== 'Completed');
  const urgentAsns = pendingAsns.filter((a) => a.isUrgent || a.daysRemaining <= 2);
  const nextExam = exams.length > 0 ? exams[0] : null;
  const missedLecs = lectures.filter((l) => l.status === 'Absent');

  if (q.includes('attendance') || q.includes('bunk') || q.includes('shortage')) {
    let resp = `Hello **${firstName}**! Here is your current verified attendance summary:\n\n`;
    resp += `* **Overall Attendance:** **${attendanceSummary.overallPercentage}%** (${attendanceSummary.totalAttended} attended out of ${attendanceSummary.totalClasses} total classes).\n\n`;
    resp += `**Subject Breakdown:**\n`;
    for (const sub of attendanceSummary.subjectStats) {
      const tag = sub.isLow ? `⚠️ **LOW (Warning!)** — Need ${sub.neededFor75} classes to hit 75%` : `✅ Good standing`;
      resp += `- **${sub.subjectName} (${sub.subjectCode}):** ${sub.percentage}% (${sub.attended}/${sub.total}) — ${tag}\n`;
    }
    if (lowAttSubjects.length > 0) {
      resp += `\n> **Urgent Action Required:** You have fallen below the 75% mandatory threshold in **${lowAttSubjects.map((s) => s.subjectName).join(', ')}**. Make sure to attend the upcoming lectures to avoid detention.`;
    }
    return resp;
  }

  if (q.includes('assignment') || q.includes('homework') || q.includes('submission')) {
    if (pendingAsns.length === 0) {
      return `Great news, **${firstName}**! You have **0 pending assignments**. You are completely up to date with your coursework submissions!`;
    }
    let resp = `Hello **${firstName}**, you currently have **${pendingAsns.length} pending assignment(s)**:\n\n`;
    for (const asn of pendingAsns) {
      const urgencyBadge = asn.daysRemaining <= 2 ? `🔥 **URGENT** (Due in ${asn.daysRemaining} days)` : `(Due in ${asn.daysRemaining} days)`;
      resp += `1. **${asn.title}** (${asn.subjectName})\n   - **Deadline:** ${asn.deadline} ${urgencyBadge}\n   - **Faculty:** ${asn.facultyName}\n   - **Progress:** ${asn.completionPercentage}% completed\n\n`;
    }
    resp += `\n**Recommendation:** Complete **${pendingAsns[0].title}** first as its deadline is nearest!`;
    return resp;
  }

  if (q.includes('exam') || q.includes('test') || q.includes('midterm') || q.includes('date')) {
    if (!nextExam) {
      return `Hello **${firstName}**, no upcoming exams are scheduled in the portal at the moment.`;
    }
    let resp = `Hello **${firstName}**, here is your upcoming exam schedule:\n\n`;
    for (const ex of exams) {
      resp += `- **${ex.subjectName} (${ex.subjectCode}):**\n  - **Date:** ${ex.examDate} (**${ex.daysRemaining} days remaining**)\n  - **Room:** ${ex.room}\n  - **Preparation Status:** ${ex.prepProgress}%\n  - **Syllabus Covered:** ${ex.syllabusProgress}%\n\n`;
    }
    resp += `Your immediate focus should be **${nextExam.subjectName}** which takes place in **${nextExam.daysRemaining} days**!`;
    return resp;
  }

  if (q.includes('miss') || q.includes('absent') || q.includes('notes')) {
    if (missedLecs.length === 0) {
      return `Good news, **${firstName}**! According to your college logs, you have not missed any recent registered lectures!`;
    }
    let resp = `Here are the classes you missed recently, **${firstName}**:\n\n`;
    for (const lec of missedLecs) {
      resp += `- **${lec.date} — ${lec.subjectName}**\n  - **Topic Taught:** "${lec.topic}"\n  - **Faculty:** ${lec.facultyName}\n  - **Lecture Notes:** ${lec.notesAvailable ? '✅ **Available for viewing** in the Lectures & Notes tab' : 'Not uploaded yet'}\n\n`;
    }
    resp += `I recommend reviewing the available notes to bridge your conceptual gaps before the upcoming exams!`;
    return resp;
  }

  if (q.includes('3 hour') || q.includes('study plan') || q.includes('today') || q.includes('schedule') || q.includes('plan')) {
    const focusSub = nextExam ? nextExam.subjectName : 'Operating Systems';
    const urgentAsn = urgentAsns[0] ? urgentAsns[0].subjectName : 'DBMS';
    return `Here is a high-yield **Personalized 3-Hour Study Schedule** tailored for you today, **${firstName}**:\n\n` +
      `* **Block 1 (60 mins) — ${focusSub} (Exam Prep):**\n  - Focus: Core theoretical algorithms and solved numericals for your upcoming exam in ${nextExam?.daysRemaining || 12} days.\n` +
      `* **Block 2 (45 mins) — ${urgentAsn} (Urgent Assignment Work):**\n  - Focus: Finish remaining diagrams and code logic for your pending submission.\n` +
      `* **Break (15 mins):** Hydrate, rest your eyes, step away from screens.\n` +
      `* **Block 3 (45 mins) — Theory of Computation / Weak Subject:**\n  - Focus: Practice 2 theorem proofs or regular expression conversions.\n` +
      `* **Block 4 (30 mins) — Quick Revision & Quiz:**\n  - Review lecture notes from recent classes.\n\n` +
      `You can generate full 7-day or 1-month plans on the dedicated **Study Planner** page!`;
  }

  if (q.includes('behind') || q.includes('weak') || q.includes('low') || q.includes('lagging')) {
    let resp = `Based on your academic profile, **${firstName}**:\n\n`;
    if (lowAttSubjects.length > 0) {
      resp += `* **Attendance Concerns:** You are behind in attendance for **${lowAttSubjects.map((s) => `${s.subjectName} (${s.percentage}%)`).join(', ')}**.\n`;
    }
    if (data.student.weakSubjects && data.student.weakSubjects.length > 0) {
      const weakNames = data.student.weakSubjects
        .map((code) => data.subjects.find((s) => s.code === code)?.name || code)
        .join(', ');
      resp += `* **Identified Weak Subject(s):** **${weakNames}**.\n`;
    }
    const lowestPrepExam = [...exams].sort((a, b) => a.prepProgress - b.prepProgress)[0];
    if (lowestPrepExam) {
      resp += `* **Exam Readiness:** **${lowestPrepExam.subjectName}** has the lowest preparation progress at **${lowestPrepExam.prepProgress}%**.\n`;
    }
    resp += `\n**Action Plan:** Allocate an extra 45 minutes daily to ${data.student.weakSubjects?.[0] ? data.subjects.find(s => s.code === data.student.weakSubjects?.[0])?.name : 'your weaker subjects'} and ensure you do not miss any more lectures this week.`;
    return resp;
  }

  // General "How am I doing?" or greeting
  let summary = `Hello **${firstName}**! Here is your personalized academic overview:\n\n`;
  summary += `* **Overall Attendance:** **${attendanceSummary.overallPercentage}%** (${attendanceSummary.totalAttended}/${attendanceSummary.totalClasses} classes attended).\n`;
  summary += `* **Pending Assignments:** **${pendingAsns.length} pending**${urgentAsns.length > 0 ? ` (${urgentAsns.length} urgent!)` : ''}.\n`;
  if (nextExam) {
    summary += `* **Next Exam:** **${nextExam.subjectName}** in **${nextExam.daysRemaining} days** (${nextExam.examDate}) with **${nextExam.prepProgress}%** preparation completed.\n`;
  }
  summary += `* **Syllabus Completion:** You have completed **${progress.overallProgressPercentage}%** of your semester coursework.\n\n`;

  if (urgentAsns.length > 0) {
    summary += `> **Immediate Priority:** Your ${urgentAsns[0].subjectName} assignment ("${urgentAsns[0].title}") is due soon! Let's get that finished today.\n\n`;
  } else if (lowAttSubjects.length > 0) {
    summary += `> **Caution:** Keep an eye on ${lowAttSubjects[0].subjectName} attendance (${lowAttSubjects[0].percentage}%).\n\n`;
  }

  summary += `Feel free to ask me for custom study schedules, lecture catch-ups, or revision plans!`;
  return summary;
}

export async function generatePersonalizedStudyPlan(
  studentData: StudentFullData,
  params: {
    dailyHours: number;
    planType: '1-day' | '7-day' | '1-month';
    weakSubjects?: string[];
    focusSubjects?: string[];
  }
) {
  const { dailyHours, planType, weakSubjects = [], focusSubjects = [] } = params;
  const firstName = studentData.student.name.split(' ')[0];

  const ai = getAiClient();
  const context = buildStudentContextPrompt(studentData);

  const prompt = `Generate a highly practical, personalized ${planType} study schedule for ${studentData.student.name}.
Parameters:
- Available study hours per day: ${dailyHours} hours
- Plan Duration: ${planType}
- Target/Focus subjects: ${focusSubjects.length ? focusSubjects.join(', ') : 'All enrolled subjects'}
- Weak/Challenging subjects: ${weakSubjects.length ? weakSubjects.join(', ') : studentData.student.weakSubjects?.join(', ') || 'None'}
- Upcoming exams and pending assignments from student context.

Please respond in JSON format matching this schema:
{
  "summary": "Brief encouraging summary of this plan",
  "schedule": [
    {
      "periodLabel": "e.g. Day 1 (Monday) or Morning / Afternoon / Evening",
      "items": [
        {
          "timeBlock": "e.g. 09:00 AM - 10:15 AM",
          "subject": "Subject Name",
          "topic": "Specific Topic",
          "duration": "1h 15m",
          "focusTip": "Actionable study tip"
        }
      ]
    }
  ]
}`;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction: `You are an expert college academic planner. Return strictly valid JSON adhering to the requested schema based on the student data.\n${context}`,
          responseMimeType: 'application/json',
        },
      });

      const text = response.text?.trim();
      if (text) {
        const parsed = JSON.parse(text);
        return parsed;
      }
    } catch (err) {
      console.error('Error generating AI study plan, using rule-based plan generator:', err);
    }
  }

  // Fallback high-quality structured generator
  return generateDeterministicStudyPlan(studentData, dailyHours, planType, weakSubjects, focusSubjects);
}

function generateDeterministicStudyPlan(
  data: StudentFullData,
  dailyHours: number,
  planType: '1-day' | '7-day' | '1-month',
  weakSubjects: string[],
  focusSubjects: string[]
) {
  const enrolled = data.subjects;
  const nextExam = data.exams[0];
  const pendingAsn = data.assignments.find((a) => a.status !== 'Completed');

  if (planType === '1-day') {
    const hours = Math.max(1, dailyHours);
    const sub1 = nextExam ? nextExam.subjectName : enrolled[0].name;
    const sub2 = weakSubjects.length > 0 ? (enrolled.find(s => s.code === weakSubjects[0])?.name || enrolled[1].name) : enrolled[1].name;
    const sub3 = pendingAsn ? pendingAsn.subjectName : (enrolled[2]?.name || enrolled[0].name);

    const items = [
      {
        timeBlock: 'Block 1 · 09:00 AM - 10:15 AM',
        subject: sub1,
        topic: nextExam?.syllabusTopics[0] || 'Core Concepts & Scheduling',
        duration: '1h 15m',
        focusTip: 'Active recall and solving past year university exam problems.',
      },
      {
        timeBlock: 'Block 2 · 10:30 AM - 11:30 AM',
        subject: sub2,
        topic: 'Weak Area Revision & Foundational Proofs',
        duration: '1h 00m',
        focusTip: 'Break complex formulas into handwritten summary cards.',
      },
    ];

    if (hours >= 3) {
      items.push({
        timeBlock: 'Block 3 · 02:00 PM - 03:00 PM',
        subject: sub3,
        topic: pendingAsn ? `Assignment Work: ${pendingAsn.title}` : 'Practical Lab Coding',
        duration: '1h 00m',
        focusTip: 'Test edge cases and ensure clean documentation before submission.',
      });
    }

    if (hours >= 4) {
      items.push({
        timeBlock: 'Block 4 · 05:00 PM - 05:45 PM',
        subject: sub1,
        topic: 'Quick Flashcard Review & Self-Quiz',
        duration: '45m',
        focusTip: 'Check lecture notes from recent classes to fill any gaps.',
      });
    }

    return {
      summary: `Tailored ${dailyHours}-hour single-day intensive study schedule focusing on your upcoming ${sub1} exam and key assignment milestones.`,
      schedule: [
        {
          periodLabel: 'Today (Intensive Schedule)',
          items,
        },
      ],
    };
  }

  if (planType === '7-day') {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const schedule = days.map((day, idx) => {
      const sub = enrolled[idx % enrolled.length];
      const examSub = data.exams[idx % data.exams.length]?.subjectName || sub.name;
      return {
        periodLabel: `${day}`,
        items: [
          {
            timeBlock: 'Session 1 (Morning)',
            subject: examSub,
            topic: `Module ${((idx % 4) + 1)}: Theory & Solved Numericals`,
            duration: `${Math.round(dailyHours * 0.6 * 60)}m`,
            focusTip: 'Review textbook worked examples and lecture notes.',
          },
          {
            timeBlock: 'Session 2 (Evening)',
            subject: sub.name,
            topic: `Revision, Assignment & Lab Prep`,
            duration: `${Math.round(dailyHours * 0.4 * 60)}m`,
            focusTip: 'Solve at least 5 practice questions or assignment problems.',
          },
        ],
      };
    });

    return {
      summary: `Comprehensive 7-Day sprint balancing all 5 semester subjects, targeting upcoming exams and clearing assignment backlogs.`,
      schedule,
    };
  }

  // 1-month plan
  const weeks = [
    {
      periodLabel: 'Week 1: Fundamentals & Immediate Exam Deadlines',
      items: [
        {
          timeBlock: 'Daily 2-3 Hours',
          subject: data.exams[0]?.subjectName || 'Operating Systems',
          topic: 'High weightage syllabus modules (Scheduling, Paging, Deadlocks)',
          duration: `${dailyHours}h / day`,
          focusTip: 'Consolidate lecture notes and complete pending assignments due this week.',
        },
      ],
    },
    {
      periodLabel: 'Week 2: Deep Dive into Weaker Subjects',
      items: [
        {
          timeBlock: 'Daily 2-3 Hours',
          subject: enrolled[1]?.name || 'Database Management Systems',
          topic: 'Normalization (3NF, BCNF) and Relational Algebra',
          duration: `${dailyHours}h / day`,
          focusTip: 'Solve previous year university papers under timed conditions.',
        },
      ],
    },
    {
      periodLabel: 'Week 3: Advanced Topics & Networking / Automata',
      items: [
        {
          timeBlock: 'Daily 2-3 Hours',
          subject: enrolled[2]?.name || 'Computer Networks',
          topic: 'Subnetting, Routing algorithms, and Pushdown Automata',
          duration: `${dailyHours}h / day`,
          focusTip: 'Focus on diagrammatic representations and step-by-step algorithms.',
        },
      ],
    },
    {
      periodLabel: 'Week 4: Full Revision & Mock Tests',
      items: [
        {
          timeBlock: 'Daily 2-3 Hours',
          subject: 'All 5 Core Subjects',
          topic: 'Rapid revision cards, formula sheets, and 2 full-length mock tests',
          duration: `${dailyHours}h / day`,
          focusTip: 'Identify lingering weak points and discuss doubts with course faculty.',
        },
      ],
    },
  ];

  return {
    summary: `Structured 4-Week semester study roadmap calibrated against your academic progress (${data.progress.overallProgressPercentage}% completed) and upcoming test dates.`,
    schedule: weeks,
  };
}
