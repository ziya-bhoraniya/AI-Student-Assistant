/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { api } from './services/api.js';
import {
  Student,
  Faculty,
  Subject,
  StudentFullData,
} from './types/academic.js';
import { Navbar } from './components/Navbar.js';
import { Sidebar, NavPageId } from './components/Sidebar.js';
import { LoginPage } from './components/LoginPage.js';
import { HomePage } from './pages/HomePage.js';
import { AttendancePage } from './pages/AttendancePage.js';
import { AssignmentsPage } from './pages/AssignmentsPage.js';
import { ExamsPage } from './pages/ExamsPage.js';
import { StudyPlannerPage } from './pages/StudyPlannerPage.js';
import { LecturesNotesPage } from './pages/LecturesNotesPage.js';
import { ProgressPage } from './pages/ProgressPage.js';
import { ProfilePage } from './pages/ProfilePage.js';
import { FacultyDashboardPage } from './pages/FacultyDashboardPage.js';
import { PythonExportModal } from './components/PythonExportModal.js';

export default function App() {
  // App state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true);
  const [currentRole, setCurrentRole] = useState<'student' | 'faculty'>('student');
  const [currentStudentId, setCurrentStudentId] = useState<string>('STU101');
  const [currentPage, setCurrentPage] = useState<NavPageId>('home');
  const [showPythonModal, setShowPythonModal] = useState<boolean>(false);

  // Data state
  const [studentsList, setStudentsList] = useState<Student[]>([]);
  const [facultyList, setFacultyList] = useState<Faculty[]>([]);
  const [subjectsList, setSubjectsList] = useState<Subject[]>([]);
  const [studentData, setStudentData] = useState<StudentFullData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Initial load
  const loadInitialData = useCallback(async () => {
    try {
      setLoading(true);
      const [students, faculty, subjects] = await Promise.all([
        api.getStudents(),
        api.getFaculty(),
        api.getSubjects(),
      ]);
      setStudentsList(students);
      setFacultyList(faculty);
      setSubjectsList(subjects);

      // Load active student data
      if (students.length > 0) {
        const targetId = currentStudentId || students[0].id;
        const fullData = await api.getStudentFullData(targetId);
        setStudentData(fullData);
      }
      setError(null);
    } catch (err: any) {
      console.error('Failed to load initial academic data:', err);
      setError('Could not connect to the academic database. Please try reloading.');
    } finally {
      setLoading(false);
    }
  }, [currentStudentId]);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  // Refresh active student data after mutations
  const refreshStudentData = useCallback(async () => {
    try {
      const fullData = await api.getStudentFullData(currentStudentId);
      setStudentData(fullData);
      const students = await api.getStudents();
      setStudentsList(students);
    } catch (err) {
      console.error('Failed to refresh student data:', err);
    }
  }, [currentStudentId]);

  // Switch student
  const handleSelectStudent = async (id: string) => {
    setCurrentStudentId(id);
    setLoading(true);
    try {
      const fullData = await api.getStudentFullData(id);
      setStudentData(fullData);
      setCurrentRole('student');
    } catch (err) {
      console.error('Failed to load student:', err);
    } finally {
      setLoading(false);
    }
  };

  // Switch role
  const handleSwitchRole = (newRole: 'student' | 'faculty') => {
    setCurrentRole(newRole);
    if (newRole === 'faculty') {
      setCurrentPage('faculty');
    } else {
      setCurrentPage('home');
    }
  };

  // Reset database
  const handleResetDb = async () => {
    if (window.confirm('Reset database to the original 10 sample students?')) {
      try {
        await api.resetDatabase();
        await loadInitialData();
      } catch (err) {
        console.error('Failed to reset DB:', err);
      }
    }
  };

  // Login handler
  const handleLogin = async (role: 'student' | 'faculty', id: string) => {
    setCurrentRole(role);
    if (role === 'student') {
      setCurrentStudentId(id);
      setCurrentPage('home');
      try {
        const full = await api.getStudentFullData(id);
        setStudentData(full);
      } catch (e) {
        console.error(e);
      }
    } else {
      setCurrentPage('faculty');
    }
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  if (!isAuthenticated) {
    return (
      <LoginPage
        students={studentsList}
        facultyList={facultyList}
        onLogin={handleLogin}
      />
    );
  }

  if (loading && !studentData) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-indigo-600 border-t-transparent mx-auto" />
          <p className="text-xs font-semibold text-slate-700">Connecting to AcademiaAI Academic Engine...</p>
        </div>
      </div>
    );
  }

  const currentFaculty = facultyList[0] || null;
  const currentStudent = studentData?.student || studentsList[0] || null;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col antialiased text-slate-800">
      {/* Top Navigation */}
      <Navbar
        currentRole={currentRole}
        currentStudent={currentStudent}
        currentFaculty={currentFaculty}
        studentsList={studentsList}
        onSelectStudent={handleSelectStudent}
        onSwitchRole={handleSwitchRole}
        onOpenPythonGuide={() => setShowPythonModal(true)}
        onResetDb={handleResetDb}
        onLogout={handleLogout}
      />

      {/* Main Workspace Layout */}
      <div className="flex-1 flex flex-col lg:flex-row max-w-7xl w-full mx-auto">
        {/* Sidebar */}
        <Sidebar
          currentPage={currentPage}
          onSelectPage={(page) => {
            if (page === 'python_guide') {
              setShowPythonModal(true);
            } else {
              setCurrentPage(page);
            }
          }}
          currentRole={currentRole}
          pendingAssignmentsCount={
            studentData?.assignments.filter((a) => a.status !== 'Completed').length || 0
          }
          lowAttendanceCount={
            studentData?.attendanceSummary.subjectStats.filter((s) => s.isLow).length || 0
          }
          upcomingExamsCount={studentData?.exams.length || 0}
        />

        {/* Content Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0">
          {error && (
            <div className="mb-4 rounded-xl border border-rose-200 bg-rose-50 p-4 text-xs text-rose-800">
              {error}
            </div>
          )}

          {/* Student Pages */}
          {currentRole === 'student' && studentData && (
            <>
              {currentPage === 'home' && (
                <HomePage
                  data={studentData}
                  onNavigatePage={(pageId) => setCurrentPage(pageId)}
                  onRefreshData={refreshStudentData}
                />
              )}

              {currentPage === 'attendance' && (
                <AttendancePage data={studentData} />
              )}

              {currentPage === 'assignments' && (
                <AssignmentsPage
                  data={studentData}
                  onRefreshData={refreshStudentData}
                />
              )}

              {currentPage === 'exams' && (
                <ExamsPage
                  data={studentData}
                  onRefreshData={refreshStudentData}
                />
              )}

              {currentPage === 'study_planner' && (
                <StudyPlannerPage data={studentData} />
              )}

              {currentPage === 'lectures_notes' && (
                <LecturesNotesPage data={studentData} />
              )}

              {currentPage === 'progress' && (
                <ProgressPage
                  data={studentData}
                  onRefreshData={refreshStudentData}
                />
              )}

              {currentPage === 'profile' && (
                <ProfilePage data={studentData} />
              )}

              {currentPage === 'faculty' && (
                <FacultyDashboardPage
                  currentFaculty={currentFaculty}
                  students={studentsList}
                  subjects={subjectsList}
                  onRefreshData={refreshStudentData}
                  onSelectStudentForInspection={(id) => {
                    handleSelectStudent(id);
                    setCurrentPage('home');
                  }}
                />
              )}
            </>
          )}

          {/* Faculty Dashboard View */}
          {currentRole === 'faculty' && (
            <FacultyDashboardPage
              currentFaculty={currentFaculty}
              students={studentsList}
              subjects={subjectsList}
              onRefreshData={refreshStudentData}
              onSelectStudentForInspection={(id) => {
                handleSelectStudent(id);
                setCurrentRole('student');
                setCurrentPage('home');
              }}
            />
          )}
        </main>
      </div>

      {/* Python Source Files & VS Code Setup Modal */}
      <PythonExportModal
        isOpen={showPythonModal}
        onClose={() => setShowPythonModal(false)}
      />
    </div>
  );
}
