import React, { useState } from 'react';
import {
  GraduationCap,
  ShieldCheck,
  ArrowRight,
  User,
} from 'lucide-react';
import { Student, Faculty } from '../types/academic.js';

interface LoginPageProps {
  students: Student[];
  facultyList: Faculty[];
  onLogin: (role: 'student' | 'faculty', id: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  students,
  facultyList,
  onLogin,
}) => {
  const [role, setRole] = useState<'student' | 'faculty'>('student');
  const [userId, setUserId] = useState(role === 'student' ? 'STU101' : 'FAC001');
  const [password, setPassword] = useState('password123');

  const handleRoleChange = (newRole: 'student' | 'faculty') => {
    setRole(newRole);
    setUserId(newRole === 'student' ? (students[0]?.id || 'STU101') : (facultyList[0]?.id || 'FAC001'));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(role, userId);
  };

  const DEMO_PRESETS = [
    {
      id: 'STU101',
      name: 'Aarav Sharma',
      desc: '88% Attendance · Balanced Performer',
      tag: 'Regular',
      role: 'student' as const,
    },
    {
      id: 'STU103',
      name: 'Rohan Verma',
      desc: '68% Attendance (Low Alert) · 3 Pending Assignments',
      tag: 'Low Attendance',
      role: 'student' as const,
    },
    {
      id: 'STU102',
      name: 'Priya Patel',
      desc: '74% Borderline Attendance · Missed CN Lecture',
      tag: 'Borderline',
      role: 'student' as const,
    },
    {
      id: 'STU104',
      name: 'Ananya Iyer',
      desc: '94% Attendance · Top Scholar (CGPA 9.45)',
      tag: 'High Achiever',
      role: 'student' as const,
    },
    {
      id: 'FAC001',
      name: 'Prof. Rajesh Mehta',
      desc: 'Faculty Head · Manages Attendance, Exams, Lectures',
      tag: 'Faculty Admin',
      role: 'faculty' as const,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-blue-600 text-white shadow-xs">
          <GraduationCap className="h-6 w-6" />
        </div>
        <h1 className="mt-3 text-2xl font-bold text-slate-900 tracking-tight">
          AcademiaAI Portal
        </h1>
        <p className="mt-1 text-xs text-slate-500">
          Faculty Academic Management & Student AI Assistant
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4 sm:px-0">
        <div className="bg-white py-8 px-6 shadow-xs border border-slate-200 rounded-2xl sm:px-8 space-y-6">
          {/* Role Toggle Tabs */}
          <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              onClick={() => handleRoleChange('student')}
              className={`flex items-center justify-center gap-2 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                role === 'student'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <User className="h-4 w-4" />
              <span>Student Login</span>
            </button>
            <button
              type="button"
              onClick={() => handleRoleChange('faculty')}
              className={`flex items-center justify-center gap-2 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                role === 'faculty'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ShieldCheck className="h-4 w-4" />
              <span>Faculty Login</span>
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="user-select" className="block text-xs font-semibold text-slate-700 mb-1">
                {role === 'student' ? 'Select Student Account:' : 'Select Faculty Account:'}
              </label>
              {role === 'student' ? (
                <select
                  id="user-select"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-medium bg-white"
                >
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.id}) · Div {s.division}
                    </option>
                  ))}
                </select>
              ) : (
                <select
                  id="user-select"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-medium bg-white"
                >
                  {facultyList.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.name} ({f.id}) · {f.department}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div>
              <label htmlFor="password-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Password:
              </label>
              <input
                id="password-input"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 bg-white"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Demo password: <span className="font-mono">password123</span>
              </p>
            </div>

            <button
              type="submit"
              className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 py-2.5 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition-colors cursor-pointer"
            >
              <span>Sign In to {role === 'student' ? 'Student Workspace' : 'Faculty Dashboard'}</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </form>

          {/* Quick Demo Profiles */}
          <div className="pt-4 border-t border-slate-200">
            <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Quick Switch Scenarios:
            </p>
            <div className="space-y-1.5">
              {DEMO_PRESETS.map((demo) => (
                <button
                  key={demo.id}
                  onClick={() => onLogin(demo.role, demo.id)}
                  className="w-full text-left p-2.5 rounded-xl border border-slate-200 hover:border-blue-300 hover:bg-blue-50/40 transition-colors flex items-center justify-between group cursor-pointer"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900 group-hover:text-blue-700">
                        {demo.name}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">({demo.id})</span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">{demo.desc}</p>
                  </div>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700 group-hover:bg-blue-100 group-hover:text-blue-800">
                    {demo.tag}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
