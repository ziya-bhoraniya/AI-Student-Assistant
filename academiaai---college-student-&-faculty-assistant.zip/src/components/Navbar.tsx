import React from 'react';
import {
  GraduationCap,
  Users,
  UserCheck,
  RotateCcw,
  Code2,
  LogOut,
  ChevronDown,
} from 'lucide-react';
import { Student, Faculty } from '../types/academic.js';

interface NavbarProps {
  currentRole: 'student' | 'faculty';
  currentStudent: Student | null;
  currentFaculty: Faculty | null;
  studentsList: Student[];
  onSelectStudent: (id: string) => void;
  onSwitchRole: (role: 'student' | 'faculty') => void;
  onOpenPythonGuide: () => void;
  onResetDb: () => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  currentStudent,
  currentFaculty,
  studentsList,
  onSelectStudent,
  onSwitchRole,
  onOpenPythonGuide,
  onResetDb,
  onLogout,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 bg-white/95 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-xs">
            <GraduationCap className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold tracking-tight text-slate-900">AcademiaAI</span>
              <span className="text-[10px] font-medium tracking-wide uppercase text-indigo-700 bg-indigo-50 border border-indigo-100/80 rounded-md px-1.5 py-0.5">
                Portal
              </span>
            </div>
            <p className="text-[11px] text-slate-500 hidden sm:block">Academic Management & Student AI</p>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Student Switcher for Quick Demo */}
          {currentRole === 'student' && studentsList.length > 0 && (
            <div className="relative hidden md:flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50/70 px-2.5 py-1 text-xs text-slate-600">
              <span className="text-slate-400 font-medium text-[11px]">Demo:</span>
              <select
                value={currentStudent?.id || ''}
                onChange={(e) => onSelectStudent(e.target.value)}
                className="bg-transparent font-medium text-slate-800 focus:outline-none cursor-pointer pr-3 text-xs"
              >
                {studentsList.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.id}) · Div {s.division}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Role Toggle Button */}
          <button
            onClick={() => onSwitchRole(currentRole === 'student' ? 'faculty' : 'student')}
            className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 hover:text-slate-900 transition-colors shadow-2xs"
            title="Switch between Student & Faculty View"
          >
            {currentRole === 'student' ? (
              <>
                <Users className="h-3.5 w-3.5 text-indigo-600" />
                <span className="hidden sm:inline">Faculty View</span>
                <span className="sm:hidden">Faculty</span>
              </>
            ) : (
              <>
                <UserCheck className="h-3.5 w-3.5 text-indigo-600" />
                <span className="hidden sm:inline">Student View</span>
                <span className="sm:hidden">Student</span>
              </>
            )}
          </button>

          {/* VS Code & Python Exporter Modal */}
          <button
            onClick={onOpenPythonGuide}
            className="hidden sm:flex items-center gap-1.5 rounded-lg border border-indigo-200/80 bg-indigo-50/60 px-3 py-1.5 text-xs font-medium text-indigo-700 hover:bg-indigo-100/70 transition-colors"
            title="View & Export Python/Streamlit + SQLite project files"
          >
            <Code2 className="h-3.5 w-3.5 text-indigo-600" />
            <span>Python Files</span>
          </button>

          {/* Reset Demo DB */}
          <button
            onClick={onResetDb}
            className="flex items-center gap-1 rounded-lg border border-slate-200 p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-50 transition-colors"
            title="Reset Database to 10 sample students"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </button>

          {/* User Badge & Logout */}
          <div className="flex items-center gap-2 border-l border-slate-200 pl-2.5">
            <div className="text-right hidden sm:block">
              <p className="text-xs font-semibold text-slate-800 leading-tight">
                {currentRole === 'student' ? currentStudent?.name : currentFaculty?.name}
              </p>
              <p className="text-[10px] text-slate-400 leading-none">
                {currentRole === 'student' ? `${currentStudent?.id}` : 'Faculty Head'}
              </p>
            </div>
            <button
              onClick={onLogout}
              className="rounded-lg p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50/80 transition-colors"
              title="Logout"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
