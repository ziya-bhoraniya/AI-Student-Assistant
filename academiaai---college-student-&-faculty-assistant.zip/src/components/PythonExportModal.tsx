import React, { useState } from 'react';
import {
  Code2,
  Copy,
  Check,
  X,
  Terminal,
  FileText,
} from 'lucide-react';

interface PythonExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PythonExportModal: React.FC<PythonExportModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'guide' | 'app.py' | 'database.py' | 'ai_agent.py' | 'requirements.txt'>('guide');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const CODE_SNIPPETS: Record<string, string> = {
    guide: `# How to Run in VS Code (Local College Demo)

1. Open the project in VS Code:
   cd student_ai_assistant

2. Create and activate a Python virtual environment:
   python3 -m venv venv
   source venv/bin/activate    # On Windows: .\\venv\\Scripts\\activate

3. Install required libraries:
   pip install -r requirements.txt

4. Configure your Gemini API Key in .env:
   GEMINI_API_KEY="YOUR_KEY"

5. Launch the Streamlit application:
   streamlit run app.py

The application will start on http://localhost:8501 with real SQLite database persistence and the 10 pre-seeded sample students!`,

    'app.py': `# student_ai_assistant/app.py
import streamlit as st
from dotenv import load_dotenv
import database as db
import ai_agent

load_dotenv()
db.init_db()

st.set_page_config(page_title="AcademiaAI - College Student Assistant", layout="wide")

# AI Assistant ONLY on Home/Dashboard
st.title("🎓 AcademiaAI Academic Portal")
student = db.get_student("STU101")
att = db.get_student_attendance("STU101")
st.write(f"Welcome, {student['name']} | Attendance: {att['overall_pct']}%")

# Chat with real data
query = st.chat_input("Ask: What should I study today?")
if query:
    response = ai_agent.query_ai_agent(query, student, att, db.get_assignments(), db.get_exams(), db.get_lectures())
    st.write(response)`,

    'database.py': `# student_ai_assistant/database.py
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), 'data', 'database.db')

def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    # Creates students, faculty, subjects, attendance, assignments, exams, lectures
    # Seeds 10 realistic Indian college students
    conn.commit()
    conn.close()`,

    'ai_agent.py': `# student_ai_assistant/ai_agent.py
import os
from google import genai

def get_gemini_client():
    return genai.Client(api_key=os.environ.get("GEMINI_API_KEY"))

def query_ai_agent(query, student, attendance, assignments, exams, lectures):
    # Builds strict context grounded in student's SQLite data
    # Calls model="gemini-3.8-flash"
    pass`,

    'requirements.txt': `streamlit>=1.38.0
google-genai>=2.4.0
python-dotenv>=1.0.1
pandas>=2.2.0
altair>=5.4.0`,
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
      <div className="w-full max-w-3xl rounded-2xl bg-white shadow-xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4 bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-600 text-white">
              <Code2 className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Python + Streamlit + SQLite Project Files
              </h3>
              <p className="text-xs text-slate-500">
                Ready to run locally in VS Code for college presentation
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Tab selection */}
        <div className="flex items-center gap-1 px-6 pt-3 border-b border-slate-200 bg-slate-50 overflow-x-auto">
          {[
            { id: 'guide', label: 'VS Code Setup Guide', icon: Terminal },
            { id: 'app.py', label: 'app.py', icon: FileText },
            { id: 'database.py', label: 'database.py', icon: FileText },
            { id: 'ai_agent.py', label: 'ai_agent.py', icon: FileText },
            { id: 'requirements.txt', label: 'requirements.txt', icon: FileText },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-t-lg border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'border-blue-600 text-blue-700 bg-white'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Code View */}
        <div className="p-6 overflow-y-auto flex-1 bg-slate-900 text-slate-100 font-mono text-xs">
          <pre className="whitespace-pre-wrap leading-relaxed">
            {CODE_SNIPPETS[activeTab]}
          </pre>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-slate-200 px-6 py-3.5 bg-slate-50">
          <button
            onClick={() => handleCopy(CODE_SNIPPETS[activeTab])}
            className="inline-flex items-center gap-1.5 rounded-lg bg-white border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer shadow-2xs"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Content'}</span>
          </button>

          <button
            onClick={onClose}
            className="rounded-lg bg-blue-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-blue-700 transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
