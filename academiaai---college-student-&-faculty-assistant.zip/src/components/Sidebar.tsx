import React from 'react';
import {
  LayoutDashboard,
  CalendarCheck2,
  FileCheck,
  CalendarDays,
  BrainCircuit,
  BookOpen,
  LineChart,
  User,
  ShieldCheck,
  Code2,
} from 'lucide-react';

export type NavPageId =
  | 'home'
  | 'attendance'
  | 'assignments'
  | 'exams'
  | 'study_planner'
  | 'lectures_notes'
  | 'progress'
  | 'profile'
  | 'faculty'
  | 'python_guide';

interface SidebarProps {
  currentPage: NavPageId;
  onSelectPage: (page: NavPageId) => void;
  currentRole: 'student' | 'faculty';
  pendingAssignmentsCount?: number;
  lowAttendanceCount?: number;
  upcomingExamsCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onSelectPage,
  currentRole,
  pendingAssignmentsCount = 0,
  lowAttendanceCount = 0,
  upcomingExamsCount = 0,
}) => {
  const studentNavItems = [
    {
      id: 'home' as NavPageId,
      label: 'Home / AI Assistant',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'attendance' as NavPageId,
      label: 'Attendance',
      icon: CalendarCheck2,
      badge: lowAttendanceCount > 0 ? `${lowAttendanceCount}` : null,
      badgeType: 'warning',
    },
    {
      id: 'assignments' as NavPageId,
      label: 'Assignments',
      icon: FileCheck,
      badge: pendingAssignmentsCount > 0 ? `${pendingAssignmentsCount}` : null,
      badgeType: 'info',
    },
    {
      id: 'exams' as NavPageId,
      label: 'Exams',
      icon: CalendarDays,
      badge: upcomingExamsCount > 0 ? `${upcomingExamsCount}` : null,
      badgeType: 'neutral',
    },
    {
      id: 'study_planner' as NavPageId,
      label: 'Study Planner',
      icon: BrainCircuit,
      badge: null,
    },
    {
      id: 'lectures_notes' as NavPageId,
      label: 'Lectures & Notes',
      icon: BookOpen,
      badge: null,
    },
    {
      id: 'progress' as NavPageId,
      label: 'Progress',
      icon: LineChart,
      badge: null,
    },
    {
      id: 'profile' as NavPageId,
      label: 'Student Profile',
      icon: User,
      badge: null,
    },
  ];

  return (
    <aside className="w-full lg:w-60 shrink-0 border-r border-slate-200/80 bg-white flex flex-col justify-between py-6 px-3">
      <div className="space-y-6">
        {/* Navigation Group */}
        <div>
          <div className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
            {currentRole === 'student' ? 'Student Menu' : 'Faculty Menu'}
          </div>
          <nav className="space-y-0.5">
            {currentRole === 'student' ? (
              studentNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectPage(item.id)}
                    className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-indigo-50 text-indigo-700 font-semibold'
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className={`h-4 w-4 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                      <span>{item.label}</span>
                    </div>
                    {item.badge && (
                      <span
                        className={`text-[10px] font-semibold px-1.5 py-0.2 rounded-md ${
                          item.badgeType === 'warning'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200/60'
                            : 'bg-indigo-50 text-indigo-700 border border-indigo-100'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })
            ) : (
              <button
                onClick={() => onSelectPage('faculty')}
                className={`flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-semibold transition-colors ${
                  currentPage === 'faculty'
                    ? 'bg-indigo-50 text-indigo-700'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <ShieldCheck className="h-4 w-4 text-indigo-600" />
                <span>Faculty Management</span>
              </button>
            )}
          </nav>
        </div>

        {/* Faculty Direct Access for Demo */}
        <div className="pt-2 border-t border-slate-100">
          <div className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
            System
          </div>
          <nav className="space-y-0.5">
            <button
              onClick={() => onSelectPage('faculty')}
              className={`flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium transition-colors ${
                currentPage === 'faculty'
                  ? 'bg-indigo-50 text-indigo-700 font-semibold'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <ShieldCheck className="h-4 w-4 text-slate-400" />
              <span>Faculty Dashboard</span>
            </button>
            <button
              onClick={() => onSelectPage('python_guide')}
              className={`flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium transition-colors ${
                currentPage === 'python_guide'
                  ? 'bg-indigo-50 text-indigo-700 font-semibold'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <Code2 className="h-4 w-4 text-slate-400" />
              <span>VS Code / Python Code</span>
            </button>
          </nav>
        </div>
      </div>

      {/* Footer Info Box */}
      <div className="rounded-xl border border-slate-100 bg-slate-50/80 p-3 text-[11px] text-slate-500">
        <p className="font-semibold text-slate-700">Academic Term 2026-27</p>
        <p className="mt-0.5 leading-relaxed text-slate-400 text-[10px]">
          Student AI syncs with verified faculty records.
        </p>
      </div>
    </aside>
  );
};
