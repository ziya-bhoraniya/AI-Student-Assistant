import React, { useState } from 'react';
import {
  Clock,
  Calendar,
  User,
  CheckCircle2,
  AlertCircle,
  FileCheck,
} from 'lucide-react';
import { StudentFullData, AssignmentStatus } from '../types/academic.js';
import { api } from '../services/api.js';

interface AssignmentsPageProps {
  data: StudentFullData;
  onRefreshData: () => void;
}

export const AssignmentsPage: React.FC<AssignmentsPageProps> = ({
  data,
  onRefreshData,
}) => {
  const { assignments } = data;
  const [filter, setFilter] = useState<'ALL' | 'Pending' | 'In Progress' | 'Completed'>('ALL');
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const filteredAssignments = assignments.filter((asn) => {
    if (filter === 'ALL') return true;
    return asn.status === filter;
  });

  const urgentList = assignments.filter((a) => a.isUrgent);
  const pendingCount = assignments.filter((a) => a.status === 'Pending').length;
  const inProgressCount = assignments.filter((a) => a.status === 'In Progress').length;
  const completedCount = assignments.filter((a) => a.status === 'Completed').length;

  const handleStatusChange = async (assignmentId: string, newStatus: AssignmentStatus) => {
    setUpdatingId(assignmentId);
    try {
      await api.updateAssignmentStatus(assignmentId, newStatus);
      onRefreshData();
    } catch (err) {
      console.error('Failed to update status:', err);
    } finally {
      setUpdatingId(null);
    }
  };

  const handlePercentageChange = async (assignmentId: string, pct: number) => {
    setUpdatingId(assignmentId);
    try {
      const newStatus: AssignmentStatus = pct === 100 ? 'Completed' : pct > 0 ? 'In Progress' : 'Pending';
      await api.updateAssignmentStatus(assignmentId, newStatus, pct);
      onRefreshData();
    } catch (err) {
      console.error('Failed to update assignment percentage:', err);
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">Assignments</h1>
          <p className="mt-0.5 text-xs text-slate-500">
            Track coursework deadlines, manage submission status, and update completion progress.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Completion</p>
            <p className="text-sm font-bold text-slate-900">
              {data.progress.assignmentsCompletionPercentage}%
            </p>
          </div>
          <div className="w-16 h-2 bg-slate-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-600 rounded-full"
              style={{ width: `${data.progress.assignmentsCompletionPercentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Urgent Alert Banner */}
      {urgentList.length > 0 && (
        <div className="rounded-xl border border-amber-200 bg-amber-50/60 p-4">
          <div className="flex items-start gap-3">
            <Clock className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <h2 className="text-xs font-bold text-amber-900 uppercase tracking-wider">
                Urgent Deadlines Approaching
              </h2>
              <div className="mt-1.5 space-y-1">
                {urgentList.map((urg) => (
                  <p key={urg.id} className="text-xs text-amber-900">
                    <span className="font-semibold">{urg.subjectName}:</span> {urg.title} —{' '}
                    {urg.daysRemaining === 1 ? (
                      <span className="font-bold text-red-600">Due tomorrow ({urg.deadline})</span>
                    ) : urg.daysRemaining === 0 ? (
                      <span className="font-bold text-red-600">Due today!</span>
                    ) : (
                      <span className="font-medium text-amber-800">Due in {urg.daysRemaining} days ({urg.deadline})</span>
                    )}
                  </p>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filter Tabs & Quick Counters */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg">
          {(
            [
              { key: 'ALL', label: 'All', count: assignments.length },
              { key: 'Pending', label: 'Pending', count: pendingCount },
              { key: 'In Progress', label: 'In Progress', count: inProgressCount },
              { key: 'Completed', label: 'Completed', count: completedCount },
            ] as const
          ).map((tab) => (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                filter === tab.key
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label} ({tab.count})
            </button>
          ))}
        </div>
        <span className="text-xs text-slate-400 font-medium">
          Showing {filteredAssignments.length} of {assignments.length} assignments
        </span>
      </div>

      {/* Assignment Cards List */}
      <div className="space-y-3.5">
        {filteredAssignments.map((asn) => {
          const isCompleted = asn.status === 'Completed';
          const isUrgent = asn.isUrgent;

          return (
            <div
              key={asn.id}
              className={`rounded-xl border bg-white p-5 shadow-xs transition-colors ${
                isUrgent && !isCompleted
                  ? 'border-amber-300 ring-1 ring-amber-100'
                  : 'border-slate-200'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                {/* Left: Info */}
                <div className="space-y-1.5 flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-sm font-bold text-slate-900">{asn.title}</h3>
                    {isUrgent && !isCompleted && (
                      <span className="rounded bg-amber-100 px-2 py-0.5 text-[10px] font-bold text-amber-800 uppercase tracking-wide">
                        Due in {asn.daysRemaining} {asn.daysRemaining === 1 ? 'day' : 'days'}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">{asn.description}</p>

                  <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px] text-slate-500">
                    <span className="font-semibold text-slate-700">{asn.subjectName}</span>
                    <span aria-hidden="true">·</span>
                    <span className="flex items-center gap-1">
                      <User className="h-3 w-3 text-slate-400" /> {asn.facultyName}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="flex items-center gap-1 font-medium text-slate-700">
                      <Calendar className="h-3 w-3 text-slate-400" /> Due: {asn.deadline}
                    </span>
                  </div>
                </div>

                {/* Right: Controls & Progress */}
                <div className="flex flex-col sm:items-end gap-3 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
                  {/* Status Dropdown */}
                  <div className="flex items-center gap-2">
                    <label htmlFor={`status-${asn.id}`} className="text-[11px] text-slate-400 font-medium">
                      Status:
                    </label>
                    <select
                      id={`status-${asn.id}`}
                      value={asn.status}
                      disabled={updatingId === asn.id}
                      onChange={(e) =>
                        handleStatusChange(asn.id, e.target.value as AssignmentStatus)
                      }
                      className={`text-xs font-semibold rounded-lg px-2.5 py-1 border transition-colors cursor-pointer focus:outline-none ${
                        isCompleted
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : asn.status === 'In Progress'
                          ? 'bg-blue-50 text-blue-800 border-blue-200'
                          : 'bg-amber-50 text-amber-800 border-amber-200'
                      }`}
                    >
                      <option value="Pending">Pending</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Completed">Completed</option>
                    </select>
                  </div>

                  {/* Progress Range */}
                  <div className="w-48 space-y-1">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">Progress</span>
                      <span className="font-semibold text-slate-700">
                        {asn.completionPercentage}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      step="5"
                      aria-label={`${asn.title} progress`}
                      value={asn.completionPercentage}
                      disabled={updatingId === asn.id}
                      onChange={(e) => handlePercentageChange(asn.id, Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                    />
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {filteredAssignments.length === 0 && (
          <div className="rounded-xl border border-dashed border-slate-300 p-8 text-center text-xs text-slate-500">
            No assignments match the selected filter.
          </div>
        )}
      </div>
    </div>
  );
};
