import React, { useState } from 'react';
import {
  CalendarCheck2,
  AlertTriangle,
  CheckCircle2,
  Calculator,
  Info,
} from 'lucide-react';
import { StudentFullData } from '../types/academic.js';

interface AttendancePageProps {
  data: StudentFullData;
}

export const AttendancePage: React.FC<AttendancePageProps> = ({ data }) => {
  const { student, attendanceSummary } = data;
  const [targetPercentage, setTargetPercentage] = useState(75);

  const isLowOverall = attendanceSummary.overallPercentage < 75;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-slate-900">Attendance Records</h1>
              <span className="text-xs text-slate-400">· Official Faculty Logs</span>
            </div>
            <p className="mt-1 text-xs text-slate-500">
              Live attendance synchronized with faculty logs. Mandatory 75% cutoff applies for semester exam eligibility.
            </p>
          </div>
          <div className="text-right">
            <span className="text-[11px] text-slate-400">Enrolled Student</span>
            <p className="text-xs font-semibold text-slate-800">{student.name} ({student.id})</p>
          </div>
        </div>
      </div>

      {/* 3 Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Overall Percentage */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-2xs flex flex-col justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500">Overall Attendance</span>
            <div className="mt-2.5 flex items-baseline gap-2.5">
              <span
                className={`text-3xl font-extrabold tracking-tight ${
                  isLowOverall ? 'text-rose-600' : 'text-slate-900'
                }`}
              >
                {attendanceSummary.overallPercentage}%
              </span>
              <span className="text-xs text-slate-500">
                ({attendanceSummary.totalAttended} of {attendanceSummary.totalClasses} total)
              </span>
            </div>
          </div>

          <div className="mt-4">
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
              <div
                className={`h-full rounded-full transition-all duration-300 ${
                  isLowOverall ? 'bg-rose-500' : 'bg-indigo-600'
                }`}
                style={{ width: `${Math.min(100, attendanceSummary.overallPercentage)}%` }}
              />
            </div>
            <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
              <span>0%</span>
              <span className="font-medium text-slate-600">75% Mandatory Cutoff</span>
              <span>100%</span>
            </div>
          </div>
        </div>

        {/* Classes Attended */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-2xs flex flex-col justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500">Classes Attended</span>
            <div className="mt-2.5 flex items-baseline gap-2">
              <span className="text-3xl font-bold tracking-tight text-slate-900">
                {attendanceSummary.totalAttended}
              </span>
              <span className="text-xs text-slate-500">lectures attended</span>
            </div>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Verified across all theory lectures & laboratory practicals.
          </p>
        </div>

        {/* Classes Missed */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-2xs flex flex-col justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500">Classes Missed</span>
            <div className="mt-2.5 flex items-baseline gap-2">
              <span
                className={`text-3xl font-bold tracking-tight ${
                  attendanceSummary.totalMissed > 15 ? 'text-rose-600' : 'text-slate-900'
                }`}
              >
                {attendanceSummary.totalMissed}
              </span>
              <span className="text-xs text-slate-500">lectures missed</span>
            </div>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Review lecture notes under <strong>Lectures & Notes</strong> to catch up.
          </p>
        </div>
      </div>

      {/* Warning banner if low attendance */}
      {attendanceSummary.subjectStats.some((s) => s.isLow) && (
        <div className="rounded-2xl border border-rose-200 bg-rose-50/60 p-4 shadow-2xs">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <h3 className="text-xs font-bold text-rose-900">
                Attendance Shortage Detected
              </h3>
              <p className="mt-1 text-xs text-rose-800 leading-relaxed">
                You are currently below 75% in:{' '}
                <strong>
                  {attendanceSummary.subjectStats
                    .filter((s) => s.isLow)
                    .map((s) => `${s.subjectName} (${s.percentage}%)`)
                    .join(', ')}
                </strong>
                . Consistent attendance in upcoming classes is recommended to avoid detention.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Subject-Wise Breakdown Table */}
      <div className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-2xs">
        <h2 className="text-sm font-bold text-slate-900 mb-4">Subject-Wise Breakdown</h2>

        <div className="space-y-3.5">
          {attendanceSummary.subjectStats.map((sub) => {
            const isCrit = sub.isLow;
            return (
              <div
                key={sub.subjectCode}
                className={`rounded-xl border p-4 transition-colors ${
                  isCrit
                    ? 'border-rose-200/80 bg-rose-50/30'
                    : 'border-slate-200/70 bg-slate-50/40'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900">{sub.subjectName}</span>
                      <span className="text-[11px] font-mono text-slate-400">
                        ({sub.subjectCode})
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">Faculty: {sub.facultyName}</p>
                  </div>

                  {/* Right numbers & badge */}
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span
                        className={`text-base font-bold ${
                          isCrit ? 'text-rose-600' : 'text-slate-900'
                        }`}
                      >
                        {sub.percentage}%
                      </span>
                      <p className="text-[11px] text-slate-400">
                        {sub.attended} attended / {sub.missed} missed
                      </p>
                    </div>

                    <div className="w-20 text-right">
                      {isCrit ? (
                        <span className="inline-block rounded-md bg-rose-100 px-2 py-0.5 text-[10px] font-semibold text-rose-800">
                          Low Alert
                        </span>
                      ) : (
                        <span className="inline-block rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200/60 px-2 py-0.5 text-[10px] font-semibold">
                          Eligible
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="mt-3">
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-200/70">
                    <div
                      className={`h-full rounded-full transition-all ${
                        isCrit ? 'bg-rose-500' : 'bg-indigo-600'
                      }`}
                      style={{ width: `${Math.min(100, sub.percentage)}%` }}
                    />
                  </div>
                </div>

                {/* Needed Classes Note */}
                {isCrit && sub.neededFor75 > 0 && (
                  <div className="mt-2.5 flex items-center gap-1.5 text-xs text-rose-800 bg-rose-100/60 rounded-lg p-2 font-medium">
                    <Info className="h-3.5 w-3.5 shrink-0" />
                    <span>
                      Need <strong>{sub.neededFor75}</strong> consecutive classes without absence to cross 75%.
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Target Attendance Calculator */}
      <div className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-2xs">
        <div className="flex items-center gap-2 mb-2">
          <Calculator className="h-4 w-4 text-indigo-600" />
          <h2 className="text-sm font-bold text-slate-900">Target Attendance Calculator</h2>
        </div>
        <p className="text-xs text-slate-500 mb-4">
          Calculate the number of consecutive lectures required to hit your desired target percentage.
        </p>

        <div className="flex items-center gap-3 max-w-xs mb-4">
          <label className="text-xs font-semibold text-slate-700 shrink-0">
            Target Goal (%):
          </label>
          <input
            type="number"
            min="60"
            max="100"
            value={targetPercentage}
            onChange={(e) => setTargetPercentage(Number(e.target.value))}
            className="w-20 rounded-lg border border-slate-200 px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {attendanceSummary.subjectStats.map((sub) => {
            const targetFrac = targetPercentage / 100;
            const numerator = targetFrac * sub.total - sub.attended;
            const denominator = 1 - targetFrac;
            const needed =
              denominator > 0 && numerator > 0
                ? Math.ceil(numerator / denominator)
                : 0;

            return (
              <div key={sub.subjectCode} className="rounded-xl border border-slate-200/70 p-3 bg-slate-50/40">
                <p className="text-xs font-semibold text-slate-800 truncate">{sub.subjectName}</p>
                <div className="mt-1 flex items-baseline justify-between text-xs">
                  <span className="text-slate-400">Current: {sub.percentage}%</span>
                  <span className="font-bold text-indigo-600">
                    {needed > 0 ? `+${needed} classes` : 'Target Met'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
