import React, { useState } from 'react';
import {
  CalendarDays,
  Clock,
  MapPin,
  TrendingUp,
} from 'lucide-react';
import { StudentFullData } from '../types/academic.js';
import { api } from '../services/api.js';

interface ExamsPageProps {
  data: StudentFullData;
  onRefreshData: () => void;
}

export const ExamsPage: React.FC<ExamsPageProps> = ({ data, onRefreshData }) => {
  const { exams } = data;
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const handlePrepChange = async (examId: string, prepProgress: number) => {
    setUpdatingId(examId);
    try {
      await api.updateExam(examId, { prepProgress });
      onRefreshData();
    } catch (err) {
      console.error('Failed to update prep progress:', err);
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">Exams Schedule</h1>
          <p className="mt-0.5 text-xs text-slate-500">
            Official examination timetable, syllabus coverage, and your self-assessed preparation level.
          </p>
        </div>
        <div className="text-right">
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Scheduled</p>
          <p className="text-sm font-bold text-slate-900">{exams.length} Papers</p>
        </div>
      </div>

      {/* Exam Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {exams.map((exam) => {
          const isSoon = exam.daysRemaining <= 7;
          return (
            <div
              key={exam.id}
              className={`rounded-xl border bg-white p-5 shadow-xs space-y-4 transition-colors ${
                isSoon ? 'border-amber-300 ring-1 ring-amber-100' : 'border-slate-200'
              }`}
            >
              {/* Card Header */}
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="text-sm font-bold text-slate-900">{exam.subjectName}</h2>
                  <span className="text-xs font-mono font-medium text-slate-400">
                    {exam.subjectCode}
                  </span>
                </div>
                <span
                  className={`inline-block rounded-md px-2 py-0.5 text-xs font-bold ${
                    isSoon
                      ? 'bg-amber-100 text-amber-900'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {exam.daysRemaining} days left
                </span>
              </div>

              {/* Date & Location */}
              <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                <div className="flex items-center gap-1.5 text-slate-600">
                  <CalendarDays className="h-3.5 w-3.5 text-slate-400" />
                  <span>{exam.examDate}</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-600">
                  <MapPin className="h-3.5 w-3.5 text-slate-400" />
                  <span className="truncate">{exam.room}</span>
                </div>
              </div>

              {/* Progress Bars */}
              <div className="space-y-3">
                {/* Syllabus Covered */}
                <div>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-slate-500 font-medium">Syllabus Covered</span>
                    <span className="font-semibold text-slate-800">{exam.syllabusProgress}%</span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
                    <div
                      className="h-full bg-slate-600 rounded-full transition-all duration-300"
                      style={{ width: `${exam.syllabusProgress}%` }}
                    />
                  </div>
                </div>

                {/* Self Preparation Progress Slider */}
                <div>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-slate-700 font-medium flex items-center gap-1">
                      <TrendingUp className="h-3.5 w-3.5 text-blue-600" /> Your Preparation Level:
                    </span>
                    <span className="font-bold text-blue-600">{exam.prepProgress}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="5"
                    aria-label={`${exam.subjectName} preparation progress`}
                    value={exam.prepProgress}
                    disabled={updatingId === exam.id}
                    onChange={(e) => handlePrepChange(exam.id, Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                    <span>Starting (0%)</span>
                    <span>Moderate (50%)</span>
                    <span>Ready (100%)</span>
                  </div>
                </div>
              </div>

              {/* Syllabus Topics */}
              {exam.syllabusTopics && exam.syllabusTopics.length > 0 && (
                <div>
                  <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                    Key Topics:
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {exam.syllabusTopics.map((topic, i) => (
                      <span
                        key={i}
                        className="rounded border border-slate-200 bg-slate-50 px-2 py-0.5 text-[11px] text-slate-600"
                      >
                        {topic}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Faculty Notes */}
              {exam.notes && (
                <div className="text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-700">
                  <span className="font-semibold text-slate-900">Faculty Note:</span> {exam.notes}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
