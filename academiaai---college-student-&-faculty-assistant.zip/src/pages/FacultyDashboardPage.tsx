import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Edit2,
  Trash2,
  CalendarCheck2,
  FileCheck,
  CalendarDays,
  BookOpen,
  Eye,
  CheckCircle2,
  X,
  Search,
} from 'lucide-react';
import {
  Student,
  Faculty,
  Subject,
  AttendanceStatus,
} from '../types/academic.js';
import { api } from '../services/api.js';

interface FacultyDashboardPageProps {
  currentFaculty: Faculty | null;
  students: Student[];
  subjects: Subject[];
  onRefreshData: () => void;
  onSelectStudentForInspection: (studentId: string) => void;
}

export const FacultyDashboardPage: React.FC<FacultyDashboardPageProps> = ({
  currentFaculty,
  students,
  subjects,
  onRefreshData,
  onSelectStudentForInspection,
}) => {
  const [activeTab, setActiveTab] = useState<
    'students' | 'attendance' | 'assignments' | 'exams' | 'lectures'
  >('students');

  // Search in students
  const [searchQuery, setSearchQuery] = useState('');

  // Modals / forms states
  const [showAddStudentModal, setShowAddStudentModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  // Student form state
  const [studentForm, setStudentForm] = useState({
    name: '',
    rollNo: '',
    email: '',
    phone: '',
    course: 'B.Tech Computer Science & Engineering',
    semester: 6,
    division: 'A',
    cgpa: 8.0,
    mentor: currentFaculty?.name || 'Prof. Rajesh Mehta',
  });

  // Attendance entry form state
  const [attForm, setAttForm] = useState({
    studentId: students[0]?.id || 'STU101',
    subjectCode: subjects[0]?.code || 'CS601',
    date: '2026-09-27',
    status: 'Present' as AttendanceStatus,
    topicTaught: 'Process Synchronization & Semaphore Implementation',
  });
  const [attSuccessMsg, setAttSuccessMsg] = useState('');

  // Assignment form state
  const [asnForm, setAsnForm] = useState({
    title: '',
    subjectCode: subjects[0]?.code || 'CS601',
    deadline: '2026-10-10',
    description: '',
  });
  const [asnSuccessMsg, setAsnSuccessMsg] = useState('');

  // Exam form state
  const [examForm, setExamForm] = useState({
    subjectCode: subjects[0]?.code || 'CS601',
    examDate: '2026-10-25',
    room: 'Hall 201, Academic Block A',
    notes: 'Comprehensive 3-hour midterm exam covering modules 1 to 4.',
    syllabusTopicsStr: 'Module 1, Module 2, Module 3',
  });
  const [examSuccessMsg, setExamSuccessMsg] = useState('');

  // Lecture & Notes form state
  const [lecForm, setLecForm] = useState({
    subjectCode: subjects[0]?.code || 'CS601',
    date: '2026-09-27',
    topic: '',
    notesContent: '',
  });
  const [lecSuccessMsg, setLecSuccessMsg] = useState('');

  // Handlers for Students CRUD
  const handleCreateStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentForm.name || !studentForm.rollNo) return;
    try {
      await api.addStudent(studentForm);
      setShowAddStudentModal(false);
      setStudentForm({
        name: '',
        rollNo: '',
        email: '',
        phone: '',
        course: 'B.Tech Computer Science & Engineering',
        semester: 6,
        division: 'A',
        cgpa: 8.0,
        mentor: currentFaculty?.name || 'Prof. Rajesh Mehta',
      });
      onRefreshData();
    } catch (err) {
      console.error('Error adding student:', err);
    }
  };

  const handleUpdateStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStudent) return;
    try {
      await api.updateStudent(editingStudent.id, editingStudent);
      setEditingStudent(null);
      onRefreshData();
    } catch (err) {
      console.error('Error updating student:', err);
    }
  };

  const handleDeleteStudent = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to remove student "${name}" (${id})?`)) return;
    try {
      await api.deleteStudent(id);
      onRefreshData();
    } catch (err) {
      console.error('Error deleting student:', err);
    }
  };

  // Record Attendance Handler
  const handleRecordAttendance = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.recordAttendance(attForm);
      setAttSuccessMsg(
        `Recorded ${attForm.status} for ${attForm.studentId} in ${attForm.subjectCode}. New Attendance: ${res.newPercentage}%`
      );
      setTimeout(() => setAttSuccessMsg(''), 4000);
      onRefreshData();
    } catch (err) {
      console.error('Error recording attendance:', err);
    }
  };

  // Add Assignment Handler
  const handleAddAssignment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!asnForm.title) return;
    const sub = subjects.find((s) => s.code === asnForm.subjectCode);
    try {
      await api.addAssignment({
        title: asnForm.title,
        subjectCode: asnForm.subjectCode,
        subjectName: sub?.name || asnForm.subjectCode,
        facultyName: currentFaculty?.name || 'Prof. Rajesh Mehta',
        deadline: asnForm.deadline,
        description: asnForm.description,
      });
      setAsnSuccessMsg(`Assignment "${asnForm.title}" published successfully!`);
      setAsnForm({
        title: '',
        subjectCode: subjects[0]?.code || 'CS601',
        deadline: '2026-10-10',
        description: '',
      });
      setTimeout(() => setAsnSuccessMsg(''), 4000);
      onRefreshData();
    } catch (err) {
      console.error('Error adding assignment:', err);
    }
  };

  // Add Exam Handler
  const handleAddExam = async (e: React.FormEvent) => {
    e.preventDefault();
    const sub = subjects.find((s) => s.code === examForm.subjectCode);
    try {
      await api.addExam({
        subjectCode: examForm.subjectCode,
        subjectName: sub?.name || examForm.subjectCode,
        examDate: examForm.examDate,
        room: examForm.room,
        notes: examForm.notes,
        syllabusTopics: examForm.syllabusTopicsStr.split(',').map((t) => t.trim()),
      });
      setExamSuccessMsg(`Exam for ${sub?.name} scheduled on ${examForm.examDate}!`);
      setTimeout(() => setExamSuccessMsg(''), 4000);
      onRefreshData();
    } catch (err) {
      console.error('Error scheduling exam:', err);
    }
  };

  // Add Lecture Handler
  const handleAddLecture = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lecForm.topic) return;
    const sub = subjects.find((s) => s.code === lecForm.subjectCode);
    try {
      await api.addLecture({
        date: lecForm.date,
        subjectCode: lecForm.subjectCode,
        subjectName: sub?.name || lecForm.subjectCode,
        facultyName: currentFaculty?.name || 'Prof. Rajesh Mehta',
        topic: lecForm.topic,
        notesContent: lecForm.notesContent,
      });
      setLecSuccessMsg(`Lecture and notes for "${lecForm.topic}" posted successfully!`);
      setLecForm({
        subjectCode: subjects[0]?.code || 'CS601',
        date: '2026-09-27',
        topic: '',
        notesContent: '',
      });
      setTimeout(() => setLecSuccessMsg(''), 4000);
      onRefreshData();
    } catch (err) {
      console.error('Error adding lecture:', err);
    }
  };

  const filteredStudents = students.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.rollNo.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Faculty Management Hub
          </h1>
          <p className="mt-0.5 text-xs text-slate-500">
            Manage student records, mark lecture attendance, post assignments, schedule exams, and publish notes.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500">Faculty:</span>
          <span className="text-xs font-semibold text-slate-900 bg-slate-100 px-2.5 py-1 rounded-md">
            {currentFaculty?.name || 'Prof. Rajesh Mehta'}
          </span>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
        {[
          { id: 'students', label: 'Student Management', icon: Users },
          { id: 'attendance', label: 'Mark Attendance', icon: CalendarCheck2 },
          { id: 'assignments', label: 'Publish Assignment', icon: FileCheck },
          { id: 'exams', label: 'Schedule Exam', icon: CalendarDays },
          { id: 'lectures', label: 'Post Lecture & Notes', icon: BookOpen },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-3 py-2 text-xs rounded-lg transition-colors font-medium cursor-pointer ${
                isActive
                  ? 'bg-white text-blue-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: STUDENT MANAGEMENT (CRUD) */}
      {activeTab === 'students' && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search students by name, ID or roll number..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-lg border border-slate-200 pl-9 pr-4 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500"
              />
            </div>

            <button
              onClick={() => setShowAddStudentModal(true)}
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition-colors cursor-pointer"
            >
              <UserPlus className="h-4 w-4" />
              <span>Add New Student</span>
            </button>
          </div>

          {/* Student Table */}
          <div className="overflow-x-auto rounded-lg border border-slate-200">
            <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
              <thead className="bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <tr>
                  <th className="px-4 py-3">Student Name</th>
                  <th className="px-4 py-3">ID / Roll</th>
                  <th className="px-4 py-3">Class & Div</th>
                  <th className="px-4 py-3">Email & Phone</th>
                  <th className="px-4 py-3">CGPA</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {filteredStudents.map((stu) => (
                  <tr key={stu.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3 font-semibold text-slate-900">{stu.name}</td>
                    <td className="px-4 py-3 text-slate-600 font-mono">
                      {stu.id} · {stu.rollNo}
                    </td>
                    <td className="px-4 py-3 text-slate-600">
                      Sem {stu.semester} (Div {stu.division})
                    </td>
                    <td className="px-4 py-3 text-slate-500">
                      <div>{stu.email}</div>
                      <div className="text-[10px] text-slate-400">{stu.phone}</div>
                    </td>
                    <td className="px-4 py-3 font-bold text-slate-800">{stu.cgpa}</td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onSelectStudentForInspection(stu.id)}
                          className="rounded p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 cursor-pointer"
                          title="View Student Dashboard"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setEditingStudent(stu)}
                          className="rounded p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 cursor-pointer"
                          title="Edit Student"
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteStudent(stu.id, stu.name)}
                          className="rounded p-1.5 text-slate-500 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                          title="Delete Student"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: MARK ATTENDANCE */}
      {activeTab === 'attendance' && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h2 className="text-sm font-bold text-slate-900">Record Lecture Attendance</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Enter attendance for an individual lecture session. System updates student attendance percentage in real time.
            </p>
          </div>

          {attSuccessMsg && (
            <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-3 text-xs font-semibold text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              <span>{attSuccessMsg}</span>
            </div>
          )}

          <form onSubmit={handleRecordAttendance} className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl">
            <div>
              <label htmlFor="att-student-select" className="text-xs font-semibold text-slate-700 block mb-1">Select Student:</label>
              <select
                id="att-student-select"
                value={attForm.studentId}
                onChange={(e) => setAttForm({ ...attForm, studentId: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
              >
                {students.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.id}) · Div {s.division}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="att-subject-select" className="text-xs font-semibold text-slate-700 block mb-1">Subject:</label>
              <select
                id="att-subject-select"
                value={attForm.subjectCode}
                onChange={(e) => setAttForm({ ...attForm, subjectCode: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
              >
                {subjects.map((sub) => (
                  <option key={sub.code} value={sub.code}>
                    {sub.shortName} · {sub.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="att-date-input" className="text-xs font-semibold text-slate-700 block mb-1">Lecture Date:</label>
              <input
                id="att-date-input"
                type="date"
                value={attForm.date}
                onChange={(e) => setAttForm({ ...attForm, date: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Attendance Status:</label>
              <div className="flex items-center gap-4 pt-1">
                <label className="flex items-center gap-2 text-xs font-semibold text-slate-800 cursor-pointer">
                  <input
                    type="radio"
                    name="att_status"
                    checked={attForm.status === 'Present'}
                    onChange={() => setAttForm({ ...attForm, status: 'Present' })}
                    className="accent-emerald-600"
                  />
                  <span className="text-emerald-700">Present</span>
                </label>
                <label className="flex items-center gap-2 text-xs font-semibold text-slate-800 cursor-pointer">
                  <input
                    type="radio"
                    name="att_status"
                    checked={attForm.status === 'Absent'}
                    onChange={() => setAttForm({ ...attForm, status: 'Absent' })}
                    className="accent-red-600"
                  />
                  <span className="text-red-700">Absent</span>
                </label>
              </div>
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="att-topic-input" className="text-xs font-semibold text-slate-700 block mb-1">Topic Taught in this Class:</label>
              <input
                id="att-topic-input"
                type="text"
                value={attForm.topicTaught}
                onChange={(e) => setAttForm({ ...attForm, topicTaught: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
              />
            </div>

            <div className="sm:col-span-2 pt-2">
              <button
                type="submit"
                className="rounded-lg bg-blue-600 px-5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition-colors cursor-pointer"
              >
                Submit Attendance Record
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 3: PUBLISH ASSIGNMENT */}
      {activeTab === 'assignments' && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h2 className="text-sm font-bold text-slate-900">Add New Course Assignment</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Assigned work will immediately show up on students' assignments page and trigger deadline reminders in the AI assistant.
            </p>
          </div>

          {asnSuccessMsg && (
            <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-3 text-xs font-semibold text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              <span>{asnSuccessMsg}</span>
            </div>
          )}

          <form onSubmit={handleAddAssignment} className="space-y-4 max-w-2xl">
            <div>
              <label htmlFor="asn-title-input" className="text-xs font-semibold text-slate-700 block mb-1">Assignment Title:</label>
              <input
                id="asn-title-input"
                type="text"
                placeholder="e.g. DBMS Assignment 4: Transaction Isolation & ACID Logging"
                value={asnForm.title}
                onChange={(e) => setAsnForm({ ...asnForm, title: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="asn-subject-select" className="text-xs font-semibold text-slate-700 block mb-1">Subject:</label>
                <select
                  id="asn-subject-select"
                  value={asnForm.subjectCode}
                  onChange={(e) => setAsnForm({ ...asnForm, subjectCode: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
                >
                  {subjects.map((sub) => (
                    <option key={sub.code} value={sub.code}>
                      {sub.shortName} · {sub.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="asn-deadline-input" className="text-xs font-semibold text-slate-700 block mb-1">Submission Deadline:</label>
                <input
                  id="asn-deadline-input"
                  type="date"
                  value={asnForm.deadline}
                  onChange={(e) => setAsnForm({ ...asnForm, deadline: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
                  required
                />
              </div>
            </div>

            <div>
              <label htmlFor="asn-desc-textarea" className="text-xs font-semibold text-slate-700 block mb-1">Instructions:</label>
              <textarea
                id="asn-desc-textarea"
                rows={3}
                placeholder="Detail what students must submit, required diagrams, or test scenarios..."
                value={asnForm.description}
                onChange={(e) => setAsnForm({ ...asnForm, description: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
              />
            </div>

            <button
              type="submit"
              className="rounded-lg bg-blue-600 px-5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition-colors cursor-pointer"
            >
              Publish Assignment
            </button>
          </form>
        </div>
      )}

      {/* TAB 4: SCHEDULE EXAM */}
      {activeTab === 'exams' && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h2 className="text-sm font-bold text-slate-900">Schedule Examination</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Add upcoming midterms or final theory papers. Countdowns and days remaining sync immediately across student portals.
            </p>
          </div>

          {examSuccessMsg && (
            <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-3 text-xs font-semibold text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              <span>{examSuccessMsg}</span>
            </div>
          )}

          <form onSubmit={handleAddExam} className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl">
            <div>
              <label htmlFor="exam-subject-select" className="text-xs font-semibold text-slate-700 block mb-1">Subject:</label>
              <select
                id="exam-subject-select"
                value={examForm.subjectCode}
                onChange={(e) => setExamForm({ ...examForm, subjectCode: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
              >
                {subjects.map((sub) => (
                  <option key={sub.code} value={sub.code}>
                    {sub.shortName} · {sub.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="exam-date-input" className="text-xs font-semibold text-slate-700 block mb-1">Exam Date:</label>
              <input
                id="exam-date-input"
                type="date"
                value={examForm.examDate}
                onChange={(e) => setExamForm({ ...examForm, examDate: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
                required
              />
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="exam-room-input" className="text-xs font-semibold text-slate-700 block mb-1">Exam Hall / Room:</label>
              <input
                id="exam-room-input"
                type="text"
                value={examForm.room}
                onChange={(e) => setExamForm({ ...examForm, room: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
              />
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="exam-topics-input" className="text-xs font-semibold text-slate-700 block mb-1">
                Syllabus Topics (comma-separated):
              </label>
              <input
                id="exam-topics-input"
                type="text"
                value={examForm.syllabusTopicsStr}
                onChange={(e) => setExamForm({ ...examForm, syllabusTopicsStr: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
              />
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="exam-notes-textarea" className="text-xs font-semibold text-slate-700 block mb-1">Preparation Note for Students:</label>
              <textarea
                id="exam-notes-textarea"
                rows={2}
                value={examForm.notes}
                onChange={(e) => setExamForm({ ...examForm, notes: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
              />
            </div>

            <div className="sm:col-span-2">
              <button
                type="submit"
                className="rounded-lg bg-blue-600 px-5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition-colors cursor-pointer"
              >
                Schedule Exam
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 5: POST LECTURE & NOTES */}
      {activeTab === 'lectures' && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h2 className="text-sm font-bold text-slate-900">Post Lecture Session & Course Notes</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Record class topics and upload study notes so students can catch up and the AI assistant can answer questions regarding missed lectures.
            </p>
          </div>

          {lecSuccessMsg && (
            <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-3 text-xs font-semibold text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              <span>{lecSuccessMsg}</span>
            </div>
          )}

          <form onSubmit={handleAddLecture} className="space-y-4 max-w-2xl">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="lec-subject-select" className="text-xs font-semibold text-slate-700 block mb-1">Subject:</label>
                <select
                  id="lec-subject-select"
                  value={lecForm.subjectCode}
                  onChange={(e) => setLecForm({ ...lecForm, subjectCode: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
                >
                  {subjects.map((sub) => (
                    <option key={sub.code} value={sub.code}>
                      {sub.shortName} · {sub.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="lec-date-input" className="text-xs font-semibold text-slate-700 block mb-1">Lecture Date:</label>
                <input
                  id="lec-date-input"
                  type="date"
                  value={lecForm.date}
                  onChange={(e) => setLecForm({ ...lecForm, date: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
                  required
                />
              </div>
            </div>

            <div>
              <label htmlFor="lec-topic-input" className="text-xs font-semibold text-slate-700 block mb-1">Topic Taught in Class:</label>
              <input
                id="lec-topic-input"
                type="text"
                placeholder="e.g. Memory Management: Page Replacement Algorithms (FIFO, LRU)"
                value={lecForm.topic}
                onChange={(e) => setLecForm({ ...lecForm, topic: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white"
                required
              />
            </div>

            <div>
              <label htmlFor="lec-notes-textarea" className="text-xs font-semibold text-slate-700 block mb-1">
                Lecture Notes & Key Concepts:
              </label>
              <textarea
                id="lec-notes-textarea"
                rows={5}
                placeholder="Paste key takeaways, formulas, algorithms, or summary points..."
                value={lecForm.notesContent}
                onChange={(e) => setLecForm({ ...lecForm, notesContent: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500 font-mono bg-white"
              />
            </div>

            <button
              type="submit"
              className="rounded-lg bg-blue-600 px-5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition-colors cursor-pointer"
            >
              Post Lecture & Notes
            </button>
          </form>
        </div>
      )}

      {/* MODAL: ADD STUDENT */}
      {showAddStudentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg rounded-2xl bg-white shadow-xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4 bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">Add New Student</h3>
              <button
                onClick={() => setShowAddStudentModal(false)}
                className="rounded-lg p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleCreateStudent} className="p-6 space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Full Student Name:</label>
                <input
                  type="text"
                  placeholder="e.g. Tanvi Deshmukh"
                  value={studentForm.name}
                  onChange={(e) => setStudentForm({ ...studentForm, name: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Roll Number:</label>
                  <input
                    type="text"
                    placeholder="e.g. 21CS111"
                    value={studentForm.rollNo}
                    onChange={(e) => setStudentForm({ ...studentForm, rollNo: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Class Division:</label>
                  <select
                    value={studentForm.division}
                    onChange={(e) => setStudentForm({ ...studentForm, division: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                  >
                    <option value="A">Division A</option>
                    <option value="B">Division B</option>
                    <option value="C">Division C</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">College Email:</label>
                <input
                  type="email"
                  placeholder="tanvi.d@college.edu.in"
                  value={studentForm.email}
                  onChange={(e) => setStudentForm({ ...studentForm, email: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Phone Number:</label>
                  <input
                    type="text"
                    placeholder="+91 98..."
                    value={studentForm.phone}
                    onChange={(e) => setStudentForm({ ...studentForm, phone: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Starting CGPA:</label>
                  <input
                    type="number"
                    step="0.05"
                    min="0"
                    max="10"
                    value={studentForm.cgpa}
                    onChange={(e) => setStudentForm({ ...studentForm, cgpa: Number(e.target.value) })}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddStudentModal(false)}
                  className="rounded-lg px-4 py-2 font-medium text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-blue-600 px-5 py-2 font-semibold text-white hover:bg-blue-700 cursor-pointer"
                >
                  Create Student
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EDIT STUDENT */}
      {editingStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg rounded-2xl bg-white shadow-xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4 bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">
                Edit Student: {editingStudent.name} ({editingStudent.id})
              </h3>
              <button
                onClick={() => setEditingStudent(null)}
                className="rounded-lg p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleUpdateStudent} className="p-6 space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Student Name:</label>
                <input
                  type="text"
                  value={editingStudent.name}
                  onChange={(e) => setEditingStudent({ ...editingStudent, name: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Roll Number:</label>
                  <input
                    type="text"
                    value={editingStudent.rollNo}
                    onChange={(e) => setEditingStudent({ ...editingStudent, rollNo: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Division:</label>
                  <select
                    value={editingStudent.division}
                    onChange={(e) => setEditingStudent({ ...editingStudent, division: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                  >
                    <option value="A">Division A</option>
                    <option value="B">Division B</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Email:</label>
                <input
                  type="email"
                  value={editingStudent.email}
                  onChange={(e) => setEditingStudent({ ...editingStudent, email: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">CGPA:</label>
                <input
                  type="number"
                  step="0.05"
                  value={editingStudent.cgpa}
                  onChange={(e) => setEditingStudent({ ...editingStudent, cgpa: Number(e.target.value) })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingStudent(null)}
                  className="rounded-lg px-4 py-2 font-medium text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-blue-600 px-5 py-2 font-semibold text-white hover:bg-blue-700 cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
