import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  AlertTriangle,
  Clock,
  BookOpen,
  CalendarCheck2,
  CalendarDays,
  CheckCircle2,
  ArrowRight,
  TrendingUp,
  BrainCircuit,
  FileCheck,
  Bot,
  User,
  Copy,
  Check,
  Lightbulb,
} from 'lucide-react';
import { StudentFullData, ChatMessage } from '../types/academic.js';
import { api } from '../services/api.js';

interface HomePageProps {
  data: StudentFullData;
  onNavigatePage: (pageId: any) => void;
  onRefreshData: () => void;
}

const SUGGESTED_QUESTIONS = [
  'What should I study today?',
  'How is my attendance?',
  'What assignments are pending?',
  'Make my weekly study plan',
  'What did I miss when I was absent?',
  'I have 3 hours today. What should I study?',
];

export const HomePage: React.FC<HomePageProps> = ({
  data,
  onNavigatePage,
  onRefreshData,
}) => {
  const { student, attendanceSummary, assignments, exams, progress, reminders } = data;
  const firstName = student.name.split(' ')[0];

  // Chatbot State
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'assistant',
      text: `Hello **${firstName}**! I'm your AcademiaAI academic assistant.\n\nI have direct access to your verified college records: attendance (**${attendanceSummary.overallPercentage}%**), **${assignments.filter((a) => a.status !== 'Completed').length} pending assignment(s)**, and upcoming exams. Click any suggestion below or ask me anything!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isSubmitting]);

  const handleSendMessage = async (queryText?: string) => {
    const textToSend = (queryText || inputQuery).trim();
    if (!textToSend || isSubmitting) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setIsSubmitting(true);

    try {
      const history = messages.slice(-5).map((m) => ({
        role: m.sender === 'assistant' ? 'model' : 'user',
        text: m.text,
      }));

      const reply = await api.askAiAssistant(textToSend, student.id, history);

      const assistantMsg: ChatMessage = {
        id: `asst-${Date.now()}`,
        sender: 'assistant',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'assistant',
        text: `I encountered an issue analyzing your records. Please try again or ask a specific question.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const pendingAssignments = assignments.filter((a) => a.status !== 'Completed');
  const urgentAssignments = pendingAssignments.filter((a) => a.isUrgent);
  const nextExam = exams.length > 0 ? exams[0] : null;

  // Compute dynamic study recommendation
  const studyRecommendation = (() => {
    if (urgentAssignments.length > 0) {
      const first = urgentAssignments[0];
      return {
        subject: first.subjectName,
        task: `Submit "${first.title}" (Due ${first.deadline === '2026-09-28' ? 'Tomorrow' : 'in 2 days'})`,
        tip: 'Finish the code/diagram implementation first to avoid late deduction.',
      };
    }
    if (nextExam) {
      return {
        subject: nextExam.subjectName,
        task: `Review ${nextExam.syllabusTopics[0] || 'Core Modules'} (Exam in ${nextExam.daysRemaining} days)`,
        tip: 'Solve 2 numerical problems and revise faculty lecture notes.',
      };
    }
    return {
      subject: 'Operating Systems',
      task: 'Review CPU Scheduling & Process Synchronization',
      tip: 'Consolidate notes from the recent lecture.',
    };
  })();

  return (
    <div className="space-y-6">
      {/* Top Greeting Header */}
      <div className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
              Good Morning, {student.name} 👋
            </h1>
            <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span className="font-medium text-slate-700">{student.course}</span>
              <span className="text-slate-300">·</span>
              <span>Semester {student.semester} (Div {student.division})</span>
              <span className="text-slate-300">·</span>
              <span>Roll: {student.rollNo}</span>
              <span className="text-slate-300">·</span>
              <span>Mentor: {student.mentor}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigatePage('study_planner')}
              className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white shadow-xs hover:bg-indigo-700 transition-colors"
            >
              <BrainCircuit className="h-4 w-4" />
              <span>Study Planner</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4 Simple Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Attendance Card */}
        <div
          onClick={() => onNavigatePage('attendance')}
          className="cursor-pointer rounded-2xl border border-slate-200/80 bg-white p-5 transition-all hover:border-indigo-300 hover:shadow-xs group flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">Attendance</span>
              <div
                className={`p-2 rounded-xl ${
                  attendanceSummary.overallPercentage < 75
                    ? 'bg-rose-50 text-rose-600'
                    : 'bg-indigo-50 text-indigo-600'
                }`}
              >
                <CalendarCheck2 className="h-4 w-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span
                className={`text-2xl font-bold tracking-tight ${
                  attendanceSummary.overallPercentage < 75 ? 'text-rose-600' : 'text-slate-900'
                }`}
              >
                {attendanceSummary.overallPercentage}%
              </span>
              <span className="text-xs text-slate-500">
                ({attendanceSummary.totalAttended}/{attendanceSummary.totalClasses} classes)
              </span>
            </div>
          </div>
          <div className="mt-3">
            <div className="h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${
                  attendanceSummary.overallPercentage < 75 ? 'bg-rose-500' : 'bg-indigo-600'
                }`}
                style={{ width: `${Math.min(100, attendanceSummary.overallPercentage)}%` }}
              />
            </div>
            <div className="mt-2 flex items-center justify-between text-[11px]">
              <span
                className={`font-medium ${
                  attendanceSummary.overallPercentage < 75 ? 'text-rose-600' : 'text-slate-500'
                }`}
              >
                {attendanceSummary.overallPercentage < 75 ? 'Below 75% Cutoff' : 'Good Standing'}
              </span>
              <span className="text-indigo-600 font-medium group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
                View <ArrowRight className="h-3 w-3" />
              </span>
            </div>
          </div>
        </div>

        {/* Pending Assignments Card */}
        <div
          onClick={() => onNavigatePage('assignments')}
          className="cursor-pointer rounded-2xl border border-slate-200/80 bg-white p-5 transition-all hover:border-indigo-300 hover:shadow-xs group flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">Pending Assignments</span>
              <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
                <FileCheck className="h-4 w-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-2xl font-bold tracking-tight text-slate-900">
                {pendingAssignments.length}
              </span>
              <span className="text-xs text-slate-500">to submit</span>
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between text-[11px] pt-1 border-t border-slate-50">
            {urgentAssignments.length > 0 ? (
              <span className="text-rose-600 font-semibold flex items-center gap-1">
                <Clock className="h-3 w-3" /> {urgentAssignments.length} Due Soon
              </span>
            ) : (
              <span className="text-slate-500 font-medium">On Schedule</span>
            )}
            <span className="text-indigo-600 font-medium group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
              Tasks <ArrowRight className="h-3 w-3" />
            </span>
          </div>
        </div>

        {/* Next Exam Card */}
        <div
          onClick={() => onNavigatePage('exams')}
          className="cursor-pointer rounded-2xl border border-slate-200/80 bg-white p-5 transition-all hover:border-indigo-300 hover:shadow-xs group flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">Next Exam</span>
              <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
                <CalendarDays className="h-4 w-4" />
              </div>
            </div>
            <div className="mt-3">
              <p className="text-sm font-bold text-slate-900 truncate">
                {nextExam ? nextExam.subjectName : 'No Exams'}
              </p>
              <p className="text-xs text-slate-500 mt-0.5">
                {nextExam ? `In ${nextExam.daysRemaining} days (${nextExam.examDate})` : 'All clear'}
              </p>
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between text-[11px] pt-1 border-t border-slate-50">
            <span className="text-slate-500">
              Prep: {nextExam ? `${nextExam.prepProgress}%` : '-'}
            </span>
            <span className="text-indigo-600 font-medium group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
              Schedule <ArrowRight className="h-3 w-3" />
            </span>
          </div>
        </div>

        {/* Study Progress Card */}
        <div
          onClick={() => onNavigatePage('progress')}
          className="cursor-pointer rounded-2xl border border-slate-200/80 bg-white p-5 transition-all hover:border-indigo-300 hover:shadow-xs group flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">Study Progress</span>
              <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
                <TrendingUp className="h-4 w-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-2xl font-bold tracking-tight text-slate-900">
                {progress.overallProgressPercentage}%
              </span>
              <span className="text-xs text-slate-500">syllabus covered</span>
            </div>
          </div>
          <div className="mt-3">
            <div className="h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
              <div
                className="h-full bg-indigo-600 rounded-full transition-all"
                style={{ width: `${progress.overallProgressPercentage}%` }}
              />
            </div>
            <div className="mt-2 flex items-center justify-between text-[11px]">
              <span className="text-slate-500">{progress.totalStudyHours}h logged</span>
              <span className="text-indigo-600 font-medium group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
                Track <ArrowRight className="h-3 w-3" />
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 3 Structured Clean Cards: Reminders, Upcoming Deadlines, Today's Study Recommendation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* 1. Important Reminders */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-amber-500" />
                <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Important Reminders
                </h2>
              </div>
              <span className="text-[11px] font-medium text-slate-400">
                {reminders.length} alert{reminders.length === 1 ? '' : 's'}
              </span>
            </div>

            <div className="mt-3 space-y-2">
              {reminders.slice(0, 2).map((rem) => {
                const isCrit = rem.urgency === 'critical';
                return (
                  <div
                    key={rem.id}
                    onClick={() => rem.actionPage && onNavigatePage(rem.actionPage)}
                    className={`cursor-pointer rounded-xl p-3 border transition-colors ${
                      isCrit
                        ? 'border-rose-100 bg-rose-50/50 hover:bg-rose-50'
                        : 'border-slate-100 bg-slate-50/70 hover:bg-slate-100/60'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <p className={`text-xs font-semibold ${isCrit ? 'text-rose-800' : 'text-slate-800'}`}>
                        {rem.title}
                      </p>
                      <span className="text-[10px] text-slate-400">{rem.date}</span>
                    </div>
                    <p className="mt-1 text-[11px] text-slate-600 line-clamp-2 leading-relaxed">
                      {rem.message}
                    </p>
                  </div>
                );
              })}
              {reminders.length === 0 && (
                <p className="text-xs text-slate-400 py-4 text-center">No active reminders. You are all caught up!</p>
              )}
            </div>
          </div>

          {reminders.length > 2 && (
            <div className="pt-2 text-right">
              <button
                onClick={() => onNavigatePage('attendance')}
                className="text-[11px] font-medium text-indigo-600 hover:text-indigo-800"
              >
                + {reminders.length - 2} more reminders
              </button>
            </div>
          )}
        </div>

        {/* 2. Upcoming Deadlines */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-indigo-600" />
                <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Upcoming Deadlines
                </h2>
              </div>
              <span className="text-[11px] font-medium text-slate-400">
                {pendingAssignments.length} pending
              </span>
            </div>

            <div className="mt-3 space-y-2">
              {pendingAssignments.slice(0, 2).map((asn) => (
                <div
                  key={asn.id}
                  onClick={() => onNavigatePage('assignments')}
                  className="cursor-pointer rounded-xl border border-slate-100 bg-slate-50/70 p-3 hover:bg-slate-100/60 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-xs font-semibold text-slate-800 truncate">{asn.title}</p>
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0 ${
                        asn.daysRemaining <= 2
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-slate-200/70 text-slate-700'
                      }`}
                    >
                      {asn.daysRemaining === 0 ? 'Today' : `In ${asn.daysRemaining}d`}
                    </span>
                  </div>
                  <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500">
                    <span>{asn.subjectName}</span>
                    <span>{asn.completionPercentage}% done</span>
                  </div>
                </div>
              ))}
              {pendingAssignments.length === 0 && (
                <p className="text-xs text-slate-400 py-4 text-center">All assignments completed!</p>
              )}
            </div>
          </div>

          <div className="pt-2 text-right">
            <button
              onClick={() => onNavigatePage('assignments')}
              className="text-[11px] font-medium text-indigo-600 hover:text-indigo-800"
            >
              View all assignments →
            </button>
          </div>
        </div>

        {/* 3. Today's Study Recommendation */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Lightbulb className="h-4 w-4 text-indigo-600" />
                <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Today's Study Focus
                </h2>
              </div>
              <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full">
                AI Pick
              </span>
            </div>

            <div className="mt-3 rounded-xl border border-indigo-100/80 bg-indigo-50/40 p-3.5 space-y-2">
              <span className="text-[11px] font-bold uppercase tracking-wide text-indigo-700">
                {studyRecommendation.subject}
              </span>
              <p className="text-xs font-semibold text-slate-900 leading-snug">
                {studyRecommendation.task}
              </p>
              <p className="text-[11px] text-slate-600 italic leading-relaxed">
                💡 {studyRecommendation.tip}
              </p>
            </div>
          </div>

          <div className="pt-3">
            <button
              onClick={() => onNavigatePage('study_planner')}
              className="w-full text-center py-2 text-xs font-semibold text-indigo-700 bg-indigo-50/70 hover:bg-indigo-100/70 rounded-xl transition-colors"
            >
              Generate Full Study Plan →
            </button>
          </div>
        </div>
      </div>

      {/* ============================================================== */}
      {/* MODERN ACADEMIC AI ASSISTANT (PROMINENT ON HOME PAGE ONLY)     */}
      {/* ============================================================== */}
      <div className="rounded-2xl border border-slate-200/90 bg-white shadow-xs overflow-hidden">
        {/* Assistant Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/60 gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-xs">
              <Bot className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-slate-900">
                  Personal Academic AI Assistant
                </h2>
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-medium text-emerald-700 border border-emerald-200/60">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Synced with Student DB
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                Analyzes your attendance records, syllabus completion, exam dates & lecture notes.
              </p>
            </div>
          </div>
          <div className="text-xs text-slate-400">
            Student: <span className="font-semibold text-slate-700">{student.name}</span>
          </div>
        </div>

        {/* Suggested Questions */}
        <div className="px-6 pt-3.5 pb-2 border-b border-slate-100 bg-white">
          <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-2">
            Suggested Questions:
          </p>
          <div className="flex flex-wrap gap-1.5">
            {SUGGESTED_QUESTIONS.map((question, i) => (
              <button
                key={i}
                onClick={() => handleSendMessage(question)}
                disabled={isSubmitting}
                className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 hover:border-indigo-200 transition-colors font-medium cursor-pointer shadow-2xs"
              >
                {question}
              </button>
            ))}
          </div>
        </div>

        {/* Chat Message Window */}
        <div className="h-96 overflow-y-auto px-6 py-5 space-y-4 bg-slate-50/30">
          {messages.map((msg) => {
            const isAsst = msg.sender === 'assistant';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isAsst ? 'justify-start' : 'justify-end'}`}
              >
                {isAsst && (
                  <div className="flex h-8 w-8 shrink-0 select-none items-center justify-center rounded-xl bg-indigo-600 text-white text-xs font-semibold shadow-2xs">
                    <Bot className="h-4 w-4" />
                  </div>
                )}
                <div
                  className={`relative max-w-2xl rounded-2xl px-4 py-3 text-xs leading-relaxed shadow-2xs ${
                    isAsst
                      ? 'bg-white border border-slate-200 text-slate-800'
                      : 'bg-indigo-600 text-white'
                  }`}
                >
                  {/* Clean Markdown parsing for assistant replies */}
                  <div className="whitespace-pre-wrap font-sans">
                    {msg.text.split('\n').map((line, idx) => {
                      const parts = line.split(/(\*\*.*?\*\*)/g);
                      return (
                        <p key={idx} className={idx > 0 ? 'mt-1.5' : ''}>
                          {parts.map((p, pIdx) => {
                            if (p.startsWith('**') && p.endsWith('**')) {
                              return (
                                <strong key={pIdx} className={isAsst ? 'font-semibold text-slate-900' : 'font-semibold text-white'}>
                                  {p.slice(2, -2)}
                                </strong>
                              );
                            }
                            return p;
                          })}
                        </p>
                      );
                    })}
                  </div>

                  <div className="mt-2 flex items-center justify-between pt-1 text-[10px]">
                    {isAsst ? (
                      <button
                        onClick={() => handleCopy(msg.id, msg.text)}
                        className="text-slate-400 hover:text-slate-600 inline-flex items-center gap-1 cursor-pointer"
                        title="Copy response"
                      >
                        {copiedId === msg.id ? (
                          <>
                            <Check className="h-3 w-3 text-emerald-600" />
                            <span className="text-emerald-600">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="h-3 w-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    ) : (
                      <span />
                    )}
                    <span className={isAsst ? 'text-slate-400' : 'text-indigo-200'}>
                      {msg.timestamp}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}

          {isSubmitting && (
            <div className="flex gap-3 justify-start items-center">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-indigo-600 text-white text-xs font-semibold shadow-2xs">
                <Bot className="h-4 w-4" />
              </div>
              <div className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs text-slate-500 flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-indigo-600 animate-pulse" />
                <span>Checking your attendance, assignments & exams...</span>
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="p-4 border-t border-slate-100 bg-white flex items-center gap-2"
        >
          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            placeholder="Ask your academic assistant (e.g. 'What should I study today?', 'What is my attendance?')..."
            className="flex-1 rounded-xl border border-slate-200 bg-slate-50/60 px-4 py-2.5 text-xs text-slate-800 placeholder-slate-400 focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 focus:outline-none transition-colors"
            disabled={isSubmitting}
          />
          <button
            type="submit"
            disabled={!inputQuery.trim() || isSubmitting}
            className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-semibold text-white shadow-xs hover:bg-indigo-700 disabled:opacity-40 transition-colors"
          >
            <Send className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Ask</span>
          </button>
        </form>
      </div>
    </div>
  );
};
