import React, { useState } from 'react';
import {
  BookOpen,
  Calendar,
  CheckCircle2,
  XCircle,
  Copy,
  Check,
  X,
} from 'lucide-react';
import { StudentFullData } from '../types/academic.js';

interface LecturesNotesPageProps {
  data: StudentFullData;
}

export const LecturesNotesPage: React.FC<LecturesNotesPageProps> = ({ data }) => {
  const { lectures } = data;
  const [selectedLectureForNotes, setSelectedLectureForNotes] = useState<any>(null);
  const [copied, setCopied] = useState(false);
  const [filterSubject, setFilterSubject] = useState<string>('ALL');

  const filteredLectures = lectures.filter((lec) => {
    if (filterSubject === 'ALL') return true;
    return lec.subjectCode === filterSubject;
  });

  const handleCopyNotes = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Lectures & Notes
          </h1>
          <p className="mt-0.5 text-xs text-slate-500">
            Review syllabus topics covered in class, verify attendance, and read lecture notes.
          </p>
        </div>
        <div className="text-right">
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Recorded</p>
          <p className="text-sm font-bold text-slate-900">{lectures.length} Sessions</p>
        </div>
      </div>

      {/* Subject Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-lg">
          <button
            onClick={() => setFilterSubject('ALL')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filterSubject === 'ALL'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Subjects
          </button>
          {data.subjects.map((sub) => (
            <button
              key={sub.code}
              onClick={() => setFilterSubject(sub.code)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                filterSubject === sub.code
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {sub.shortName}
            </button>
          ))}
        </div>
        <span className="text-xs text-slate-400 font-medium">
          Showing {filteredLectures.length} of {lectures.length} lectures
        </span>
      </div>

      {/* Lectures List */}
      <div className="space-y-3">
        {filteredLectures.map((lec) => {
          const isAbsent = lec.status === 'Absent';
          return (
            <div
              key={lec.id}
              className={`rounded-xl border bg-white p-4 shadow-xs transition-colors ${
                isAbsent
                  ? 'border-amber-200 bg-amber-50/20'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{lec.subjectName}</span>
                    <span className="text-xs font-mono text-slate-400">({lec.subjectCode})</span>
                    <span className="text-slate-300">·</span>
                    <span className="text-xs text-slate-500 flex items-center gap-1">
                      <Calendar className="h-3 w-3 text-slate-400" /> {lec.date}
                    </span>
                  </div>

                  <p className="text-xs text-slate-800">
                    <span className="font-semibold text-slate-900">Topic:</span> {lec.topic}
                  </p>

                  <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 pt-0.5">
                    <span>Faculty: {lec.facultyName}</span>
                    <span aria-hidden="true">·</span>
                    {isAbsent ? (
                      <span className="inline-flex items-center gap-1 font-bold text-amber-900 bg-amber-100 px-2 py-0.5 rounded">
                        <XCircle className="h-3 w-3 text-amber-700" /> Absent
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 font-medium text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                        <CheckCircle2 className="h-3 w-3 text-emerald-600" /> Present
                      </span>
                    )}
                    <span aria-hidden="true">·</span>
                    <span>Notes: {lec.notesAvailable ? 'Available' : 'Pending upload'}</span>
                  </div>
                </div>

                {/* View Notes Button */}
                <div className="shrink-0 flex items-center gap-2 pt-2 sm:pt-0">
                  {lec.notesAvailable ? (
                    <button
                      onClick={() => setSelectedLectureForNotes(lec)}
                      className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold shadow-xs transition-colors cursor-pointer ${
                        isAbsent
                          ? 'bg-amber-600 text-white hover:bg-amber-700'
                          : 'bg-blue-600 text-white hover:bg-blue-700'
                      }`}
                    >
                      <BookOpen className="h-3.5 w-3.5" />
                      <span>{isAbsent ? 'Catch Up: Notes' : 'Read Notes'}</span>
                    </button>
                  ) : (
                    <span className="text-xs text-slate-400 italic">No notes</span>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {filteredLectures.length === 0 && (
          <div className="rounded-xl border border-dashed border-slate-300 p-8 text-center text-xs text-slate-500">
            No lectures recorded for the selected subject.
          </div>
        )}
      </div>

      {/* Modal for viewing lecture notes */}
      {selectedLectureForNotes && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
          <div className="w-full max-w-2xl rounded-2xl bg-white shadow-xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4 bg-slate-50">
              <div>
                <span className="text-[11px] font-semibold uppercase tracking-wider text-blue-600">
                  {selectedLectureForNotes.subjectName} · {selectedLectureForNotes.date}
                </span>
                <h3 className="text-sm font-bold text-slate-900 mt-0.5">
                  {selectedLectureForNotes.topic}
                </h3>
              </div>
              <button
                onClick={() => setSelectedLectureForNotes(null)}
                className="rounded-lg p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-4 text-xs leading-relaxed text-slate-700">
              <div className="flex items-center justify-between text-[11px] text-slate-500 pb-2 border-b border-slate-100">
                <span>Faculty: {selectedLectureForNotes.facultyName}</span>
                <span
                  className={
                    selectedLectureForNotes.status === 'Absent'
                      ? 'text-amber-800 font-semibold'
                      : 'text-emerald-700 font-semibold'
                  }
                >
                  Your Attendance: {selectedLectureForNotes.status}
                </span>
              </div>

              {/* Notes content */}
              <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-4 font-sans text-xs leading-relaxed whitespace-pre-wrap">
                {selectedLectureForNotes.notesContent || 'No notes content provided.'}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between border-t border-slate-200 px-6 py-3.5 bg-slate-50">
              <button
                onClick={() => handleCopyNotes(selectedLectureForNotes.notesContent)}
                className="inline-flex items-center gap-1.5 text-xs text-blue-700 font-semibold hover:text-blue-900 cursor-pointer"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copied ? 'Copied to Clipboard' : 'Copy Notes'}</span>
              </button>

              <button
                onClick={() => setSelectedLectureForNotes(null)}
                className="rounded-lg bg-slate-200 px-4 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-300 transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
