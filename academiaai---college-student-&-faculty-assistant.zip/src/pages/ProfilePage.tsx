import React from 'react';
import {
  User,
  Mail,
  Phone,
  BookOpen,
  Award,
  GraduationCap,
} from 'lucide-react';
import { StudentFullData } from '../types/academic.js';

interface ProfilePageProps {
  data: StudentFullData;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ data }) => {
  const { student, subjects } = data;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">Student Profile</h1>
          <p className="mt-0.5 text-xs text-slate-500">
            Official college enrollment record, academic standings, and enrolled faculty courses.
          </p>
        </div>
        <div className="text-right">
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Cumulative GPA</p>
          <p className="text-xl font-bold text-slate-900">{student.cgpa} / 10.0</p>
        </div>
      </div>

      {/* Profile Overview Card */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-blue-600 text-white text-lg font-bold shadow-xs">
            {student.name
              .split(' ')
              .map((n) => n[0])
              .join('')}
          </div>
          <div className="flex-1">
            <h2 className="text-base font-bold text-slate-900">{student.name}</h2>
            <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span>ID: <strong className="font-mono text-slate-800">{student.id}</strong></span>
              <span aria-hidden="true">·</span>
              <span>Roll No: <strong className="font-mono text-slate-800">{student.rollNo}</strong></span>
              <span aria-hidden="true">·</span>
              <span className="font-medium text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
                {student.course}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Profile Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Academic Enrollment */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-3">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider pb-2 border-b border-slate-100">
            Enrollment Details
          </h3>

          <div className="space-y-2.5 text-xs">
            <div className="flex justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500">Degree Program</span>
              <span className="font-semibold text-slate-800">{student.course}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500">Current Semester</span>
              <span className="font-semibold text-slate-800">Semester {student.semester}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500">Class Division</span>
              <span className="font-semibold text-slate-800">Division {student.division}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500">College Email</span>
              <span className="font-medium text-slate-800">{student.email}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500">Contact Number</span>
              <span className="font-medium text-slate-800">{student.phone}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-500">Faculty Mentor</span>
              <span className="font-semibold text-blue-700">{student.mentor}</span>
            </div>
          </div>
        </div>

        {/* Academic Health & Status */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-3">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider pb-2 border-b border-slate-100">
            Academic Status
          </h3>

          <div className="space-y-2.5 text-xs">
            <div className="flex justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500">Registration Status</span>
              <span className="inline-block rounded bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800">
                ACTIVE & VERIFIED
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500">Cumulative GPA</span>
              <span className="font-bold text-slate-900">{student.cgpa} / 10.0</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500">Overall Attendance</span>
              <span
                className={`font-bold ${
                  data.attendanceSummary.overallPercentage < 75
                    ? 'text-red-600'
                    : 'text-emerald-700'
                }`}
              >
                {data.attendanceSummary.overallPercentage}%
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500">Enrolled Credits</span>
              <span className="font-semibold text-slate-800">
                {subjects.reduce((sum, s) => sum + s.credits, 0)} Credits
              </span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-500">Academic Standing</span>
              <span className="font-semibold text-slate-800">Good Standing</span>
            </div>
          </div>
        </div>
      </div>

      {/* Enrolled Subjects List */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-3">
        <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
          Enrolled Courses & Instructors
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {subjects.map((sub) => (
            <div
              key={sub.code}
              className="rounded-lg border border-slate-200 bg-slate-50 p-3.5 space-y-1"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-blue-700">{sub.code}</span>
                <span className="text-[10px] font-semibold text-slate-500 bg-slate-200/60 px-1.5 py-0.5 rounded">
                  {sub.credits} Credits
                </span>
              </div>
              <p className="text-xs font-bold text-slate-900">{sub.name}</p>
              <p className="text-[11px] text-slate-500">Faculty: {sub.facultyName}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
