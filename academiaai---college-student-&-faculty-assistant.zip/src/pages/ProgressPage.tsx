import React, { useState } from 'react';
import {
  TrendingUp,
  CheckCircle2,
  Circle,
  Clock,
  BookOpen,
} from 'lucide-react';
import { StudentFullData } from '../types/academic.js';
import { api } from '../services/api.js';

interface ProgressPageProps {
  data: StudentFullData;
  onRefreshData: () => void;
}

export const ProgressPage: React.FC<ProgressPageProps> = ({
  data,
  onRefreshData,
}) => {
  const { student, progress, exams } = data;
  const [activeSubjectCode, setActiveSubjectCode] = useState<string>(
    progress.subjects[0]?.subjectCode || 'CS601'
  );
  const [isUpdating, setIsUpdating] = useState(false);

  const activeSubjectProgress =
    progress.subjects.find((p) => p.subjectCode === activeSubjectCode) ||
    progress.subjects[0];

  const handleToggleTopic = async (topic: string, isCurrentlyCompleted: boolean) => {
    setIsUpdating(true);
    try {
      await api.toggleProgressTopic(
        student.id,
        activeSubjectProgress.subjectCode,
        topic,
        !isCurrentlyCompleted
      );
      onRefreshData();
    } catch (err) {
      console.error('Failed to toggle topic:', err);
    } finally {
      setIsUpdating(false);
    }
  };

  const avgExamPrep =
    exams.length > 0
      ? Math.round(exams.reduce((sum, e) => sum + e.prepProgress, 0) / exams.length)
      : 0;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Academic Progress
          </h1>
          <p className="mt-0.5 text-xs text-slate-500">
            Track syllabus mastery across subjects, mark topics done, and review preparation metrics.
          </p>
        </div>
        <div className="text-right">
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Overall Syllabus</p>
          <p className="text-2xl font-bold text-blue-600">
            {progress.overallProgressPercentage}%
          </p>
        </div>
      </div>

      {/* 4 Overview Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Syllabus Covered</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">
              {progress.overallProgressPercentage}%
            </span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full bg-blue-600 rounded-full"
              style={{ width: `${progress.overallProgressPercentage}%` }}
            />
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Assignments Done</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-emerald-700">
              {progress.assignmentsCompletionPercentage}%
            </span>
            <span className="text-xs text-slate-400">
              ({progress.assignmentsCompletedCount}/{progress.assignmentsTotalCount})
            </span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full bg-emerald-500 rounded-full"
              style={{ width: `${progress.assignmentsCompletionPercentage}%` }}
            />
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Exam Preparation</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">{avgExamPrep}%</span>
            <span className="text-xs text-slate-400">avg readiness</span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full bg-slate-600 rounded-full"
              style={{ width: `${avgExamPrep}%` }}
            />
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Study Hours Logged</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">{progress.totalStudyHours}h</span>
            <span className="text-xs text-slate-400">total</span>
          </div>
          <p className="mt-1 text-[11px] text-slate-400">Self-study & revision</p>
        </div>
      </div>

      {/* Subject-Wise Topic Mastery Section */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
          <h2 className="text-sm font-bold text-slate-900">
            Syllabus Topics by Subject
          </h2>
          <span className="text-xs text-slate-400">Click any topic to mark as completed</span>
        </div>

        {/* Subject Tabs */}
        <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 rounded-lg">
          {progress.subjects.map((sub) => {
            const isSelected = sub.subjectCode === activeSubjectCode;
            const pct = Math.round(
              (sub.completedTopics.length / Math.max(1, sub.totalTopicsCount)) * 100
            );

            return (
              <button
                key={sub.subjectCode}
                onClick={() => setActiveSubjectCode(sub.subjectCode)}
                className={`px-3 py-1.5 text-xs rounded-md transition-colors font-medium cursor-pointer ${
                  isSelected
                    ? 'bg-white text-blue-700 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>{sub.subjectName}</span>
                <span className="ml-1.5 text-[10px] text-slate-400">({pct}%)</span>
              </button>
            );
          })}
        </div>

        {/* Selected Subject Breakdown */}
        {activeSubjectProgress && (
          <div className="space-y-4 pt-2">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  {activeSubjectProgress.subjectName}
                </h3>
                <p className="text-xs text-slate-500">
                  {activeSubjectProgress.completedTopics.length} of{' '}
                  {activeSubjectProgress.totalTopicsCount} topics mastered
                </p>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-400">Study Log:</span>
                <p className="text-sm font-bold text-slate-900">
                  {activeSubjectProgress.studyHoursLogged} Hours
                </p>
              </div>
            </div>

            {/* Checklist */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Completed Topics */}
              <div className="rounded-xl border border-emerald-200 bg-emerald-50/20 p-4 space-y-2">
                <div className="flex items-center justify-between pb-1 border-b border-emerald-100">
                  <span className="text-xs font-bold text-emerald-900 flex items-center gap-1.5">
                    <CheckCircle2 className="h-4 w-4 text-emerald-600" /> Completed Topics (
                    {activeSubjectProgress.completedTopics.length})
                  </span>
                </div>
                {activeSubjectProgress.completedTopics.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">No topics marked as completed yet.</p>
                ) : (
                  activeSubjectProgress.completedTopics.map((topic, i) => (
                    <button
                      key={i}
                      disabled={isUpdating}
                      onClick={() => handleToggleTopic(topic, true)}
                      className="w-full flex items-center justify-between text-left text-xs text-slate-800 p-2.5 rounded-lg bg-white border border-emerald-100 hover:border-emerald-300 transition-colors group cursor-pointer"
                    >
                      <span className="line-through text-slate-400">{topic}</span>
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                    </button>
                  ))
                )}
              </div>

              {/* Remaining Topics */}
              <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-4 space-y-2">
                <div className="flex items-center justify-between pb-1 border-b border-slate-200">
                  <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Circle className="h-4 w-4 text-slate-400" /> Remaining Topics (
                    {activeSubjectProgress.remainingTopics.length})
                  </span>
                </div>
                {activeSubjectProgress.remainingTopics.length === 0 ? (
                  <p className="text-xs text-emerald-600 font-medium">All topics completed for this subject! 🎉</p>
                ) : (
                  activeSubjectProgress.remainingTopics.map((topic, i) => (
                    <button
                      key={i}
                      disabled={isUpdating}
                      onClick={() => handleToggleTopic(topic, false)}
                      className="w-full flex items-center justify-between text-left text-xs text-slate-800 p-2.5 rounded-lg bg-white border border-slate-200 hover:border-blue-400 hover:text-blue-900 transition-colors group cursor-pointer"
                    >
                      <span className="font-medium">{topic}</span>
                      <span className="text-[10px] text-slate-400 group-hover:text-blue-600">
                        Mark Done
                      </span>
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
