import React, { useState } from 'react';
import {
  BrainCircuit,
  Clock,
  Calendar,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  CalendarDays,
  Target,
} from 'lucide-react';
import { StudentFullData } from '../types/academic.js';
import { api } from '../services/api.js';

interface StudyPlannerPageProps {
  data: StudentFullData;
}

export const StudyPlannerPage: React.FC<StudyPlannerPageProps> = ({ data }) => {
  const { student, subjects, exams, assignments } = data;

  const [dailyHours, setDailyHours] = useState<number>(3);
  const [planType, setPlanType] = useState<'1-day' | '7-day' | '1-month'>('1-day');
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(
    subjects.map((s) => s.code)
  );
  const [weakSubjects, setWeakSubjects] = useState<string[]>(
    student.weakSubjects || ['CS601', 'CS602']
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedPlan, setGeneratedPlan] = useState<any>(null);

  const toggleSubject = (code: string) => {
    setSelectedSubjects((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]
    );
  };

  const toggleWeakSubject = (code: string) => {
    setWeakSubjects((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]
    );
  };

  const handleGeneratePlan = async () => {
    setIsGenerating(true);
    try {
      const plan = await api.generateStudyPlan({
        studentId: student.id,
        dailyHours,
        planType,
        weakSubjects,
        focusSubjects: selectedSubjects,
      });
      setGeneratedPlan(plan);
    } catch (err) {
      console.error('Failed to generate study plan:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">Study Planner</h1>
          <p className="mt-0.5 text-xs text-slate-500">
            Generate custom daily, weekly, or monthly study routines calibrated against exams, assignments, and weak areas.
          </p>
        </div>
        <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-blue-50 text-blue-700 self-start sm:self-auto">
          AI Schedule Engine
        </span>
      </div>

      {/* Configuration Form Card */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-5">
        <h2 className="text-sm font-bold text-slate-900">Plan Configuration</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Plan Duration & Hours */}
          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1.5">
                Plan Horizon:
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(
                  [
                    { id: '1-day', label: '1-Day Plan', desc: 'Today intensive' },
                    { id: '7-day', label: '7-Day Plan', desc: 'Weekly schedule' },
                    { id: '1-month', label: '1-Month Plan', desc: 'Term roadmap' },
                  ] as const
                ).map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setPlanType(t.id)}
                    className={`rounded-lg border p-2.5 text-left transition-colors cursor-pointer ${
                      planType === t.id
                        ? 'border-blue-600 bg-blue-50/50 text-blue-900 ring-1 ring-blue-600'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <p className="text-xs font-bold">{t.label}</p>
                    <p className="text-[10px] text-slate-500 mt-0.5">{t.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Daily Hours Slider */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <label htmlFor="daily-hours-slider" className="font-semibold text-slate-700">
                  Available Daily Study Time:
                </label>
                <span className="font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
                  {dailyHours} {dailyHours === 1 ? 'Hour' : 'Hours'} / day
                </span>
              </div>
              <input
                id="daily-hours-slider"
                type="range"
                min="1"
                max="8"
                step="0.5"
                aria-label="Available daily study time in hours"
                value={dailyHours}
                onChange={(e) => setDailyHours(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>1h (Light)</span>
                <span>3h (Standard)</span>
                <span>5h (Intensive)</span>
                <span>8h (Exam Mode)</span>
              </div>
            </div>
          </div>

          {/* Target & Weak Subjects */}
          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1.5">
                Include Subjects:
              </label>
              <div className="flex flex-wrap gap-1.5">
                {subjects.map((s) => {
                  const isSelected = selectedSubjects.includes(s.code);
                  return (
                    <button
                      key={s.code}
                      onClick={() => toggleSubject(s.code)}
                      className={`text-xs px-2.5 py-1 rounded-md border transition-colors cursor-pointer ${
                        isSelected
                          ? 'border-blue-500 bg-blue-50 text-blue-800 font-medium'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {s.shortName}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1.5">
                Prioritize Weaker Subjects (Allocates additional focus):
              </label>
              <div className="flex flex-wrap gap-1.5">
                {subjects.map((s) => {
                  const isWeak = weakSubjects.includes(s.code);
                  return (
                    <button
                      key={s.code}
                      onClick={() => toggleWeakSubject(s.code)}
                      className={`text-xs px-2.5 py-1 rounded-md border transition-colors cursor-pointer ${
                        isWeak
                          ? 'border-amber-400 bg-amber-50 text-amber-900 font-semibold'
                          : 'border-slate-200 bg-white text-slate-500 hover:bg-slate-50'
                      }`}
                    >
                      {s.shortName} {isWeak && '⚠️ Priority'}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Database Insights Bar */}
        <div className="rounded-lg bg-slate-50 p-3 border border-slate-200 text-xs text-slate-600 flex flex-wrap items-center gap-4">
          <span className="font-semibold text-slate-700">Inputs Used:</span>
          <span>📅 Next Exam: {exams[0]?.subjectName || 'None'} ({exams[0]?.daysRemaining}d)</span>
          <span>📝 {assignments.filter((a) => a.status !== 'Completed').length} Pending Assignments</span>
          <span>📊 Syllabus: {data.progress.overallProgressPercentage}%</span>
        </div>

        {/* Action Button */}
        <div>
          <button
            onClick={handleGeneratePlan}
            disabled={isGenerating}
            className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 disabled:opacity-50 transition-colors cursor-pointer"
          >
            <BrainCircuit className="h-4 w-4" />
            <span>
              {isGenerating
                ? 'Synthesizing Academic Schedule...'
                : `Generate ${planType.toUpperCase()} Schedule`}
            </span>
          </button>
        </div>
      </div>

      {/* Generated Schedule Display */}
      {generatedPlan && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
            <div>
              <span className="text-[11px] font-semibold text-blue-600 uppercase tracking-wider">
                Personalized Schedule
              </span>
              <h3 className="text-sm font-bold text-slate-900 mt-0.5">
                {generatedPlan.summary}
              </h3>
            </div>
            <span className="text-xs text-slate-500 font-medium">
              Daily Target: {dailyHours} Hours
            </span>
          </div>

          <div className="space-y-4">
            {generatedPlan.schedule?.map((period: any, pIdx: number) => (
              <div key={pIdx} className="rounded-lg border border-slate-200 bg-slate-50/50 p-4">
                <h4 className="text-xs font-bold text-slate-800 mb-3 flex items-center gap-2">
                  <Calendar className="h-3.5 w-3.5 text-blue-600" />
                  <span>{period.periodLabel}</span>
                </h4>

                <div className="space-y-2">
                  {period.items?.map((item: any, iIdx: number) => (
                    <div
                      key={iIdx}
                      className="rounded-lg border border-slate-200 bg-white p-3 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">{item.subject}</span>
                          <span className="text-[11px] font-medium text-blue-700 bg-blue-50 border border-blue-100 px-1.5 py-0.2 rounded">
                            {item.timeBlock}
                          </span>
                        </div>
                        <p className="text-xs text-slate-700 font-medium">Topic: {item.topic}</p>
                        <p className="text-[11px] text-slate-500 italic">💡 {item.focusTip}</p>
                      </div>

                      <div className="shrink-0 text-right">
                        <span className="text-xs font-semibold text-slate-700 bg-slate-100 px-2 py-1 rounded">
                          {item.duration}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
