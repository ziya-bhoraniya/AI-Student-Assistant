import {
  Student,
  Faculty,
  Subject,
  StudentFullData,
  Assignment,
  Exam,
  Lecture,
  StudyPlan,
  AttendanceStatus,
  AssignmentStatus,
} from '../types/academic.js';

const API_BASE = '/api';

export const api = {
  // Auth
  async login(role: 'student' | 'faculty', id?: string): Promise<{ success: boolean; role: 'student' | 'faculty'; user: any }> {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role, id }),
    });
    if (!res.ok) throw new Error('Login failed');
    return res.json();
  },

  // Students
  async getStudents(): Promise<Student[]> {
    const res = await fetch(`${API_BASE}/students`);
    if (!res.ok) throw new Error('Failed to fetch students');
    return res.json();
  },

  async getStudentFullData(id: string): Promise<StudentFullData> {
    const res = await fetch(`${API_BASE}/students/${id}`);
    if (!res.ok) throw new Error(`Failed to fetch student data for ${id}`);
    return res.json();
  },

  async addStudent(studentData: Partial<Student>): Promise<Student> {
    const res = await fetch(`${API_BASE}/students`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(studentData),
    });
    if (!res.ok) throw new Error('Failed to create student');
    return res.json();
  },

  async updateStudent(id: string, updates: Partial<Student>): Promise<Student> {
    const res = await fetch(`${API_BASE}/students/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) throw new Error('Failed to update student');
    return res.json();
  },

  async deleteStudent(id: string): Promise<{ success: boolean }> {
    const res = await fetch(`${API_BASE}/students/${id}`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error('Failed to delete student');
    return res.json();
  },

  // Faculty & Subjects
  async getFaculty(): Promise<Faculty[]> {
    const res = await fetch(`${API_BASE}/faculty`);
    return res.json();
  },

  async getSubjects(): Promise<Subject[]> {
    const res = await fetch(`${API_BASE}/subjects`);
    return res.json();
  },

  // Attendance
  async recordAttendance(data: {
    studentId: string;
    subjectCode: string;
    status: AttendanceStatus;
    date: string;
    topicTaught?: string;
  }): Promise<{ success: boolean; newPercentage: number }> {
    const res = await fetch(`${API_BASE}/attendance`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to record attendance');
    return res.json();
  },

  // Assignments
  async addAssignment(data: Partial<Assignment>): Promise<Assignment> {
    const res = await fetch(`${API_BASE}/assignments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to add assignment');
    return res.json();
  },

  async updateAssignmentStatus(
    id: string,
    status: AssignmentStatus,
    completionPercentage?: number
  ): Promise<Assignment> {
    const res = await fetch(`${API_BASE}/assignments/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, completionPercentage }),
    });
    if (!res.ok) throw new Error('Failed to update assignment status');
    return res.json();
  },

  // Exams
  async addExam(data: Partial<Exam>): Promise<Exam> {
    const res = await fetch(`${API_BASE}/exams`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to add exam');
    return res.json();
  },

  async updateExam(id: string, updates: Partial<Exam>): Promise<Exam> {
    const res = await fetch(`${API_BASE}/exams/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) throw new Error('Failed to update exam');
    return res.json();
  },

  // Lectures
  async addLecture(data: Partial<Lecture>): Promise<Lecture> {
    const res = await fetch(`${API_BASE}/lectures`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to add lecture');
    return res.json();
  },

  // Progress Topics
  async toggleProgressTopic(
    studentId: string,
    subjectCode: string,
    topic: string,
    completed: boolean
  ): Promise<{ success: boolean }> {
    const res = await fetch(`${API_BASE}/progress/topic`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentId, subjectCode, topic, completed }),
    });
    return res.json();
  },

  // Chatbot (Home page only)
  async askAiAssistant(query: string, studentId: string, history: any[] = []): Promise<string> {
    const res = await fetch(`${API_BASE}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, studentId, history }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to get answer from AI Assistant');
    }
    const data = await res.json();
    return data.answer;
  },

  // Study Planner
  async generateStudyPlan(params: {
    studentId: string;
    dailyHours: number;
    planType: '1-day' | '7-day' | '1-month';
    weakSubjects?: string[];
    focusSubjects?: string[];
  }): Promise<any> {
    const res = await fetch(`${API_BASE}/study-planner/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    if (!res.ok) throw new Error('Failed to generate study plan');
    return res.json();
  },

  // Reset database
  async resetDatabase(): Promise<void> {
    await fetch(`${API_BASE}/reset-db`, { method: 'POST' });
  },
};
