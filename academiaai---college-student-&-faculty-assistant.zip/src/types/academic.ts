export type AttendanceStatus = 'Present' | 'Absent';
export type AssignmentStatus = 'Pending' | 'In Progress' | 'Completed';
export type ReminderType = 'low_attendance' | 'assignment_due' | 'exam_soon' | 'missed_lecture';
export type UrgencyLevel = 'critical' | 'warning' | 'info';

export interface Student {
  id: string; // e.g. 'STU101'
  name: string;
  rollNo: string;
  email: string;
  phone: string;
  course: string; // e.g. 'B.Tech Computer Science & Engineering'
  semester: number; // e.g. 6
  division: string; // e.g. 'A' or 'B'
  cgpa: number;
  mentor: string;
  enrolledSubjects: string[]; // subject codes
  weakSubjects?: string[];
}

export interface Faculty {
  id: string; // e.g. 'FAC001'
  name: string;
  email: string;
  department: string;
  designation: string;
  subjects: string[];
}

export interface Subject {
  code: string; // e.g. 'CS601'
  name: string; // e.g. 'Operating Systems'
  shortName: string; // e.g. 'OS'
  facultyId: string;
  facultyName: string;
  credits: number;
  syllabusTopics: string[];
}

export interface AttendanceEntry {
  id: string;
  studentId: string;
  subjectCode: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  topicTaught: string;
}

export interface Assignment {
  id: string;
  studentId?: string; // If empty or 'ALL', applies to enrolled students
  subjectCode: string;
  subjectName: string;
  facultyName: string;
  title: string;
  description: string;
  deadline: string; // YYYY-MM-DD
  status: AssignmentStatus;
  completionPercentage: number;
}

export interface Exam {
  id: string;
  studentId?: string; // or general
  subjectCode: string;
  subjectName: string;
  examDate: string; // YYYY-MM-DD
  room: string;
  syllabusTopics: string[];
  syllabusProgress: number; // percentage (0-100)
  prepProgress: number; // percentage (0-100)
  notes?: string;
}

export interface Lecture {
  id: string;
  date: string; // YYYY-MM-DD
  subjectCode: string;
  subjectName: string;
  facultyName: string;
  topic: string;
  notesAvailable: boolean;
  notesContent: string;
  attendanceMap: Record<string, AttendanceStatus>; // studentId -> 'Present' | 'Absent'
}

export interface SubjectProgress {
  subjectCode: string;
  subjectName: string;
  completedTopics: string[];
  remainingTopics: string[];
  totalTopicsCount: number;
  studyHoursLogged: number;
}

export interface Reminder {
  id: string;
  type: ReminderType;
  title: string;
  message: string;
  urgency: UrgencyLevel;
  date: string;
  relatedSubject?: string;
  actionPage?: string;
}

export interface StudyPlanItem {
  timeBlock: string;
  subject: string;
  topic: string;
  duration: string;
  focusTip: string;
}

export interface StudyPlan {
  id: string;
  studentId: string;
  planType: '1-day' | '7-day' | '1-month';
  dailyHours: number;
  daysCount: number;
  schedule: Array<{
    periodLabel: string;
    items: StudyPlanItem[];
  }>;
  createdAt: string;
  summary: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  structuredDetails?: {
    recommendations?: string[];
    priorityList?: string[];
    studyPlanSummary?: string;
  };
}

export interface StudentFullData {
  student: Student;
  subjects: Subject[];
  attendanceSummary: {
    overallPercentage: number;
    totalClasses: number;
    totalAttended: number;
    totalMissed: number;
    subjectStats: Array<{
      subjectCode: string;
      subjectName: string;
      facultyName: string;
      attended: number;
      missed: number;
      total: number;
      percentage: number;
      isLow: boolean;
      neededFor75: number;
    }>;
  };
  assignments: Array<Assignment & { daysRemaining: number; isUrgent: boolean }>;
  exams: Array<Exam & { daysRemaining: number }>;
  lectures: Array<{
    id: string;
    date: string;
    subjectCode: string;
    subjectName: string;
    topic: string;
    status: AttendanceStatus;
    notesAvailable: boolean;
    notesContent: string;
    facultyName: string;
  }>;
  progress: {
    overallProgressPercentage: number;
    subjects: SubjectProgress[];
    totalStudyHours: number;
    assignmentsCompletedCount: number;
    assignmentsTotalCount: number;
    assignmentsCompletionPercentage: number;
  };
  reminders: Reminder[];
}
