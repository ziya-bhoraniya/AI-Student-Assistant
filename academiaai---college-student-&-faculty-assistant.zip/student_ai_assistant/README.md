# AcademiaAI — College Student & Faculty Assistant (Python + Streamlit + SQLite)

A complete college academic portal and personal AI student assistant powered by Google Gemini and SQLite.

## Features
- **Faculty Management:** Add/edit students, record lecture attendance, assign homework, schedule exams, upload lecture notes.
- **Personalized Student Dashboard:** Reads actual SQLite student data.
- **Academic AI Agent:** Exclusively on the Home Page, analyzing the student's real attendance, urgent deadlines, and syllabus progress.
- **8 Dedicated Student Pages:** Attendance, Assignments, Exams, Study Planner, Lectures & Notes, Progress, Profile, and Faculty.
- **10 Sample Indian College Students** pre-seeded with realistic records.

---

## 🛠️ Step-by-Step Installation & Running in VS Code

### 1. Open in VS Code
Open the `student_ai_assistant` folder in Visual Studio Code:
```bash
cd student_ai_assistant
```

### 2. Create and Activate a Python Virtual Environment
**On Windows (PowerShell):**
```powershell
python -m venv venv
.\venv\Scripts\activate
```

**On macOS / Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure Your Gemini API Key
Create a `.env` file in the `student_ai_assistant` folder (copy from `.env.example`):
```bash
GEMINI_API_KEY=YOUR_GEMINI_API_KEY
```
*(Get a free Gemini API key from [Google AI Studio](https://aistudio.google.com/app/apikey))*.
*Note: If no API key is set, the application automatically uses its built-in rule-based academic engine so it never fails.*

### 5. Run the Application
```bash
streamlit run app.py
```
Streamlit will launch automatically in your browser at `http://localhost:8501`.

---

## 👥 Demo Credentials
- **Student Login:** Select any of the 10 students from the sidebar dropdown (e.g. `Aarav Sharma (STU101)`, `Rohan Verma (STU103 - Low Attendance Warning)`, `Priya Patel (STU102)`).
- **Faculty Login:** Switch to "Faculty" in the sidebar to add/edit students, enter lecture attendance, or post assignments.
