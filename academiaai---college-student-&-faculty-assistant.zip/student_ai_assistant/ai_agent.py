import os
import json
from google import genai
from google.genai import types

def get_gemini_client():
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return None
    return genai.Client(
        api_key=api_key,
        http_options={'headers': {'User-Agent': 'aistudio-build'}}
    )

def build_student_context(student, att_summary, assignments, exams, lectures):
    att_str = "\n".join([
        f"- {s['name']} ({s['code']}): {s['percentage']}% ({s['attended']}/{s['total']} classes){' [LOW ATTENDANCE WARNING]' if s['is_low'] else ''}"
        for s in att_summary['subject_stats']
    ])

    pending_asns = [a for a in assignments if a['status'] != 'Completed']
    asns_str = "\n".join([
        f"- {a['title']} ({a['subject_name']}) | Due: {a['deadline']} | Status: {a['status']} ({a['completion_pct']}%)"
        for a in pending_asns
    ]) or "No pending assignments."

    exams_str = "\n".join([
        f"- {e['subject_name']}: Date {e['exam_date']}, Room {e['room']}, Prep {e['prep_progress']}%"
        for e in exams
    ])

    missed_lecs = []
    for l in lectures:
        att_map = json.loads(l.get('attendance_map', '{}'))
        if att_map.get(student['id']) == 'Absent':
            missed_lecs.append(f"- {l['date']}: {l['subject_name']} — Topic: '{l['topic']}'")

    missed_str = "\n".join(missed_lecs) or "No missed classes recorded."

    return f"""STUDENT ACADEMIC PROFILE (STRICT DATABASE RECORDS):
Name: {student['name']} (ID: {student['id']}, Roll: {student['roll_no']})
Course: {student['course']}, Sem: {student['semester']}, Div: {student['division']}, CGPA: {student['cgpa']}
Mentor: {student['mentor']}

ATTENDANCE:
Overall: {att_summary['overall_pct']}% ({att_summary['total_attended']}/{att_summary['total_classes']} classes)
{att_str}

ASSIGNMENTS:
{asns_str}

UPCOMING EXAMS:
{exams_str}

MISSED LECTURES:
{missed_str}
"""

def query_ai_agent(user_query, student, att_summary, assignments, exams, lectures, history=None):
    context = build_student_context(student, att_summary, assignments, exams, lectures)
    first_name = student['name'].split()[0]

    system_instruction = f"""You are AcademiaAI, a dedicated college academic assistant.
Always base answers strictly on the student's actual database profile below.
Address student by first name ({first_name}).
Provide helpful, proactive, structured advice regarding attendance, urgent assignments, upcoming exams, or study plans.

{context}
"""
    client = get_gemini_client()
    if client:
        try:
            response = client.models.generate_content(
                model="gemini-3.8-flash",
                contents=user_query,
                config=types.GenerateContentConfig(
                    system_instruction=system_instruction,
                    temperature=0.7,
                )
            )
            if response and response.text:
                return response.text
        except Exception as e:
            print(f"Gemini API error, falling back to rule-based engine: {e}")

    # Fallback response
    q = user_query.lower()
    if 'attendance' in q:
        return f"Hello {first_name}, your overall attendance is **{att_summary['overall_pct']}%** ({att_summary['total_attended']} attended out of {att_summary['total_classes']} classes). Check the Attendance tab for full subject-by-subject statistics."
    elif 'assignment' in q:
        pending = [a for a in assignments if a['status'] != 'Completed']
        if not pending:
            return f"Great job {first_name}, you have no pending assignments!"
        return f"Hello {first_name}, you have **{len(pending)} pending assignments**. The most urgent is **{pending[0]['title']}** due on {pending[0]['deadline']}."
    elif 'exam' in q:
        if exams:
            return f"Hello {first_name}, your next exam is **{exams[0]['subject_name']}** on **{exams[0]['exam_date']}** with current preparation at {exams[0]['prep_progress']}%."
    return f"Hello {first_name}! Your current attendance is {att_summary['overall_pct']}%, you have {len([a for a in assignments if a['status'] != 'Completed'])} pending assignments, and your upcoming exam is {exams[0]['subject_name'] if exams else 'none'}. How can I assist your studies today?"
