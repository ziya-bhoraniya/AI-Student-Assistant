import streamlit as st
import os
from dotenv import load_dotenv
import database as db
import ai_agent

load_dotenv()
db.init_db()

st.set_page_config(
    page_title="AcademiaAI - Student Academic Assistant",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Authentication / Session State
if "user_role" not in st.session_state:
    st.session_state.user_role = "student"
if "current_student_id" not in st.session_state:
    st.session_state.current_student_id = "STU101"
if "chat_messages" not in st.session_state:
    st.session_state.chat_messages = []

# Sidebar Navigation & User Switcher
with st.sidebar:
    st.title("🎓 AcademiaAI")
    st.caption("College Academic Portal & Assistant")

    role = st.radio("Portal View", ["Student", "Faculty"], index=0 if st.session_state.user_role == "student" else 1)
    st.session_state.user_role = role.lower()

    if st.session_state.user_role == "student":
        students = db.get_all_students()
        student_options = {f"{s['name']} ({s['id']})": s['id'] for s in students}
        current_idx = list(student_options.values()).index(st.session_state.current_student_id) if st.session_state.current_student_id in student_options.values() else 0
        selected_label = st.selectbox("Switch Active Student:", list(student_options.keys()), index=current_idx)
        st.session_state.current_student_id = student_options[selected_label]
        st.info(f"Logged in as **{selected_label}**")
    else:
        st.success("Logged in as **Prof. Rajesh Mehta (Faculty)**")

# If Faculty selected, direct to faculty view
if st.session_state.user_role == "faculty":
    st.title("👨‍🏫 Faculty Academic Management Portal")
    st.markdown("Manage student records, mark lecture attendance, add assignments and schedule exams.")
    st.write("Navigate to the **Faculty** section in the pages menu or use the controls below.")
    st.stop()

# --- STUDENT HOME / AI ASSISTANT PAGE ---
student = db.get_student(st.session_state.current_student_id)
if not student:
    st.error("Student record not found.")
    st.stop()

att_summary = db.get_student_attendance(student['id'])
assignments = db.get_assignments()
exams = db.get_exams()
lectures = db.get_lectures()

first_name = student['name'].split()[0]

st.title(f"Welcome back, {first_name}! 👋")
st.caption(f"{student['course']} · Semester {student['semester']} (Div {student['division']}) · Roll No: {student['roll_no']}")

# 4 Key Summary Metric Cards
c1, c2, c3, c4 = st.columns(4)

with c1:
    st.metric(
        label="Overall Attendance",
        value=f"{att_summary['overall_pct']}%",
        delta="Warning: Low" if att_summary['overall_pct'] < 75 else "Good standing",
        delta_color="inverse" if att_summary['overall_pct'] < 75 else "normal"
    )

with c2:
    pending_count = len([a for a in assignments if a['status'] != 'Completed'])
    st.metric(label="Pending Assignments", value=f"{pending_count}", delta=f"{pending_count} to submit")

with c3:
    next_exam_title = exams[0]['subject_name'] if exams else "None"
    st.metric(label="Next Upcoming Exam", value=next_exam_title, delta=f"Date: {exams[0]['exam_date']}" if exams else "")

with c4:
    st.metric(label="Study Hours / Progress", value="68%", delta="Semester syllabus")

st.markdown("---")

# PROMINENT AI ASSISTANT CHATBOT (ONLY ON HOME PAGE)
st.subheader("🤖 Your Personalized Academic AI Assistant")
st.markdown("Ask anything regarding your actual attendance, upcoming exams, urgent assignments, missed lectures, or ask for a study plan.")

# Quick prompt chips
q1, q2, q3, q4 = st.columns(4)
prompt_clicked = None
if q1.button("📌 What should I study today?"):
    prompt_clicked = "What should I study today?"
if q2.button("📊 What is my attendance?"):
    prompt_clicked = "What is my attendance?"
if q3.button("📝 Which assignment is urgent?"):
    prompt_clicked = "Which assignment should I complete first?"
if q4.button("⏳ Make me a 3-hour study plan"):
    prompt_clicked = "I have 3 hours today. What should I study?"

# Display chat history
for msg in st.session_state.chat_messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

user_input = st.chat_input("Ask your academic assistant anything (e.g. 'What did I miss when absent?')...")

active_query = prompt_clicked or user_input
if active_query:
    st.session_state.chat_messages.append({"role": "user", "content": active_query})
    with st.chat_message("user"):
        st.markdown(active_query)

    with st.chat_message("assistant"):
        with st.spinner("Analyzing your academic records..."):
            reply = ai_agent.query_ai_agent(active_query, student, att_summary, assignments, exams, lectures)
            st.markdown(reply)
            st.session_state.chat_messages.append({"role": "assistant", "content": reply})
