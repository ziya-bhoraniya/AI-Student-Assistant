import sqlite3
import os
import json
from datetime import datetime

DB_DIR = os.path.join(os.path.dirname(__file__), 'data')
DB_PATH = os.path.join(DB_DIR, 'database.db')

def get_connection():
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    # Students table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS students (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        roll_no TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT,
        course TEXT NOT NULL,
        semester INTEGER NOT NULL,
        division TEXT NOT NULL,
        cgpa REAL,
        mentor TEXT,
        enrolled_subjects TEXT, -- JSON array
        weak_subjects TEXT       -- JSON array
    )
    ''')

    # Faculty table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS faculty (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        department TEXT NOT NULL,
        designation TEXT NOT NULL,
        subjects TEXT -- JSON array
    )
    ''')

    # Subjects table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS subjects (
        code TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        short_name TEXT NOT NULL,
        faculty_id TEXT NOT NULL,
        faculty_name TEXT NOT NULL,
        credits INTEGER NOT NULL,
        syllabus_topics TEXT -- JSON array
    )
    ''')

    # Attendance table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id TEXT NOT NULL,
        subject_code TEXT NOT NULL,
        date TEXT NOT NULL,
        status TEXT NOT NULL, -- 'Present' or 'Absent'
        topic_taught TEXT,
        FOREIGN KEY (student_id) REFERENCES students(id),
        FOREIGN KEY (subject_code) REFERENCES subjects(code)
    )
    ''')

    # Assignments table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS assignments (
        id TEXT PRIMARY KEY,
        subject_code TEXT NOT NULL,
        subject_name TEXT NOT NULL,
        faculty_name TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        deadline TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Pending', -- 'Pending', 'In Progress', 'Completed'
        completion_pct INTEGER DEFAULT 0
    )
    ''')

    # Exams table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS exams (
        id TEXT PRIMARY KEY,
        subject_code TEXT NOT NULL,
        subject_name TEXT NOT NULL,
        exam_date TEXT NOT NULL,
        room TEXT NOT NULL,
        syllabus_topics TEXT, -- JSON array
        syllabus_progress INTEGER DEFAULT 50,
        prep_progress INTEGER DEFAULT 40,
        notes TEXT
    )
    ''')

    # Lectures table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS lectures (
        id TEXT PRIMARY KEY,
        date TEXT NOT NULL,
        subject_code TEXT NOT NULL,
        subject_name TEXT NOT NULL,
        faculty_name TEXT NOT NULL,
        topic TEXT NOT NULL,
        notes_available INTEGER DEFAULT 1,
        notes_content TEXT,
        attendance_map TEXT -- JSON object {student_id: 'Present'/'Absent'}
    )
    ''')

    conn.commit()

    # Check if we should seed initial 10 students
    cursor.execute('SELECT COUNT(*) as count FROM students')
    if cursor.fetchone()['count'] == 0:
        seed_data(conn)

    conn.close()

def seed_data(conn):
    cursor = conn.cursor()

    # Seed 10 realistic Indian students
    students = [
        ('STU101', 'Aarav Sharma', '21CS101', 'aarav.sharma@college.edu.in', '+91 98201 44521', 'B.Tech Computer Science & Engineering', 6, 'A', 8.65, 'Prof. Rajesh Mehta', json.dumps(['CS601', 'CS602', 'CS603', 'CS604', 'CS605']), json.dumps(['CS602'])),
        ('STU102', 'Priya Patel', '21CS102', 'priya.patel@college.edu.in', '+91 98450 12890', 'B.Tech Computer Science & Engineering', 6, 'A', 8.20, 'Dr. Sunita Rao', json.dumps(['CS601', 'CS602', 'CS603', 'CS604', 'CS605']), json.dumps(['CS603'])),
        ('STU103', 'Rohan Verma', '21CS103', 'rohan.verma@college.edu.in', '+91 97112 88419', 'B.Tech Computer Science & Engineering', 6, 'B', 6.95, 'Prof. Rajesh Mehta', json.dumps(['CS601', 'CS602', 'CS603', 'CS604', 'CS605']), json.dumps(['CS601', 'CS602'])),
        ('STU104', 'Ananya Iyer', '21CS104', 'ananya.iyer@college.edu.in', '+91 99304 55120', 'B.Tech Computer Science & Engineering', 6, 'A', 9.45, 'Dr. Sunita Rao', json.dumps(['CS601', 'CS602', 'CS603', 'CS604', 'CS605']), json.dumps([])),
        ('STU105', 'Karthik Nair', '21CS105', 'karthik.nair@college.edu.in', '+91 98111 67234', 'B.Tech Computer Science & Engineering', 6, 'B', 7.75, 'Prof. Rajesh Mehta', json.dumps(['CS601', 'CS602', 'CS603', 'CS604', 'CS605']), json.dumps(['CS601'])),
        ('STU106', 'Sneha Kulkarni', '21CS106', 'sneha.kulkarni@college.edu.in', '+91 98670 91823', 'B.Tech Computer Science & Engineering', 6, 'A', 8.10, 'Dr. Sunita Rao', json.dumps(['CS601', 'CS602', 'CS603', 'CS604', 'CS605']), json.dumps(['CS604'])),
        ('STU107', 'Vikram Singh', '21CS107', 'vikram.singh@college.edu.in', '+91 98220 33419', 'B.Tech Computer Science & Engineering', 6, 'B', 7.30, 'Prof. Rajesh Mehta', json.dumps(['CS601', 'CS602', 'CS603', 'CS604', 'CS605']), json.dumps(['CS603', 'CS605'])),
        ('STU108', 'Divya Sundaram', '21CS108', 'divya.sundaram@college.edu.in', '+91 99401 77312', 'B.Tech Computer Science & Engineering', 6, 'A', 8.80, 'Dr. Sunita Rao', json.dumps(['CS601', 'CS602', 'CS603', 'CS604', 'CS605']), json.dumps(['CS602'])),
        ('STU109', 'Mohammad Farhan', '21CS109', 'm.farhan@college.edu.in', '+91 98920 66541', 'B.Tech Computer Science & Engineering', 6, 'B', 7.15, 'Prof. Rajesh Mehta', json.dumps(['CS601', 'CS602', 'CS603', 'CS604', 'CS605']), json.dumps(['CS603'])),
        ('STU110', 'Ishita Sen', '21CS110', 'ishita.sen@college.edu.in', '+91 98300 22918', 'B.Tech Computer Science & Engineering', 6, 'A', 9.10, 'Dr. Sunita Rao', json.dumps(['CS601', 'CS602', 'CS603', 'CS604', 'CS605']), json.dumps(['CS604']))
    ]

    cursor.executemany('''
    INSERT INTO students (id, name, roll_no, email, phone, course, semester, division, cgpa, mentor, enrolled_subjects, weak_subjects)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', students)

    # Faculty
    faculty = [
        ('FAC001', 'Prof. Rajesh Mehta', 'rajesh.mehta@college.edu.in', 'Computer Science & Engineering', 'Associate Professor & HOD Academics', json.dumps(['CS601', 'CS602'])),
        ('FAC002', 'Dr. Sunita Rao', 'sunita.rao@college.edu.in', 'Computer Science & Engineering', 'Professor & Senior Research Lead', json.dumps(['CS603', 'CS604', 'CS605']))
    ]
    cursor.executemany('INSERT INTO faculty VALUES (?, ?, ?, ?, ?, ?)', faculty)

    # Subjects
    subjects = [
        ('CS601', 'Operating Systems', 'OS', 'FAC001', 'Prof. Rajesh Mehta', 4, json.dumps(['Process Management', 'CPU Scheduling Algorithms', 'Deadlocks', 'Memory Management & Paging', 'Virtual Memory', 'Disk Scheduling'])),
        ('CS602', 'Database Management Systems', 'DBMS', 'FAC001', 'Prof. Rajesh Mehta', 4, json.dumps(['ER Diagrams', 'Relational Algebra & SQL', 'Normalization (1NF-BCNF)', 'Transactions & ACID', 'Concurrency Control'])),
        ('CS603', 'Computer Networks', 'CN', 'FAC002', 'Dr. Sunita Rao', 4, json.dumps(['OSI & TCP/IP Model', 'Data Link Layer', 'Routing Algorithms', 'Subnetting & CIDR', 'Transport Layer (TCP/UDP)'])),
        ('CS604', 'Theory of Computation', 'TOC', 'FAC002', 'Dr. Sunita Rao', 3, json.dumps(['Finite Automata (DFA/NFA)', 'Regular Expressions & Pumping Lemma', 'Context Free Grammars', 'Pushdown Automata', 'Turing Machines'])),
        ('CS605', 'Web Technologies & Cloud Applications', 'WTCA', 'FAC002', 'Dr. Sunita Rao', 3, json.dumps(['REST APIs', 'React Framework', 'Express Middleware', 'Authentication', 'Cloud & Docker Deployment']))
    ]
    cursor.executemany('INSERT INTO subjects VALUES (?, ?, ?, ?, ?, ?, ?)', subjects)

    # Assignments
    assignments = [
        ('ASN001', 'CS602', 'Database Management Systems', 'Prof. Rajesh Mehta', 'DBMS Assignment 3: Relational Algebra & SQL Optimization', 'Complex queries, relational algebra execution plans.', '2026-09-29', 'Pending', 35),
        ('ASN002', 'CS603', 'Computer Networks', 'Dr. Sunita Rao', 'Socket Programming & Wireshark Packet Capture', 'TCP Echo server in Python and packet analysis.', '2026-09-28', 'In Progress', 70),
        ('ASN003', 'CS601', 'Operating Systems', 'Prof. Rajesh Mehta', 'Process Synchronization with Semaphores', 'Simulate Producer-Consumer with deadlock prevention.', '2026-10-04', 'Pending', 10),
        ('ASN004', 'CS604', 'Theory of Computation', 'Dr. Sunita Rao', 'PDA Design & Chomsky Normal Form Simplification', 'Construct PDA for palindromes and simplify CFG.', '2026-10-08', 'Pending', 0),
        ('ASN005', 'CS605', 'Web Technologies & Cloud Applications', 'Dr. Sunita Rao', 'Full Stack REST API with Docker containerization', 'Containerized Node backend with JWT authentication.', '2026-09-20', 'Completed', 100)
    ]
    cursor.executemany('INSERT INTO assignments VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', assignments)

    # Exams
    exams = [
        ('EXAM001', 'CS601', 'Operating Systems', '2026-10-09', 'Hall 302, Academic Block A', json.dumps(['Processes & Threads', 'CPU Scheduling', 'Deadlocks', 'Virtual Memory']), 65, 60, 'Focus on Banker Algorithm and Page Replacement.'),
        ('EXAM002', 'CS604', 'Theory of Computation', '2026-10-03', 'Auditorium 1, Main Campus', json.dumps(['DFA/NFA', 'Regular Expressions', 'Pumping Lemma', 'Pushdown Automata']), 55, 45, 'High weightage on Pumping Lemma proofs.'),
        ('EXAM003', 'CS602', 'Database Management Systems', '2026-10-15', 'Lab 4, Computing Center', json.dumps(['Relational Algebra & SQL', 'Normalization', 'Transactions', 'Indexing']), 75, 65, 'Practical SQL & Normalization.'),
        ('EXAM004', 'CS603', 'Computer Networks', '2026-10-22', 'Hall 105, Academic Block B', json.dumps(['OSI/TCP-IP', 'Subnetting & Routing', 'TCP Congestion Control']), 80, 70, 'Subnetting & Routing calculations.')
    ]
    cursor.executemany('INSERT INTO exams VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', exams)

    # Lectures
    lectures = [
        (
            'LEC001', '2026-09-24', 'CS601', 'Operating Systems', 'Prof. Rajesh Mehta',
            'CPU Scheduling Algorithms (FCFS, SJF, Round Robin & Priority)',
            1,
            '### Operating Systems — CPU Scheduling\n- FCFS: Convoy effect\n- SJF/SRTF: Optimal turnaround time\n- Round Robin: Time quantum critical\n- Starvation handled by Aging.',
            json.dumps({'STU101': 'Present', 'STU102': 'Present', 'STU103': 'Absent', 'STU104': 'Present', 'STU105': 'Absent', 'STU106': 'Present', 'STU107': 'Absent', 'STU108': 'Present', 'STU109': 'Present', 'STU110': 'Present'})
        ),
        (
            'LEC002', '2026-09-25', 'CS602', 'Database Management Systems', 'Prof. Rajesh Mehta',
            'Database Normalization (3NF vs BCNF & Dependency Preservation)',
            1,
            '### DBMS — Normalization (3NF & BCNF)\n- 3NF allows prime attribute on RHS\n- BCNF strictly requires LHS to be superkey\n- Lossless join guaranteed in both.',
            json.dumps({'STU101': 'Present', 'STU102': 'Present', 'STU103': 'Absent', 'STU104': 'Present', 'STU105': 'Present', 'STU106': 'Present', 'STU107': 'Present', 'STU108': 'Present', 'STU109': 'Absent', 'STU110': 'Present'})
        ),
        (
            'LEC003', '2026-09-26', 'CS603', 'Computer Networks', 'Dr. Sunita Rao',
            'Subnetting, CIDR & Variable Length Subnet Masking (VLSM)',
            1,
            '### CN — CIDR & Subnetting\n- Subnet masks: /24, /26, /28\n- Usable host formula: 2^(32-n) - 2\n- Longest prefix match routing.',
            json.dumps({'STU101': 'Present', 'STU102': 'Absent', 'STU103': 'Present', 'STU104': 'Present', 'STU105': 'Present', 'STU106': 'Present', 'STU107': 'Absent', 'STU108': 'Present', 'STU109': 'Absent', 'STU110': 'Present'})
        )
    ]
    cursor.executemany('INSERT INTO lectures VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', lectures)

    conn.commit()

# Query helper functions
def get_student(student_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute('SELECT * FROM students WHERE id = ?', (student_id,))
    row = c.fetchone()
    conn.close()
    return dict(row) if row else None

def get_all_students():
    conn = get_connection()
    c = conn.cursor()
    c.execute('SELECT * FROM students ORDER BY id ASC')
    rows = c.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_subjects():
    conn = get_connection()
    c = conn.cursor()
    c.execute('SELECT * FROM subjects')
    rows = c.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_assignments():
    conn = get_connection()
    c = conn.cursor()
    c.execute('SELECT * FROM assignments ORDER BY deadline ASC')
    rows = c.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_exams():
    conn = get_connection()
    c = conn.cursor()
    c.execute('SELECT * FROM exams ORDER BY exam_date ASC')
    rows = c.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_lectures():
    conn = get_connection()
    c = conn.cursor()
    c.execute('SELECT * FROM lectures ORDER BY date DESC')
    rows = c.fetchall()
    conn.close()
    return [dict(r) for r in rows]

# Attendance stats mapping
STUDENT_ATT_PRESETS = {
    'STU101': {'CS601': (22, 3), 'CS602': (21, 4), 'CS603': (22, 2), 'CS604': (18, 2), 'CS605': (18, 2)},
    'STU102': {'CS601': (19, 6), 'CS602': (19, 6), 'CS603': (17, 7), 'CS604': (15, 5), 'CS605': (15, 5)},
    'STU103': {'CS601': (17, 8), 'CS602': (16, 9), 'CS603': (17, 7), 'CS604': (14, 6), 'CS605': (14, 6)},
    'STU104': {'CS601': (24, 1), 'CS602': (24, 1), 'CS603': (23, 1), 'CS604': (19, 1), 'CS605': (19, 1)},
    'STU105': {'CS601': (19, 6), 'CS602': (20, 5), 'CS603': (19, 5), 'CS604': (16, 4), 'CS605': (16, 4)},
    'STU106': {'CS601': (21, 4), 'CS602': (21, 4), 'CS603': (20, 4), 'CS604': (15, 5), 'CS605': (17, 3)},
    'STU107': {'CS601': (18, 7), 'CS602': (18, 7), 'CS603': (17, 7), 'CS604': (14, 6), 'CS605': (15, 5)},
    'STU108': {'CS601': (22, 3), 'CS602': (21, 4), 'CS603': (21, 3), 'CS604': (17, 3), 'CS605': (18, 2)},
    'STU109': {'CS601': (18, 7), 'CS602': (18, 7), 'CS603': (16, 8), 'CS604': (15, 5), 'CS605': (15, 5)},
    'STU110': {'CS601': (23, 2), 'CS602': (23, 2), 'CS603': (22, 2), 'CS604': (18, 2), 'CS605': (19, 1)},
}

def get_student_attendance(student_id):
    subjects = get_subjects()
    presets = STUDENT_ATT_PRESETS.get(student_id, {})
    stats = []
    total_att = 0
    total_miss = 0

    for sub in subjects:
        att, miss = presets.get(sub['code'], (18, 4))
        tot = att + miss
        pct = round((att / tot) * 100) if tot > 0 else 0
        total_att += att
        total_miss += miss
        needed_75 = max(0, 3 * tot - 4 * att) if pct < 75 else 0

        stats.append({
            'code': sub['code'],
            'name': sub['name'],
            'faculty': sub['faculty_name'],
            'attended': att,
            'missed': miss,
            'total': tot,
            'percentage': pct,
            'is_low': pct < 75,
            'needed_75': needed_75
        })

    overall_tot = total_att + total_miss
    overall_pct = round((total_att / overall_tot) * 100) if overall_tot > 0 else 0

    return {
        'overall_pct': overall_pct,
        'total_attended': total_att,
        'total_missed': total_miss,
        'total_classes': overall_tot,
        'subject_stats': stats
    }
